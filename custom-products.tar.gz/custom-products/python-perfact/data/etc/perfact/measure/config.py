#!/usr/bin/env python
'''Default configuration for measure.py'''

# Use systemd-journald for logging?
use_journal = False

# How to connect to the database (mandatory for measure.py)
dbconn_string = 'dbname=perfactema user=postgres'
pg_version = '11'
# Warning and failure limit in MiB for total table size
bigtables_limits = [5000, 7000]
# This timeout is for SQL statements, e.g. measurement of table size (seconds)
statement_timeout = 2

# Default email sender for notifications
sender = 'no-reply@perfact.de'

# Default email recipients for notifications
recipients = ['sla@perfact.de', ]

# Recipient for measurements, e.g.
# upload_recipient = 'measure@perfact.de'
# upload_interval = 60
upload_recipient = None
upload_interval = None

# Enable / disable recoveries and notifications globally
recoveries_enabled = True
notifications_enabled = True

# Sampling interval
interval = 10

# Maximum time for each test
timeout = 30

# Recovery command for zeo
# ubuntu14.04
# zeo_service_name = 'zope{zope_version}'
# >=ubuntu16.04
# do not edit {zope_version}, it will be replaced later
zeo_service_name = 'zope@{zope_version}-zeo-emazeo'

# Recovery command for zope
# It is used with: service <cmd> restart
# ubuntu14.04
# zope_service_name = 'zope{zope_version}'
# >=ubuntu16.04
# do not edit {zope_version} and {inst}, it will be replaced later
zope_service_name = 'zope@{zope_version}-instance-{inst}'


# ZEO PID-file
# ubuntu14.04
# zeo_pidfile = 'ZEO.pid'
# >=ubuntu16.04
zeo_pidfile = 'Z2.pid'


def hook(pm):
    # Set up the tests in pm (Instance of PerformanceMeter)

    # Tests for installations with a running dbcached
    pm.setup_cachecontrol()

    # Tests for standard Zope installations
    pm.setup_postgresql(bigtables_limits=bigtables_limits,
                        version=pg_version)
    pm.setup_apache()
    pm.setup_server()
    pm.setup_zope(
        zope_service_name=zope_service_name,
        zeo_service_name=zeo_service_name,
        zeo_pidfile=zeo_pidfile)

    # Test timeout behaviour by activating this:
    # pm.setup_dummydelay()

    try:
        import systemd  # only possible if we are on a newer system
        pm.setup_systemd()
    except ImportError:
        pass


# Put your own tests here
