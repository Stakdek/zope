# Base directory of the repository
base_dir = '/opt/perfact/dbutils-pgrepo'

# For backwards compatibility, an unset subdir means '__psql__' while an empty
# subdir means to record directly into the given base_dir
subdir = ''

# Databases to store (usually only one)
databases = ['perfactema', ]

# Tables to dump on a regular basis
db_tables = {
    'perfactema': [
        'apppref',
        'appnavcustom',
        'appcerttype',
        'appjob',
        'datadict',
        'datadictint',
        'country',
        'escalbasemethod',
        'escalmethod',
        'i18nlang',
        'i18nlex',
        'i18nelem',
        'i18ntrans',
        'qnattrtype',
        # module SCA
        'filestatus',
        'filetype',
        'gentemplate',
        # module UCA
        'cachereqlc',
        'xferstatus',
        # module PSA
        'ean128',
        'appdevtype',
        'appdevtgt',
        'brserv',
        'brservitem',
    ],
}

# default settings for git repos
commit_name = "Zope Developer"
commit_email = "zope-devel@perfact.de"
commit_message = "Generic commit message."
