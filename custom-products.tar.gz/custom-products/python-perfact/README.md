# PerFact Python Modules

Requirements (when installed as debian package):
- Debian based linux distribution
-

Maintainers:
Ján Jockusch <jan.jockusch@perfact.de>
Viktor Dick <viktor.dick@perfact.de>


# Installation

A stable build is available via the perfact debian package repository and can
be installed using aptitude.

Development packages can be installed using dpkg.
