#
# dbbackup.py  -  Methods for dumping and restoring database tables.
#
# Copyright (C) 2018 Jan Jockusch <jan.jockusch@perfact-innovation.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
'''Required software:
- postgres-client (pg_dump, psql)
'''
import tempfile
import subprocess
import os
from perfact.generic import safe_syscall
import perfact.pfcodechg

# NOTE: The user has to have superuser privileges, usually postgres
# NOTE: Using this from within Zope may lead to long loading times.
# Deployment for systems without remote access needs these steps:
# /opt/perfact/python-modules/perfact>sudo cp dbbackup.py \
#        /usr/lib/python2.7/dist-packages/perfact/
# >sudo emacs \
#  /var/lib/zope2.13/instance/ema/Products/PerFactScriptModules/__init__.py
#    add allow_module("perfact.dbbackup")


DEFAULT_CONNSTR = 'dbname=perfactema user=postgres'


def connstr_to_dbargs(connstr):
    '''Convert connection string to dbargs dictionary.
    >>> connstr_to_dbargs('dbname=perfactema user=zope')
    {'dbname': 'perfactema', 'user': 'zope'}
    '''
    return dict([pair.strip().split('=', 1) for pair in connstr.split(' ')])


def dbargs_to_options(dbargs):
    '''Unfold dbargs into options for pg_dump.
    >>> dbargs_to_options({'dbname': 'perfactema', 'user': 'zope'})
    ['--dbname', 'perfactema', '--user', 'zope']
    '''
    return [i for k, v in dbargs.items() for i in ['--'+k, v]]


def db_dump(tables=None, connstr=DEFAULT_CONNSTR):
    '''Dump data from indicated tables. Tables must be unique in the
    list of available schemata or given in schema.table syntax.

    The dump is produced and saved as a temporary file.  This method
    returns the path and file name for transmission to the client.

    '''
    if tables is None:
        tables = []
    for schema, table in tables:
        assert table.isalnum(), "Only alphanumeric table names allowed."

    dbargs = connstr_to_dbargs(connstr)

    tdir = tempfile.mkdtemp()
    fname = tdir + '/dump.sql'
    fh = open(fname, 'wb')
    fh.write('''-- PerFact DB dump
set session_replication_role to 'replica';
''')
    fh.close()
    for schema, table in tables:
        db_dump_table(fname, dbargs, schema, table, truncate=True)

    safe_syscall(['gzip', fname], raisemode=True)
    return tdir, 'dump.sql.gz'


def db_dump_table(fname, dbargs, schema=None, table=None, truncate=False,
                  append=True, inserts=True):
    '''
    Dump the table with an optional prepended truncate statement.
    Parameters:
      * fname: file name to be saved to
      * dbargs: a struct describing database connection arguments (see above)
      * schema: the name of the schema. If omitted, the table is looked for in
          the search path.
      * table: the name of the table to be dumped
      * truncate: if set, a statement to delete the table is included in front
          of the insert or copy statements.
      * append: if set (default), the statements are appended to the output
          file instead of overwriting it.
      * inserts: controls if insert statements (more explicit control naming
          all columns) or copy statements (more compact, ordered by id,
          diff-friendly) are generated.
    '''
    if schema is not None:
        table = schema+'.'+table

    fh = open(fname, 'ab' if append else 'wb')

    if truncate:
        fh.write('delete from {};\n'.format(table))
        fh.flush()
    opts = dbargs_to_options(dbargs)

    if inserts:
        cmd = ['pg_dump', '--column-inserts', '--data-only', '--table', table]
    else:
        fh.write((u"COPY %s FROM STDIN;\n" % table).encode('utf-8'))
        fh.flush()
        cmd = ['psql',
               '--command',
               "copy (select * from {table} order by {table}_id) to stdout"
               .format(table=table)
               ]
    cmd.extend(opts)
    c = subprocess.Popen(cmd, stdout=fh)
    c.wait()
    if not inserts:
        fh.write(u"\\.\n".encode('utf-8'))
    fh.close()


def db_dump_schema(fname, database, dbargs=None, opts=None):
    '''
    Dump the schema of a database to a file. Accepts either dbargs or directly
    opts.
    '''
    if opts is None:
        opts = dbargs_to_options(dbargs)
    subprocess.call(
        ['pg_dump',
         '--schema-only',
         '--file', fname,
         ] + opts
    )


def db_restore(infile, connstr=DEFAULT_CONNSTR):
    assert hasattr(infile, 'read'), "Needs a file-like object"
    origname = infile.filename.rsplit('/', 1)[-1]
    assert origname in ('dump.sql', 'dump.sql.gz'), "Invalid file name."

    tdir = tempfile.mkdtemp()
    fname = tdir + '/' + origname
    fh = open(fname, 'wb')
    while True:
        data = infile.read(65536)
        if not data:
            break
        fh.write(data)
    fh.close()

    if fname.endswith('.gz'):
        safe_syscall(['gunzip', fname], raisemode=True)
        fname = fname[:-3]

    dbargs = connstr_to_dbargs(connstr)
    opts = dbargs_to_options(dbargs)
    cmd = ['psql', '--single-transaction', '--file', fname]
    cmd = cmd + opts
    return safe_syscall(cmd, raisemode=True)


def git_snapshot(config, connstr=DEFAULT_CONNSTR):
    '''
    Create a git snapshot of schemata and tables configured in config.
    config should be a namespace containing the following names:
    * base_dir: the path to the git repo
    * subdir (default: __psql__): subdir used in base_dir. May be empty.
    * databases: a list of databases
    * db_tables: a dict mapping each database to a list of tables
    For each database, the schema as well as the listed tables are dumped.
    Afterwards, a git commit is performed.
    '''
    basedir = config.base_dir

    # if not set, subdir is __psql__, for backward compatibility (the same
    # config can be used as with zoperecord
    # Newer configs set subdir to ''
    subdir = getattr(config, 'subdir', '__psql__')
    if subdir:
        basedir = basedir + '/' + subdir

    try:
        os.stat(basedir)
    except OSError:
        print('Will create new directory %s' % basedir)
        os.makedirs(basedir)

    dbargs = connstr_to_dbargs(connstr)
    opts = dbargs_to_options(dbargs)
    for database in config.databases:
        print('Will dump database schema for %s' % database)
        db_dump_schema(
            fname='{basedir}/schema-{database}.sql'.format(
                basedir=basedir,
                database=database
            ),
            database=database,
            opts=opts
        )

        path = basedir+'/data-'+database
        try:
            os.stat(path)
        except OSError:
            print('Will create new directory %s' % path)
            os.makedirs(path)

        for table in config.db_tables.get(database, []):
            print('Will dump database table %s / %s' % (database, table))
            db_dump_table(
                fname=path+'/'+table+'.sql',
                dbargs=dbargs,
                table=table,
                truncate=False,
                append=False,
                inserts=False,
            )
    perfact.pfcodechg.git_snapshot(
        directory=config.base_dir,
        commit_message=config.commit_message,
        subdir=subdir
    )


# Testing
if __name__ == '__main__':
    import doctest
    doctest.testmod()
