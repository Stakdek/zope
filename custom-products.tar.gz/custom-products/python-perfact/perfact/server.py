#!/usr/bin/env python
#
# server.py  -  Utilities for inspection and service
#
# $Revision$
#
# Copyright (C) 2015 Jan Jockusch <jan.jockusch@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
# $Id$

from perfact.generic import safe_syscall


# Phone home activation, deactivation and status

ph_cmd = '/opt/perfact/phonehome/bin/phonehome'

def phonehome_status():
    retcode, output = safe_syscall([ph_cmd, 'status'])
    return retcode, output

def phonehome_up(num=1):
    retcode, output = safe_syscall([ph_cmd, 'up', str(num)])
    return phonehome_status()

def phonehome_down():
    retcode, output = safe_syscall([ph_cmd, 'down'])
    return phonehome_status()



# Printer status

def status_lpstat():
    return safe_syscall('lpstat -p -o')

def status_lpcancel(id=None):
    if id is None:
        return safe_syscall('cancel -a')
    else:
        return safe_syscall('cancel %d' % int(id))

def status_lpinspect(id, page=1):
    filename = '/var/spool/cups/d%05d-%03d' % (int(id), int(page))
    return safe_syscall(['cat', filename])

def status_lpenable(printer):
    return safe_syscall(['cupsenable', str(printer)])

def status_lpdisable(printer):
    return safe_syscall(['cupsdisable', str(printer)])


# Process listing

def status_top():
    return safe_syscall('top -n1 -b')

def status_process(pid, cmd=None):
    '''Check for the presence of the given PID, returning the command line
    if it matches cmd or cmd is None.

    If the process is not found or does not match the cmd, return
    None.

    '''
    try:
        f = open('/proc/%d/cmdline' % int(pid), 'r')
    except:
        return None
    cmdline = f.read().strip()
    f.close()
    if cmd is None or cmdline.find(cmd) != -1:
        return cmdline
    return None


def status_killproc(pid, signal=15):
    retcode, output = safe_syscall(['/usr/local/bin/kill',
                                    '-%d' % signal, '%d' % pid])
    # time.sleep(0.5)
    return retcode, output


# Service restarting

def service_restart(service):
    if service not in ('zope2.13', 'xmitd', 'dbcached', 'sampled'):
        raise ValueError("Invalid service given.")
    return safe_syscall(['sudo', '/usr/sbin/service',
                         service, 'restart'])

# Mail status

def status_postqueue():
    return safe_syscall(['postqueue','-p'])

def status_postqueue_flush():
    return safe_syscall(['postqueue','-f'])

def status_postqueue_cancel(id):
    return safe_syscall(['sudo', 'postsuper', '-d', str(id)])

def status_postqueue_inspect(id):
    return safe_syscall(['sudo', 'postcat', '-q', str(id)])

def status_postqueue_fwclose():
    return safe_syscall(['sudo', '/opt/perfact/zope_tools/outgoing_mail_fw.sh', 'start'])
    # return safe_syscall(['postsuper', '-H', str(id)])

def status_postqueue_fwopen():
    return safe_syscall(['sudo', '/opt/perfact/zope_tools/outgoing_mail_fw.sh', 'stop'])

def status_postqueue_fwstatus():
    return safe_syscall(['sudo', '/opt/perfact/zope_tools/outgoing_mail_fw.sh', 'status'])


# Firewall
def status_firewall(host='127.0.0.1', raisemode=False):
    '''Read out the status of the firwall on a given host.
    Returns a nested dictionary whos first level contains only one key/value
    pair with key 'iptables'. Second level has a key for every builtin iptables
    table.
    e.g.: {'iptables': {'filter': '...', 'nat': '...', 'mangle': '...'}}
    The values are the outputs of the 'iptables' command issued on a CLI.
    '''
    from perfact.firewall import firewall_control
    fwstruct = {u'command': None,
                u'fwstruct': {'iptables': {}},
                u'outformat': 'iptables'
    }
    retcode = 0
    output = ''

    try:
        output = firewall_control(host=host, fwstruct=fwstruct)
    except Exception as e:
        if raisemode: raise
        retcode = 1
        output = e
    return retcode, output

# Disk stats

def status_disks():
    return safe_syscall('df -h')


# Network stats

def status_netaddr():
    return safe_syscall('ip addr show')

def status_netroute():
    return safe_syscall('ip route show')



# Package versions

def status_pkgversion(package):
    return safe_syscall(['dpkg-query', '--showformat=${Version}', '--show', package])

def status_osversion():
    return safe_syscall(['cat', '/etc/lsb-release'])


# Local server monit page

def status_monit():
    return safe_syscall(['curl', '-s', 'http://localhost:2812'])

# Load balancer status

def status_balancer():
    return safe_syscall(['curl', '-s', 'http://localhost:8980/balancer-manager'])
