select 'hätte, könnte, wöllte' as with_umlauts
