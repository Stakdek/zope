update file set
  file_size = %(size)s
where
  file_id = %(id)s
returning file_id
  
