select
  file_id,
  file_filename,
  file_mimetype,
  file_data

from file

where
  (%(id)s is not null and
      file_id = %(id)s
  ) or
  (%(id)s is null and
    (file_checksum is null or
     file_text is null or
     file_tags is null or
     file_thumb is null)
  )

order by file_id
