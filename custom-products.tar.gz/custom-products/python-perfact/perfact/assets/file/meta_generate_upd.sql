update file set
  file_checksum = %(checksum)s,
  file_tags = %(tags)s,
  file_text = %(text)s,
  file_thumb = E%(thumb)s::bytea

where
  file_id = %(id)s
