insert into file (
  file_author,
  file_creator,
  file_caption,
  file_filename,
  file_mimetype,
  file_data
) values (
  %(username)s,
  %(username)s,
  %(caption)s,
  %(filename)s,
  %(mimetype)s,
  nullif(E%(bindata)s::bytea, ''::bytea)
)

returning file_id
	     
