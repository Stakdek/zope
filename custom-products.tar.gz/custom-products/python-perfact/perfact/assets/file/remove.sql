delete from file
where file_id = %(id)s
