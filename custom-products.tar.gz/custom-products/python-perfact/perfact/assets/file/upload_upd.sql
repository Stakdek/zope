update file set

 file_author   = coalesce(%(username)s, file_author),
 file_modtime  = now(),
 file_caption  = coalesce(%(caption)s, file_caption),
 file_filename = coalesce(%(filename)s, file_filename),
 file_mimetype = %(mimetype)s,
 file_bytes    = nullif(E%(bindata)s::bytea, ''::bytea),
 file_text     = null,
 file_thumb    = null,
 file_tags     = null

where
 file_id = %(id)s
 
returning file_id
 
