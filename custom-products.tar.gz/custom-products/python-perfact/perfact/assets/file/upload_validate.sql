select
  filestatus_editable as editable

from file

join filestatus
  on filestatus_id = file_filestatus_id

where file_id = %(id)s
