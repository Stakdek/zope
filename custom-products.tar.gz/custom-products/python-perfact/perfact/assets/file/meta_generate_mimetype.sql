update file set
  file_mimetype = %(mimetype)s
where
  file_id = %(id)s
