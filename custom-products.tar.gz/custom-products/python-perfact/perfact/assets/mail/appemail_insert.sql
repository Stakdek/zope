insert into appemail (
  appemail_author,
  appemail_creator,
  appemail_subject,
  appemail_sender,
  appemail_receiver,
  appemail_cc,
  appemail_bcc,
  appemail_headers
) values (
  %(username)s,
  %(username)s,
  %(subject)s,
  %(sender)s,
  %(receiver)s,
  %(cc)s,
  %(bcc)s,
  %(headers)s
)

returning appemail_id
