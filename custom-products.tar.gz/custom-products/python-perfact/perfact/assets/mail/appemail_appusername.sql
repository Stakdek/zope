select appuser_name
from appuser
where appuser_email = %(sender)s
