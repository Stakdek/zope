insert into appemailxfile (
  appemailxfile_author,
  appemailxfile_appemail_id,
  appemailxfile_file_id
) values (
  %(username)s,
  %(appemail_id)s,
  %(file_id)s
)

returning appemailxfile_id
