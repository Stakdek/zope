update appemail set
  appemail_body = %(body)s

where appemail_id = %(id)s
