#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# network.py  -  Tools for networking, among others for Steute gateways
#
# $Revision: 1.0 $
#
# Copyright (C) 2015 PerFact Innovation GmbH & Co. KG <info@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#


import socket
import ipaddress
import unittest

# Generic tools

def get_netmask(ipaddr):
    '''Extract the netmask from CIDR notation.

    >>> get_netmask('192.168.42.23')
    u'255.255.255.255'
    >>> get_netmask('172.16.0.0/12')
    u'255.240.0.0'
    '''
    net_obj = ipaddress.ip_network(unicode(ipaddr))
    return unicode(net_obj.netmask)


# Tools for Steute gateways follow:


def udpBroadcast(portnum, message, runs=10, bufsize=1024):
    '''Send a UPD broadcast with the given message to the given portnum
    and collect the responses'''
    responses = {}
    # create the socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, True)
    # sockets waits blocked for 5sec when receiving
    s.settimeout(5)

    s.sendto(message, ("<broadcast>", portnum))
    # receive loop collecting responses
    for i in range(runs):
        try:
            yield s.recvfrom(bufsize)
        except socket.timeout:
            break
    s.close()

### WARNING: the functions below will no longer work since udpBroadcast() has
# changed its behavior. They are no longer used and only are kept for compatibility
def findDCGatewaysS(runs=10):
    ''' Discovers .steute sWave Gateways via UDP broadcast '''
    res = udpBroadcast(portnum=55444, message='Discovery: Who is out there?', runs=runs)
    print("Res: %s" % (res))
    gateways = []
    for ip in res:
        parts = res[ip].split("'")
        if (res[ip].startswith(".steute sWave NET Gateway") or res[ip].startswith(".steute sWave NET Access Point")) and len(parts) > 1:
            gateways.append({'ip':ip[0],'name':parts[1]})
    return gateways

#### TEST ####


class BroadCastTestCase(unittest.TestCase):

    def test_noserver(self):
        ''' What does the broadcast, when there is no server '''
        port = 5555
        result = udpBroadcast(port, 'testmessage', 2)
        self.assertEqual(result,{})

    def test_withserver(self):
        ''' What does the broadcast, when there is a server '''
        port = 5555

        import threading
        from SocketServer import UDPServer, BaseRequestHandler
        
        class TestHandler(BaseRequestHandler):
            ''' Handler for the UDP-Server '''
            def handle(self):
                socket = self.request[1]
                socket.sendto("unittestresponse", self.client_address)
        # create Server with our handler
        server = UDPServer(("",port), TestHandler)
        # start the server in thread
        server_thread = threading.Thread(target=server.serve_forever)
        server_thread.start()
        # make the broadcast
        result = udpBroadcast(port, 'testmessage', 2)
        # tear down the server
        server.shutdown()
        server.server_close()
        resulttexts = result.values()
        # there should be the answer from our server in the responses
        self.assertIn('unittestresponse',resulttexts,'No answer from local server')

    def test_findDGatewaysS_without(self):
        ''' What does the discovery do when there are no gateways, when there is no server '''
        result = findDCGatewaysS(2)
        self.assertEqual(result,[])

    def test_findDCGatewaysS_with(self):
        ''' What does the broadcast, when there is a server '''
        port = 55444

        import threading
        from SocketServer import UDPServer, BaseRequestHandler
        
        class TestHandlerGateWays(BaseRequestHandler):
            ''' Handler for the UDP-Server '''
            def handle(self):
                socket = self.request[1]
                socket.sendto(".steute sWave NET Gateway 'aName'", self.client_address)
        # create Server with our handler
        server = UDPServer(("",port), TestHandlerGateWays)
        # start the server in thread
        server_thread = threading.Thread(target=server.serve_forever)
        server_thread.start()
        # make the broadcast
        result = findDCGatewaysS(2)
        # tear down the server
        server.shutdown()
        server.server_close()
        weHaveOne = len(result) > 0
        self.assertTrue(weHaveOne, 'No Gateway found')
        self.assertEqual('aName',result[0]['name'])
