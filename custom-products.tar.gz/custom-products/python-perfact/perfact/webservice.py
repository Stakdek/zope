#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# webservice.py  -  Tools for webservices
#
# $Revision: 1.0 $
#
# Copyright (C) 2016 PerFact Innovation GmbH & Co. KG <info@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import requests
import re
import xml.parsers.expat


def credentialsFromUrl(url):
    ''' extracts a tuple of (username,password) from a url '''
    m = re.match(r"^https?://(.+):(.+)@", url)
    if m:
        return (m.group(1), m.group(2))
    else:
        return None


def removeCredentialsFromUrl(url):
    ''' return the given url without credentials '''
    return re.sub(r'://.+:.+@', '://', url)


# Session Handling
def createSession(login_url, login_data):
    ses = requests.Session()
    res = ses.post(login_url, login_data)
    if res.status_code != requests.codes.ok:
        raise Exception(
            'Login failed with Status Code {}'.format(res.status_code))
    return ses


def closeSession(session, logout_url):
    session.post(logout_url)


def sessionEnabled(func):
    ''' Decorator for session handling'''
    def deco(*args, **kwargs):
        if ('login_url' in kwargs) and ('login_data' in kwargs):
            ses = createSession(login_url=kwargs['login_url'],
                                login_data=kwargs['login_data'])
            kwargs['session'] = ses
            res = func(*args, **kwargs)
            if ('logout_url' in kwargs):
                closeSession(session=ses,
                             logout_url=kwargs['logout_url'])
        else:
            res = func(*args, **kwargs)
        return res
    return deco


# Authentication Method
authclassMapping = {
    'basic': requests.auth.HTTPBasicAuth,
    'digest': requests.auth.HTTPDigestAuth
}


def authtypeChoosable(func):
    ''' Decorator for choosing the authtype.
    basic and digest are possible values '''
    def deco(*args, **kwargs):
        if ('authtype' in kwargs) and ('auth' in kwargs):
            authclass = authclassMapping.get(kwargs['authtype'], None)
            if authclass is None:
                raise Exception('Unknown Authtype %s' % kwargs['authtype'])
            kwargs['auth'] = authclass(kwargs['auth'][0], kwargs['auth'][1])
        return func(*args, **kwargs)
    return deco


@authtypeChoosable
@sessionEnabled
def getWS(url, headers=None, params=None, auth=None,
          session=requests, **kwargs):
    '''
    sends a GET request
    params is a dict that gets encoded in the url
    auth is a tuple like ('user','password')
    '''
    res = session.get(url=url, headers=headers, params=params, auth=auth)
    return res


@authtypeChoosable
@sessionEnabled
def getJSON(url, headers=None, params=None, auth=None,
            session=requests, **kwargs):
    '''
    sends a GET request
    params is a dict that gets encoded in the url
    auth is a tuple like ('user','password')
    assumes json output from the ws
    returns a dict
    '''
    res = getWS(url=url, headers=headers, params=params,
                auth=auth, session=session)
    try:
        data = res.json()
    except Exception:
        # TODO: This is not a friendly error. Wrap JSON error more clearly.
        raise ValueError(
            'Could not decode response. Try getText to see whats going on')
    return data


@authtypeChoosable
@sessionEnabled
def getXML(url, headers=None, params=None, auth=None,
           session=requests, **kwargs):
    '''
    sends a GET request
    params is a dict that gets encoded in the url
    auth is a tuple like ('user','password')
    assumes XML output from the ws
    returns a dict
    '''
    res = getWS(url=url, headers=headers, params=params,
                auth=auth, session=session)
    try:
        p = GenericXML(ignore_attrs=False)
        data = p.parse(res.text)
        del p
    except Exception:
        # TODO: Not a friendly error message. Wrap XML error more clearly.
        raise ValueError(
            'Could not decode response. Try getText to see whats going on')
    return data


@authtypeChoosable
@sessionEnabled
def getText(url, headers=None, params=None, auth=None,
            session=requests, **kwargs):
    '''
    sends a GET request
    params is a dict that gets encoded in the url
    auth is a tuple like ('user','password')
    returns a text from the ws
    '''
    res = getWS(url=url, headers=headers, params=params,
                auth=auth, session=session)
    return res.text


@authtypeChoosable
@sessionEnabled
def postWS(url, headers=None, data=None, json=None, auth=None,
           session=requests, **kwargs):
    '''
    sends a POST request
    data is a dict that gets form-encoded or a string that is send as it is
    json is a dict that gets json-encoded as an alternative to data
    auth is a tuple like ('user','password')
    '''
    res = session.post(url=url, headers=headers, data=data,
                       auth=auth, verify=False)
    if res.status_code != requests.codes.ok:
        raise Exception('Server returned status {0}: {1}'.format(
            res.status_code, res.text))
    else:
        return {
            'status': res.status_code,
            'data': res.text,
            'object': res
        }


# SOAP

class GenericXML:
    '''Build a parser for simple hierarchical dictionaries.
    no attributes are allowed.
    an element contains either data or other elements.
    residual data is in the 'data' dictionary element.
    '''

    def __init__(self, encoding='utf-8', delete_ns=True,
                 strip_spaces=True, ignore_attrs=True):
        # Set this to the desired encoding.
        self.enc = encoding
        self.del_ns = delete_ns
        self.strip_spaces = strip_spaces
        self.ignore_attrs = ignore_attrs

        self.p = xml.parsers.expat.ParserCreate()
        self.p.StartElementHandler = self.start_element
        self.p.EndElementHandler = self.end_element
        self.p.CharacterDataHandler = self.char_data
        self.p.buffer_text = True
        return

    def parse(self, data):
        '''Send data through parser and return finished dictionary.
        '''
        # Element stack is initialized with the root dictionary.
        self.stack = [('', {})]
        self.p.Parse(data, 1)
        return self.stack[0][1]

    def start_element(self, name, attrs):
        '''Push a new element on the stack and start
        its sub-dictionary.
        '''
        name = name.encode(self.enc)
        if self.del_ns:
            name = name.rsplit(':', 1)[-1]

        d = {}                       # new dictionary

        if attrs and not self.ignore_attrs:
            d['__attrs__'] = attrs

        if name not in self.stack[-1][1]:
            self.stack[-1][1][name] = []
        if not isinstance(self.stack[-1][1][name], list):
                # Something nasty happened: a tag containing only data has
                # been repeated!
                # We ignore such mistakes by pushing the tag onto the
                # validation stack
                self.stack.append((name, {'__ignore__': ''}))
                return
        self.stack[-1][1][name].append(d)  # add new dictionary to parent
        self.stack.append((name, d))  # push reference on stack.
        return

    def end_element(self, name):
        '''Pop the named element, checking for character contents.
        '''
        name = name.encode(self.enc)
        if self.del_ns:
            name = name.rsplit(':', 1)[-1]

        e = self.stack.pop()
        assert e[0] == name, "Closing tag does not match opening tag!"
        d = e[1]  # validate popped dictionary (reference!)
        if '__ignore__' in d:
            # Emergency measure for broken XML
            return
        if not d:
            del self.stack[-1][1][name]
        if len(d.keys()) == 1 and d.keys()[0] == '__data__':
            # only '__data__' present: replace with contents
            self.stack[-1][1][name] = d['__data__']
        return

    def char_data(self, data):
        '''Add a '__data__' entry to the dictionary.
        '''
        # val = data.strip().encode(self.enc)
        # val = data.encode(self.enc)
        val = data
        if self.strip_spaces:
            val = val.strip()
        if not val:
            return
        d = self.stack[-1][1]
        if '__data__' in d:
            d['__data__'] += val
        else:
            d['__data__'] = val
        return


def translate_xml(data, delete_ns=False,
                  strip_spaces=True,
                  add_attributes=False):
    '''Simple dictionary translator.'''
    p = GenericXML(delete_ns=delete_ns, strip_spaces=strip_spaces,
                   ignore_attrs=not add_attributes)
    d = p.parse(data)
    del p
    return d


def soapConvertTo12(msg):
    ''' replace a 1.1 envelope namespace with a 1.2 envelope namespace '''
    return msg.replace('http://schemas.xmlsoap.org/soap/envelope/',
                       'http://www.w3.org/2003/05/soap-envelope')


def soapConvertTo11(msg):
    ''' replace a 1.2 envelope namespace with a 1.1 envelope namespace '''
    return msg.replace('http://www.w3.org/2003/05/soap-envelope',
                       'http://schemas.xmlsoap.org/soap/envelope/')


soap_version_converter = {
    '1.1': soapConvertTo11,
    '1.2': soapConvertTo12
}


def call_soapservice(msg, endpoint, soapaction=None, add_headers=None,
                     credentials=None, version='1.2'):
    ''' cleaner replacement for the old generic call'''
    if add_headers is None:
        add_headers = {}
    if credentials is None:
        credentials = credentialsFromUrl(endpoint)
        # TODO: removeCredentialsFromUrl
    if type(credentials) is dict:
        credentials = (credentials['username'], credentials['password'])

    assert version in ['1.1', '1.2'], "Unrecognized version string"

    msg = soap_version_converter[version](msg)

    header_sets = {
        '1.1': {
            'Content-Type': 'text/xml; charset=utf-8',
            'SOAPAction': '""'
        },
        '1.2': {
            'Content-Type': 'application/soap+xml; charset=utf-8'
        },
    }

    # Augment and quote the headers
    my_headers = header_sets[version]
    my_headers.update(add_headers)

    # Perform the query
    data = postWS(url=endpoint, headers=my_headers, data=msg, json=None,
                  auth=credentials, session=requests)['object']

    data.encoding = 'utf-8'
    data = data.text.encode('utf-8', 'replace')

    if not data:
        # TODO: Error message in German. Needed?
        raise AssertionError(
            "Keine Daten erhalten. Server hat nicht geantwortet.")

    # Unpack XML
    p = GenericXML()
    d = p.parse(data)
    del p

    return d
