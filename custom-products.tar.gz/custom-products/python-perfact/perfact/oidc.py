#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# oidc.py  -  OpenID Connect methods
#
# Copyright (C) 2017 PerFact Innovation GmbH & Co.KG  <info@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

import base64
# PyJWT
import jwt
import requests
import urllib

# For Testing
import unittest

# PerFact specific
from perfact.generic import generate_random_string, json_encode, json_decode

def postReq(url, data=None, auth=None, verify=True, headers=None, \
            *args, **kwargs):
    """
    Issue an HTTP POST request using the 'requests' module and return the
    answer to the caller.
    """
    res = requests.post(url=url,
                        data=data,
                        auth=auth,
                        verify=verify,
                        headers=headers,
                        *args, **kwargs
    )
    return res

def getReq(url, verify=True):
    """
    Issue an HTTP GET request using the 'requests' module and return the 
    answer to the caller.
    """
    res = requests.get(url=url, verify=verify)
    return res

def passwordTokenReq(url, username, password, client_id, client_secret=None, \
             scope=None, *args, **kwargs):
    """
    Use the OIDC grant type 'password' to aquire an access_token from the
    OpenID Provider (OP).
    
    :client_secret (optional)

    :scope (optional)
    """
    params = {'grant_type': 'password',
              'username': username,
              'password': password,
              'client_id': client_id,
              'client_secret': client_secret,
              'scope': scope}
    res = postReq(url=url,
                  data=params,
                  *args,
                  **kwargs)
    status_code = res.status_code
    txt = res.text
    try:
        json = res.json()
    except:
        json = None
    return {'text': txt,
            'json': json,
            'status_code': status_code,
    }
    return res

def authReq(url, client_id, client_secret, auth_code, redirect_uri, \
            verify=True, *args, **kwargs):
    '''
    Query the backend OpenID-Connect Provider (OP) to receive information about
    the login process.

    :url
    token endpoint address
    
    :client_id
    username
    
    :client_secret
    password
    
    :auth_code 
    authorization code which was given to us on the frontchannel
    
    :redirect_uri
    address for redirection which was given to us on the frontchannel

    :*args
    will just be passed to the postReq function 

    :**kwargs
    will just be passed to the postReq function  
    '''
    # request to backend
    data = {'grant_type':'authorization_code',
            'code':auth_code,
            'redirect_uri':redirect_uri}
    # prepare the authentication against the server
    # the requests library takes care of converting that to HTTP Basic auth
    # using base64 encoding of username:password
    auth = (client_id, client_secret)
    res = postReq(url=url, data=data, auth=auth, verify=verify,
                  *args, **kwargs)
    status_code = res.status_code
    txt = res.text
    try:
        json = res.json()
    except:
        json = None
    return {'text': txt,
            'json': json,
            'status_code': status_code,
    }

def jwkToPubKeyObj(keystring):
    '''
    The JWT library requires to pass a specific public key object
    which can be derived from a json string (JWT) like:

    {"kid":"QYVpNfd-JydP-p5JhOf3vzB9QfHzp8l0LrOLpXH1Zms",
     "kty":"RSA","alg":"RS256","use":"sig",
     "n":"g5zWXNIbDORmfPK2t6e-yQ3vIG2K7TOg4su0yiWzs0esJaiiYHLsToQWIAqGskNh\
     6JHbpo-cPQyN96lLyCSBaP9YESJ8ikZLj43g9Ue4jv4GCA2b_B90sULGkRFHd3TLPCoW1\
     dEU3BOD2V54OOo5rwwUHkaeFBDPwst27Xwye94oarDy3BQHIRDuP_nd3Pj7lwVzLqkyGP\
     FCXmTGPGfHSohW82tCbKNVqGvQTfNBrBu0we6KC6EYAszvypmbzRuhXkQitCb4-IELhcA\
     ZoZ7EQXcLSwo75O8uzfBtZbH77mJb_6YyeNmThiHxeK8xJXPJymsrB2vpa0sggkB_O2Qjiw",
     "e":"AQAB"}
    '''
    keyobj = jwt.algorithms.RSAAlgorithm.from_jwk(keystring)
    return keyobj

def parseJwt(jwtobj, key=None, verify=True, audience=None, options=None):
    '''
    Parse/read values from a received JWT (Java Web Token).
    '''
    if key:
        if type(key) == str and key.startswith('{'):
            # likely a json string which needs to be converted
            key = jwkToPubKeyObj(key)
            
        # try to verify the signature
        id_token = jwt.decode(jwt=jwtobj, key=key, verify=verify,
                              options=options, audience=audience)
    else:
        id_token = jwt.decode(jwt=jwtobj, verify=verify, options=options)
    return id_token

def createJwt(id_token, key=None, alg='RS256'):
    '''
    ONLY FOR TESTING!
    Creat a JWT (Java Web Token) from a dictionary, a key and optional
    signature algorithm.

    :iss
    issuer of the token e.g. the endpoint URL

    :sub
    subject of the token (user ID or name)

    :aud
    audience that the token is intended for
    for decoding the audience must be in the list of expected/accepted audiences

    :nonce
    number only used once - random value which *must* not be reused 

    :exp
    expiry timestamp in seconds (epoch timestamp)

    :iat
    issue timestamp in seconds (epoch timestamp)

    :algorithm
    RS256 - RSA Signature with SHA-256 (private/public keys needed)
    HS256 - HMAC with SHA-256

    :id_token
    dictionary e.g.
    {"iss": "https://server.example.com",
      "sub": "testuser",
      "aud": "some-value",
      "nonce": "xjs8Yu0-2",
      "exp": 2147382000,
      "iat": 1507212328,
    }
    '''
    if alg == 'HS256' and not key:
        raise AssertionError('A key is needed to calculate the digest')

    encoded = jwt.encode(payload=id_token,
                         key=key,
                         algorithm=alg)
    return encoded


def authRedir(client_id, auth_uri, redirect_uri,
              response_type='code', scope='openid',
              state=None, statelen=128, nonce=None):
    '''
    Generate a URL to send the client to the OpenID-Connect login page.
    --Input--
    :client_id
    unique identifier of this Relying Party
    
    :auth_uri
    URL for authentication requests at the OpenID-Provider server

    :redirect_uri
    Optional URL where the OpenID-Provider will redirect to

    :response_type
    should be 'code'

    :scope
    should be 'openid'

    :state
    optional random value, will be created if None is given
    - 'statelen' length of the state if it should be created
    - 'nonce' optional number used only once

    --Output--
    :target_url
    holds a URL including all parameters needed for an OpenID-Connect process

    :state
    represents a kind of csrf token to uniquely identify this login process
    '''
    if not state:
        state = generate_random_string(length=statelen, mode='normal')
    params = {'client_id': client_id,
              'state': state,
              'response_type': response_type,
              'scope': scope,
              'redirect_uri': redirect_uri,
    }
    if nonce:
        params['nonce'] = nonce

    target_url = auth_uri + '?' + urllib.urlencode(params)

    return target_url, state


def userInfoReq(url, access_token, verify=True, *args, **kwargs):
    '''
    Request additional user information from the OpenID Provider
    using the bearer token for authentication.
    
    :url
    Endpoint for request

    :access_token
    Bearer token from previous request in OIDC context

    :verify
    Indicates if the server certificate should be verified

    :*args
    will just be passed to the postReq function 

    :**kwargs
    will just be passed to the postReq function 
    '''
    headers = {'Authorization': 'Bearer ' + access_token }
    res = postReq(url=url, headers=headers, verify=verify, *args, **kwargs)
    status_code = res.status_code
    txt = res.text
    try:
        json = res.json()
    except:
        json = None
    return {'text': txt,
            'json': json,
            'status_code': status_code,
    }    

def parseAuthResp(resp, aud=None, key=None, verify=True):
    '''
    Parse the response of an OpenID-Connect Authentication request to extract
    useful information from the embedded JWT (Java Web Token)
    --Input--
    :resp
    Dictionary containint the server response (generated by pythons requests lib)

    :aud 
    String containing the expected audience a.k.a the OpenID client_id of the RP
    
    :verify
    Boolean to control the verification of the JWT

    --Output--
    A dictionary containing the following keys
    :msg
    An informational message

    :status_code
    The HTTP status code of the response

    :text
    Embedded HTML of the response
    
    :id_token
    Dictionary which contains the results of the parsed JWT
    '''
    result = {'msg': None,
              'status_code': resp.get('status_code'),
              'text': resp.get('text'),
              'err': 0,
              }
    if resp.get('status_code') != requests.codes.ok:
        result['msg'] = 'The server returned an error'
        result['err'] = 6
        return result

    if not resp['json']:
        result['msg'] = 'No json in the returned response from the OpenID Provider'
        result['err'] = 1
        return result
    
    # decode the json and filter out the 'id_token' and so on...
    if not isinstance(resp['json'], dict):
        result['msg'] = 'The returned json is empty'
        result['err'] = 2
        return result

    # h19t1...sJy (random value)
    result['access_token'] = resp['json'].get('access_token')

    # 7199 (seconds?)
    result['expires_in'] = resp['json'].get('expires_in')

    # e.g. 'Bearer'
    result['token_type'] = resp['json'].get('token_type')

    # e.g. 'openid'
    result['scope'] = resp['json'].get('scope')

    # V0m....Fha (random value)
    result['refresh_token'] = resp['json'].get('refresh_token')

    # JWT - java web token
    jwt = resp['json'].get('id_token')
    
    if not jwt:
        result['msg'] = 'No id_token a.k.a JWT was found in the JSON structure'
        result['err'] = 3
        return result

    # extract the information (claims) from the JWT (JSON web token)
    # Signature verification - how? with which key?
    #options = {'verify_aud': True}
    options = None
    try:
        id_token = parseJwt(jwt, key=key, verify=verify,
                            options=options, audience=aud)
    except Exception as err:
        result['msg'] = 'JWT could not be parsed/validated' \
                        ' The reason was: %s' % \
                        (str(err))
        result['err'] = 5
        return result

    if not len(id_token.keys()):
        result['msg'] = 'The id_token a.k.a JWT did not contain any information'
        result['err'] = 4

    # The id_token can hold the following keys
    # for reference see: http://openid.net/specs/openid-connect-core-1_0.html#StandardClaims
    #
    # sub                - username e.g. perfacttest1@example.com
    # aud                - audience, must be the OpenID client_id
    # realm_name         - LdapRegistry (optional)
    # iss                - issuer e.g. https://openid.example.com/oidc/endpoint/foo
    # uniqueSecurityName - uid=perfacttest1@example.com,ou=undefined,ou=clients,dc=example,dc=com
    # at_hash            - i6PU...g1A (random value?)
    # groupIds           - [u'cn=serviceconsumer,ou=roles,dc=example,dc=com']
    # exp                - expiry timestamp 1509384970 (unix epoch timestamp)
    # iat                - issued at timestamp 1509377770 (unix epoch timestamp)
    result['id_token'] = id_token

    result['err'] = 0
    return result


class localTests(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        print('Test against local http(s) server')
        # start a static http server which serves a jwt
        self.host = 'localhost'
        self.port = 4711
        self.server, \
        self.server_thread = tests.tcpserver.startDynamicServer(host=self.host,
                                                               port=self.port,
                                                               use_ssl=True)
    @classmethod
    def tearDownClass(self):
        # stop the server again
        print('Stopping local http(s) server')
        tests.tcpserver.stopServer(self.server, self.server_thread)
        print('Test against local server done!')

    def test_oidc(self):
        print('>>> Running oidc authentication tests')
        server_base = 'https://%s:%s' % (self.host, self.port)
        auth_uri_path = '/oidc_auth' 
        auth_uri = server_base + auth_uri_path
        redirect_uri = 'https://foo.example.com'
        token_uri_path = '/oidc_token'
        token_uri = server_base + token_uri_path
        userinfo_uri_path = '/oidc_userinfo'
        userinfo_uri = server_base + userinfo_uri_path
        state = generate_random_string(mode='normal', length=128)

        client_id = 'SomeRandomValue'
        client_secret = 'wFI1rznlwiApOhmRT2iD5m40nGTjXmPYEMQZ3Ie61pJorME8ptBM52'

        # do not verify SSL certificates
        verify_ssl = False

        # try to check the signature of JWTs
        verify_jwt = True

        # 1.) 
        # prepare the server and create an URL to access it
        # set the expected parameters for our first call
        expected_params = {'redirect_uri': redirect_uri,
                           'state': state,
                           'client_id': client_id}
        self.server.RequestHandlerClass.expected_params = expected_params
        expected_urls = [auth_uri_path]
        self.server.RequestHandlerClass.expected_urls = expected_urls
    
        # start login process, redirect the user to the OP
        target_url, rec_state = authRedir(auth_uri=auth_uri,
                                          redirect_uri=redirect_uri,
                                          client_id=client_id,
                                          state=state)
        assert target_url.startswith(auth_uri), 'Wrong URL used!'
        assert rec_state == state, 'State differs! Received: %s Expected: %s' % \
            (rec_state, state)

        # 2.)
        # the user is redirected to the OP login page
        # user logs into OpenID-Connect backend server (OP)
        # the redirect page needs to invoke a callback
        # we fake this here and set code and state ourself!

        # edit the expected parameters on the server side
        expected_params['scope'] = 'openid'
        expected_params['response_type'] = 'code'
        self.server.RequestHandlerClass.expected_params = expected_params
        code = '1234567'
        answer = {'code': code,
                   'state': state}
        self.server.RequestHandlerClass.answer = answer

        print('>>> Request to OP for user login')
        res = getReq(url=target_url, verify=verify_ssl)
        assert res.status_code == 200, 'Server gave an error: %s' % res.text
        print(res.status_code)
        print('DEBUG: content: %s' % res.content)
        print('DEBUG: text: %s' % res.text)
        resdict = eval(res.text)
        # we expect a 'code' and the previously given 'state'
        assert resdict['state'] == state, 'State differs! Received: %s Expected: %s' \
            % (resdict['state'], state)
        assert resdict['code'] == code, 'Code differs! Received: %s Expected: %s' % \
            (residct['code'], code)
        
        # 3.)
        # prepare the server
        # allowed expected_urls
        expected_urls = [token_uri_path]
        self.server.RequestHandlerClass.expected_urls = expected_urls

        # expected parameters
        expected_params['code'] = code
        expected_params['grant_type'] = 'authorization_code'
        self.server.RequestHandlerClass.expected_params = expected_params

        # allowed headers
        basic = base64.b64encode(client_id + ':' + client_secret)
        expected_headers = {'Authorization': 'Basic ' + basic}
        self.server.RequestHandlerClass.expected_headers.update(expected_headers)
        
        # preconfigured answer
        jwt_key = '9348235'
        jwt_token = {"iss": server_base,
                     "sub": "testuser",
                     "aud": client_id,
                     "nonce": "xjs8Yu0-2",
                     "exp": 2147483646,
                     "iat": 507212328,
        }
        jwt = createJwt(id_token=jwt_token,
                           key=jwt_key,
                           alg='HS256')
        access_token = 'asdfhasdfsdfljsadf3434sadlfasdf'
        answer = {'id_token': jwt,
                  'access_token': access_token}
        answer = json_encode(answer)
        self.server.RequestHandlerClass.answer = answer

        # we make an request to the OP over our backchannel connection
        print('>>>  request to OP to receive login details')
        res = authReq(url=token_uri,
                      auth_code=code,
                      client_id=client_id,
                      client_secret=client_secret,
                      redirect_uri=redirect_uri,
                      verify=verify_ssl)
        assert res['status_code'] == 200, 'Server gave an error: %s' % res.text
        
        # parse the received data (JWT) and extract useful information
        res = parseAuthResp(res, aud=client_id, key=jwt_key, verify=verify_jwt)
        assert res['id_token'] == jwt_token, 'JWT was altered!'
        assert res['access_token'] == access_token, 'Acess token does not match'            

        # 4.) Request additional user information using the access_token
        expected_headers = {'Authorization':  'Bearer ' + access_token}
        self.server.RequestHandlerClass.expected_headers.update(expected_headers)

        print('>>> Request user info from the OP')
        answer = {'foo': 'bar'}
        answer = json_encode(answer)
        self.server.RequestHandlerClass.answer = answer
        # request additional information about the user (email, names, groups...)
        res = userInfoReq(url=userinfo_uri, access_token=access_token, verify=verify_ssl)
        assert res['status_code'] == 200, 'Server error while requesting user info'
        print(res['text'])

def test_all():
    # For testing
    global tests
    global tcpserver
    import tests.tcpserver
    global base64
    import base64
    global time
    import time
    unittest.main()

if __name__ == '__main__':
    test_all()
