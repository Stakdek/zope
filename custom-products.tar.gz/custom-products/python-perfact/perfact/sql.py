# -*- coding: utf-8 -*-

try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO


# Escapers for data types

def sql_boolean(value=None):
    if value:
        return 'true'
    else:
        return 'false'

def sql_char_list(indexes=None):
    '''Mimick the behaviour of the char_list() aggregate on an index list,
    returning an SQL string.
    '''
    if not indexes: return None
    return ', '.join(indexes)

def sql_date(value=None):
    '''Reverse the German date format into something understandable by SQL.
    TODO: Internationalization is missing here.
    '''
    return sql_datetime(value)

def sql_datetime(value=None):
    '''Reformat a German date into ISO notation, keeping the time part.
    '''
    if not value: return 'null'
    parts = value.split()
    if not len(parts): return 'null'

    value = parts[0]
    value = value.replace(',','.')
    value = value.replace('/','.')
    items = value.split('.')
    if len(items) != 3: return 'null'
    fmt = "%04d-%02d-%02d" % (int(items[2]), int(items[1]), int(items[0]))
    parts[0] = fmt
    return "'"+' '.join(parts)+"'"

def sql_datetimearray(values=None):
    '''Reformat a string of space separeted German dates in an Array of dates
       in ISO notation
    '''
    result = "array["
    if same_type(dates, '') and len(dates)>0:
        entrys=[]

        for date in dates.split():
            date=date.split('.')
            date = sql_datetime(date)
            entrys.append("timestamp '" + date + "'")

        result+=', '.join(entrys)
    return result + "]::timestamp with time zone[]"


def sql_float(value=None):
    if value is None: return 'null'

    value = str(value)
    value = value.replace(',','.') # Usually, we use german commas
    value = value.replace(' ','')  # Thousands separators must go
    # TODO: Accept all kinds of separators
    # TODO: Only leave the last period

    try:    value = float(value)
    except: return 'null'

    return str(float(value))

def sql_int(value=None):
    if value is None: return 'null'

    value = str(value)
    value = value.replace(',','.') # Usually, we use german commas
    value = value.replace(' ','')  # Thousands separators must go
    # TODO: Accept all kinds of separators
    # TODO: Only leave the last period

    try:    value = int(value)
    except: return 'null'

    return str(int(value))

def sql_intarray(indexes=None):
    '''Return null (empty list) or a SQL representation of a bigint array.
    '''
    if get_type(indexes) == 'str':
        indexes = indexes.split()

    if not indexes: return 'null::bigint[]'
    indexes = filter(lambda a: a not in ('', 0), indexes)

    if not indexes: return 'null::bigint[]'

    # Convert to strings
    indexes = map(str, indexes)

    return 'array[' + ', '.join(indexes) + ']::bigint[]'

def sql_interval(value=None):
    '''Very rudimentary escaper, which works essentially like str'''
    return sql_string(value)

def sql_literal(val):
    '''Ensure there's nothing dangerous about a literal.'''
    if not val: raise AssertionError("Empty literal!")

    return str(val).replace(';', '').replace("'", '')

def sql_string(value=None):
    '''Safety escaper for SQL strings.'''
    if not value: return 'null'
    value = str(value)
    return "'"+value.replace("'","''")+"'"

def sql_text(value=None):
    '''A little more complicated than sql_string, can also handle
    backslashes.
    '''
    if not value: return 'null'
    value = value.replace('\r', '')
    value = value.strip()
    value = value.replace('\\', '\\\\')
    value = value.replace("'", "''")
    return "E'" + value + "'"

def sql_texthtml(value=None, html_cleanup=None):
    if not value: return 'null'

    #value = value.replace('\r', '')
    #value = value.strip()

    value = html_cleanup(value)

    value = value.replace('\\', '\\\\')
    value = value.replace("'", "''")
    return "E'" + value + "'"

def sql_time(value=None):
    return sql_string(value)


# Escapers for BLOBs

def esc_text(data):
    '''
    Escape text for use with a postgres backend.
    '''
    out = StringIO()
    for c in data:
        if c == '\\': out.write('\\\\')
        elif c == "'": out.write("\\'")
        elif c == "\r": continue
        elif c == "\n": out.write("\\n")
        elif c == '\000': continue
        else: out.write(c)
    out.seek(0)
    return out.read()

def esc_binary(data, std_string=False):
    '''
    Helper routine which escapes binary data for use
    with a PostgreSQL backend.
    '''
    if data is None: return None
    bs = std_string and '\\' or '\\\\'
    out = StringIO()
    for c in data:
        oc = ord(c)
        if c == '\\': out.write(bs+'134')
        elif c == "'": out.write(bs+'047')
        elif oc < 32 or oc >= 127: out.write(bs+'%03o' % oc)
        else: out.write(c)
    out.seek(0)
    return out.read()

def unesc_binary(data):
    '''
    Backward conversion of binary data which has been
    escaped by PostgreSQL for output.
    '''
    out = StringIO()
    i = 0
    while i < len(data):
        if data[i] == '\\':
            if data[i+1] == '\\':
                out.write(data[i])
                i += 1
            elif data[i+1] in '0123456789':
                out.write(chr(int(data[i+1:i+4], 8)))
                i += 3
        else:
            out.write(data[i])
        i += 1
    out.seek(0)
    return out.read()
