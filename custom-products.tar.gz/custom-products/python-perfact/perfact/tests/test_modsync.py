#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# test_modsync.py  -  Tests perfact.modsync
#
# Copyright (C) 2018 PerFact Innovation GmbH & Co. KG <info@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

import unittest
import perfact.modsync
import tempfile
import os

class modsync_tc(unittest.TestCase):

    def setUp(self):
        self.base_dir = tempfile.mkdtemp()

    def test_schemadump_wrong(self):
        ''' try to dump the schema of a non existing db '''
        modsync = perfact.modsync.zModSync(base_dir=self.base_dir,
                                           server_url='/')
        try:
            modsync.db_schema_dump(dbname='foo')
        except:
            self.assertEqual(1,1)
        else:
            self.assertEqual(1,0,'Ran without raising')
        #for root, dirs, files in os.walk(self.base_dir):
        #    self.assertEqual(len(dirs),0,'Folders generated')
        #    self.assertEqual(len(files),0,'Files generated')
        
    def test_schemadump_default(self):
        ''' dump the schema of the default db '''
        modsync = perfact.modsync.zModSync(base_dir=self.base_dir,
                                           server_url='/')
        modsync.db_schema_dump()
        for root, dirs, files in os.walk(os.path.join(self.base_dir,'__psql__')):
            self.assertEqual(len(dirs),0,'Folders generated')
            self.assertIn('schema-perfactema.sql',files,'No schema file generated')

    def test_table_dump(self):
        ''' dump data from a table '''
        modsync = perfact.modsync.zModSync(base_dir=self.base_dir,
                                           server_url='/',
                                           db_tables = {'perfactema':['appuser']})
        modsync.db_table_dump(dbname='perfactema', tablename='appuser')
        for root, dirs, files in os.walk(os.path.join(self.base_dir,
                                                      '__psql__',
                                                      'data-perfactema')):
            self.assertEqual(len(dirs),0,'Folders generated')
            self.assertIn('appuser.sql',files,'No data file generated')
