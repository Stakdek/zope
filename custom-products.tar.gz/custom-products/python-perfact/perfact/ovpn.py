#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ovpn.py  -  Utilities for connecting via OpenVPN and setup of keys/certs
#
# Copyright (C) 2015 Jan Jockusch <jan.jockusch@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

import os
from perfact.generic import safe_syscall

# suppress informational messages which might interferen with output parsing
# e.g.
#  Warning: Permanently added '127.0.0.1' (ECDSA) to the list of known hosts.
sshopts=' -o LogLevel=ERROR '

def ovpn_kill_conn(ovpnconn_id, proxy="vpnnode1", mode="tun"):
    '''Kill a existing vpn connection.
    By default a "tun" connection is terminated
    '''
    assert_safe_for_bash(proxy)

    cmd = 'ssh %s %s /home/mpaproxy/ovpncommand kill %s %s' \
          % (sshopts, proxy, ovpnconn_id, mode)
    ret, out = safe_syscall(cmd, raisemode=True)
    assert ret == 0, 'Communication with management console failed: %s' % out
    return out

def ovpn_status(proxy="vpnnode1", mode="tun", version=1):
    '''Retreive ovpn server process internal state table showing connected
    clients, routing information and statistics.
    By default the status version mode 1 is choosen
    '''
    assert_safe_for_bash(proxy)

    cmd = 'ssh %s %s /home/mpaproxy/ovpncommand status %s %s' \
          % (sshopts, proxy, version, mode)
    ret, out = safe_syscall(cmd, raisemode=True)
    assert ret == 0, 'Communication with management console failed: %s' % out
    return out

def ovpn_status_parse(status, version=1):
    '''Parse the output of the openvpn server management consoles status command
    Get a list of connected clients.
    '''
    results = {'clients': []}
    if version == 1:
        # version 1 is a <lf> and comma separated table
        raw_clients, raw_routes = status.split('ROUTING TABLE')
        # get rid of table header
        # ['OpenVPN CLIENT LIST',
        # 'Updated,Fri Jan  5 12:37:02 2018',
        # 'Common Name,Real Address,Bytes Received,Bytes Sent,Connected Since',
        # 'valuable data...'...]  
        client_lines = raw_clients.strip().split('\n')[3:]
        clients = []
        for line in client_lines:
            id = line[0:line.find(',')]
            if id.lower().startswith('undef'):
                # not interested - common name is not determined yet
                continue
            if id.isdigit():
                clients.append(int(id))
            else:
                clients.append(id)
        results['clients'] = clients
    return results
    
def ovpn_create_conf(cn, conf, proxy="vpnnode1"):
    '''Write a configuration file for the connecting openVPN Client. This
    could include routing information etc.'''

    cn=str(cn)
    assert cn.isdigit(), "Invalid common name (must be all digits)"
    assert len(cn) <= 100, "Common name much too long"
    assert len(conf) <= 16384, "Configuration string too long (> 16384)"
    assert_safe_for_bash(proxy)

    # cannot use safe_syscall because we need a writable pipe
    fh = os.popen('ssh %s %s "cat > /etc/openvpn/client-config/%s"' \
                  % (sshopts, proxy, cn), 'w')
    fh.write(conf)
    ret = fh.close()
    assert ret is None, \
    "Configuration writer returned ret: %s " % ret
    return


def ovpn_delete_conf(cn, proxy="vpnnode1"):
    '''Deletes the configuration file for the given client'''
    cn=str(cn)
    assert cn.isdigit(), "Invalid common name (must be all digits)"
    assert len(cn) <= 100, "Common name much too long"
    assert_safe_for_bash(proxy)

    # check if we can reach the other server and see the directory
    # otherwise an error will be raised
    cmd = 'ssh %s %s stat /etc/openvpn/client-config/' % (sshopts, proxy)
    ret, out = safe_syscall(cmd, raisemode=True)

    # now we see if the file exists - if it was already deleted we do not care
    cmd = 'ssh %s %s stat /etc/openvpn/client-config/%s' % (sshopts, proxy, cn)
    ret, out = safe_syscall(cmd, raisemode=False)

    # if the file is there, we can delete it
    # otherwise we are already done
    if ret == 0:
            cmd = 'ssh %s %s rm /etc/openvpn/client-config/%s' % (sshopts, proxy, cn)
            ret, out = safe_syscall(cmd, raisemode=True)

    return


def ovpn_list_conf(proxy="vpnnode1"):
    '''Return a list of configurations at the given VPN proxy.'''
    assert_safe_for_bash(proxy)

    cmd ='ssh %s %s ls /etc/openvpn/client-config' % (sshopts, proxy)
    ret, out = safe_syscall(cmd, raisemode=True)
    assert ret == 0, "Could not list VPN configuration files"

    ids = out.split()
    return ids


def ovpn_initialize(subj, expire_days=None, passphrase=None, appca_id=1,
                    ovpn_path='/home/zope/ovpn', rsabits=4096, dhbits=2048):
    '''Generate a RSA private key and X.509 certificate for the OpenVPN 
    server process.

    Generate random parameters for Diffie-Helmann key exchange 
    (long prime & generator) - these can be made public. 

    Generate a pre shared key (PSK) for additional TLS authentication using HMAC
    and thus preventing denial of service attacks. ('man openvpn => --tls-auth')
    This PSK has to be available on server & client side.
    '''
    from perfact.cert import cert_makekey, cert_makecsr, ca_signreq

    # Generate RSA key and X.509 certificate signed by the appropriate
    # appca_id
    ca_path_fmt="/home/zope/CA/%d"
    ca_path = ca_path_fmt % long(appca_id)

    key = cert_makekey(rsabits=rsabits)
    csr = cert_makecsr(key=key, subj=subj, request_type='server',
                       passphrase=passphrase)
    cert = ca_signreq(csr, passphrase=passphrase, days=expire_days,
                      appca_id=appca_id)

    safe_syscall(['mkdir', '-p', '-m', '700', ovpn_path], raisemode=False)

    fh=open(ovpn_path+'/public.pem', 'w')
    fh.write(cert)
    fh.close()

    fh=open(ovpn_path+'/private.pem', 'w')
    fh.write(key)
    fh.close()

    # Move the CA certificate to our current path
    # Symlink in the /etc/openvpn directory points to it!
    safe_syscall(['cp', ca_path+'/certs/cacert.pem',
                  ovpn_path+'/cacert.pem'], raisemode=True)

    # Generate Diffie-Hellman parameters (prime & generator)
    # Symlink in the /etc/openvpn directory points to it!
    safe_syscall(['openssl', 'dhparam',
                  '-out', ovpn_path+'/dhparam.pem',
                  str(dhbits)], raisemode=True)

    # Generate TLS authentication key (PSK) for HMAC
    # Symlink in the /etc/openvpn directory points to it!
    safe_syscall(['openvpn', '--genkey',
                  '--secret', ovpn_path+'/tlsauth.key'
                  ], raisemode=True)

    return True


def ovpn_gettlsauth(ovpn_path='/home/zope/ovpn'):
    fh = open(ovpn_path+'/tlsauth.key', 'r')
    content = fh.read()
    index = content.find('-----BEGIN OpenVPN Static key V1-----')
    key = content[index:]
    return key
                 
                 
def assert_safe_for_bash(value):
    '''Checks the input for a possible Shell (Bash) exploit
    Given input is compared with a list of bad/forbidden characters
    If one is found, an AssertionError is raised.
    '''
    # shell security check
    bad = [';',
           '\\',
           '&',
           '(',
           '´',
           '|',
           '<',
           '>',
           '!',
           '$',
           ':',
           '*',
           '?',
           '[',
           '{',
    ]
    assert len(set(value).intersection(bad)) == 0, \
        'Forbidden characters for bash found in: %s' % value
    return True



def test_all():
    """Most tests need to be run as user 'zope'!
    """

    try:
        assert_safe_for_bash('my-string')
    except:
        assert True, 'Problem while checking bash safety'

    try:
        assert_safe_for_bash('echo;')
        assert True, 'Problem while checking bash safety'
    except:
        pass

    uid = os.getuid()
    assert uid == 1005, "You need to run as user 'zope' (uid=1005)! \n\
    Your uid is %s. As root try: 'sudo -u zope python ovpn.py'" % uid

    # write a config
    cn = '0101010'
    conf = 'push "route 192.168.42.212"'
    proxy = 'vpnnode1'
    ovpn_create_conf(cn=cn, conf=conf, proxy=proxy)

    # ceck if config was written
    filepath = '/etc/openvpn/client-config/'+cn
    assert os.path.isfile(filepath), 'Config file could not be written'

    # check contents of config
    fd = open(filepath, 'r')
    contents = fd.read()
    fd.close()
    assert conf == contents, 'Expected content does not match! \n\
    Wanted: %s \n\
    Got: %s' % (conf, contents)

    # list configs
    ls = ovpn_list_conf(proxy=proxy)
    assert len(ls) >= 1, 'No configs could be read'
    assert cn in ls, 'Config file not in list'

    # delete a config
    ovpn_delete_conf(cn=cn, proxy=proxy)
    assert os.path.isfile(filepath) is False, 'File was not deleted'

    # try to kill a connection
    expected = ["ERROR: common name '"+cn+"' not found",
                "SUCCESS: common name '"+cn+"1337' found, 1 client(s) killed"]
    # only if the port is reachable
    import socket
    d = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    d.settimeout(4.0)
    try:
        d.connect(('127.0.0.1', 4438))
        d.close()
    except socket.timeout:
        print('Warning! TUN management console timed out')
    except socket.error:
        print('Warning! TUN management console not reachable')
    else:
        out = ovpn_kill_conn(ovpnconn_id=cn, proxy=proxy, mode='tun')
        assert out.strip() in expected, 'Kill got an unexpected result: %s' % out
         

    d = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    d.settimeout(4.0)
    try:
        d.connect(('127.0.0.1', 4439))
        d.close()
    except socket.timeout:
        print('Warning! TAP management console timed out')
    except socket.error:
        print('Warning! TAP management console not reachable')
    else:
        out = ovpn_kill_conn(ovpnconn_id=cn, proxy=proxy, mode='tap')
        out = out.strip()
        assert out.strip() in expected, 'Kill got an unexpected result: %s' % out
          

    # Test status query
    status = ovpn_status(version=1)
    status_ok = status.strip().startswith('OpenVPN CLIENT LIST')
    assert status_ok, 'Wrong status output. Got: %s' % status
        
    # Test status output parsing
    expected = {'clients': [465, 464]}
    from perfact.fileassets import fileassets
    contents = fileassets['tests.ovpn_status_1']
    parsed = ovpn_status_parse(status=contents, version=1)
    assert expected == parsed, \
        'Parsing did not work for expected connections! ' \
        'Got: %s Expexted: %s' % (parsed, expected)

    expected = {'clients': []}    
    contents = fileassets['tests.ovpn_status_1_empty']
    parsed = ovpn_status_parse(status=contents, version=1)
    assert expected == parsed, \
        'Parsing did not work for empty connections! '\
        'Got: %s Expexted: %s' % (parsed, expected)

    expected = {'clients': []}    
    contents = fileassets['tests.ovpn_status_1_undef']
    parsed = ovpn_status_parse(status=contents, version=1)
    assert expected == parsed, \
        'Parsing did not work for undefined connections! '\
        'Got: %s Expexted: %s' % (parsed, expected)
    
    # Test OVPN key, cert, dhparam generation
    print('Generating keys for OpenVPN - this may take some time!')

    # setup a testing CA
    from perfact.cert import ca_initialize
    ca_pass = 'ldskjf;f93579&/k3n4j'
    ca_subj = "/C=DE/ST=NRW/L=Herford/O=perfact::ema/CN=ema-devel-2016"
    appca_id1 = 1337
    ca_initialize(ca_subj, appca_id=appca_id1)

    # Build OVPN specific keys, cert ...
    subj = '/C=DE/ST=NRW/L=Herford/O=perfact::ema/CN=test-OVPN-Server'
    ovpn_initialize(subj, expire_days=None, passphrase=None,
                    appca_id=appca_id1,
                    ovpn_path='/tmp/ovpn',
                    rsabits=512,
                    dhbits=512)

    res, out = safe_syscall(['ls', '-l', '/tmp/ovpn'], raisemode=True)
    print(out)

    res, out = safe_syscall(['openssl', 'dhparam', '-in',
                             '/tmp/ovpn/dhparam.pem', '-check'
                            ], raisemode=True)
    print(out)

    fh = open('/tmp/ovpn/tlsauth.key', 'r')
    secret = fh.read()
    fh.close()

    assert 'BEGIN OpenVPN Static key V1' in secret, \
    'Start indicator for OVPN static key missing in tlsauth.key!'

    assert 'END OpenVPN Static key V1' in secret, \
    'Stop indicator for OVPN static key missing in tlsauth.key!'

    key = ovpn_gettlsauth(ovpn_path='/tmp/ovpn')
    assert key.startswith('-----BEGIN OpenVPN Static key V1-----')

    # Clean up
    safe_syscall(['rm', '-rf', '/tmp/ovpn'])
    
    print('All tests successful')


if __name__ == '__main__':
    test_all()
