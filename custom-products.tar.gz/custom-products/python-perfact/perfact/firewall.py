#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# firewall.py  -  Firewall control
#
# Copyright (C) 2017 PerFact Innovation GmbH & Co. KG
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#

# For interfacing and executing iptables and friends
from perfact.generic import safe_syscall, json_encode, json_decode
from perfact.generic import to_ustring, to_string, tokenize_quoted
# For the shell wrapper (stdin, stdout)
import sys
# For unit testing of large strings
from perfact.generic import md5digest


# Helpers for SSH and local shell execution

def firewall_control(host, fwstruct):
    '''Wrap the ssh call of /usr/bin/perfact-firewall-control

    Use this method from within Zope.
    '''
    control_bin = '/usr/bin/perfact-firewall-control'
    cmd = ['/usr/bin/ssh', host, 'sudo', control_bin]
    input = json_encode(fwstruct)
    retcode, output = safe_syscall(cmd, stdin_data=input,
                                   raisemode=True)
    return json_decode(output)


def binwrapper(dryrun=False):
    '''Wrapper used by /usr/bin/perfact-firewall-control

    This runs on the firewall machine, mostly started via ssh by Zope.
    '''
    # Read args list (if we want to use it)
    input = sys.stdin.read()
    if input:
        fwstruct = json_decode(input)
    else:
        fwstruct = None
    fw = FirewallControl(dryrun=dryrun)
    output = fw.write(fwstruct)
    print(json_encode(output))


# Private helper functions

def _parse_counts(val):
    ''' Read counter values from iptables-save

    >>> _parse_counts('[217547:16533572]')
    {u'bytes': 16533572L, u'packets': 217547L}
    '''
    packets, bytes = map(int, val.strip('[]').split(':'))
    return {u'packets': packets, u'bytes': bytes}


class FirewallControl:
    '''Features

    This module constitutes a front end for the following kernel internals
    relating to IP:

    iptables (tables, chains, rules)


    Future support may include:

    ip rule (send marked packets into other routing tables)

    ip route (build alternative routing tables)

    tc (shape traffic depending on whatever)

    ipset (sets usable for rules)

    The exported interface FirewallControl.write() is wrapped in a
    script, which should be made available in "sudoers".

    '''

    def __init__(self, dryrun=False):
        self.strict = False
        self.dryrun = dryrun
        self.iptables_bin = '/sbin/iptables'
        self.iptables_save = '/sbin/iptables-save'
        self.outformat_allowed = ['python', 'iptables']
        self.outformat = 'python'

        self.iptables_revopts = {
            self.iptables_opts[key]:
            key for key in self.iptables_opts.keys()
        }



    builtin_chains = {
        u'filter': [u'INPUT', u'OUTPUT', u'FORWARD'],
        u'nat': [u'PREROUTING', u'INPUT', u'OUTPUT', u'POSTROUTING'],
        u'mangle': [u'PREROUTING', u'INPUT', u'FORWARD', u'OUTPUT', u'POSTROUTING'],
        u'raw': [u'PREROUTING', u'OUTPUT'],
        u'security': [u'INPUT', u'OUTPUT', u'FORWARD', u'SECMARK', u'CONNSECMARK'],
    }
    iptables_opts = {
        # This must be extended if needed
        u's': u'source',
        u'd': u'destination',
        u'p': u'protocol',
        u'm': u'match',
        u'j': u'jump',
        u'g': u'goto',
        u'i': u'in-interface',
        u'o': u'out-interface',
        u'f': u'fragment',
        u'c': u'set-counters',
    }

    def read(self):
        '''Read the complete firewall with iptables-save and build a
        dictionary reflecting the current status.

        Enrich the return value with a checksum which can be used by the
        caller to detect changes to the ruleset.

        Alternatively the returned data might be plain iptables console output.
        To enable this, the fwstruct needs to set it via key:
        outformat='iptables'
        '''
        # propagate dryrun into components
        if self.dryrun:
            if self.outformat == 'python':
                retcode, dump = 0, example_iptables_save
            elif self.outformat == 'iptables':
                retcode, dump = 0, example_iptables_console

        if not self.dryrun:
            if self.outformat == 'python':
                retcode, dump = safe_syscall(
                    [self.iptables_save, '-c'], raisemode=True)
            elif self.outformat == 'iptables':
                res = {u'iptables': {}}
                for table in self.builtin_chains:
                    # only string arguments are allowed in safe_syscall
                    table = str(table)
                    retcode, dump = safe_syscall(
                        [self.iptables_bin, '-L', '-n', '-v', '-t', table],
                        raisemode=True)
                    res['iptables'][table] = dump
                return res

        # ensure the dump material is unicode
        dump = to_ustring(dump)
        lines = []
        line = []
        comment = False
        for word in tokenize_quoted(
                dump, quotes=u'"', separators=u' \n', append_separators=True):
            # TODO: implement backslash_mode in tokenize_quoted
            if len(word) == 0:
                continue
            if word[0] == u'#' and len(line) == 0:
                comment = True
            line.append(word.strip())
            if word.endswith(u'\n'):
                if not comment:
                    lines.append(line)
                comment = False
                line = []

        tables = {}
        table = None
        for line in lines:
            if len(line) == 0:
                continue

            if line[0][0] == u'*':  # switch to new table
                table = line[0][1:]
                chains = {}
                rules = {}
                continue

            if line[0] == u'COMMIT':  # end of rules
                tables[table] = {u'chains': chains, u'rules': rules}
                continue

            if line[0][0] == ':':  # new chain
                chain = {}
                name = line[0][1:]
                if name in self.builtin_chains.keys():
                    chain[u'policy'] = line[1]
                chain[u'counters'] = _parse_counts(line[-1])
                chains[name] = chain
                continue
            # new rule
            chain = line[2]
            words = line[3:]
            options = []
            option = []
            while len(words):
                cur_word = words.pop(0)
                if len(option) and (cur_word == u'!' or
                                    cur_word.startswith(u'-')):
                    # flush collected option, start afresh
                    options.append(option)
                    option = []
                if cur_word == u'!':
                    option.append(u'!')
                    # jump to the next word
                    cur_word = words.pop(0)
                if cur_word.startswith(u'--'):
                    cur_word = cur_word[2:]
                elif cur_word.startswith(u'-'):
                    # map to long options
                    optstring = self.iptables_opts.get(cur_word[1])
                    if optstring is not None:
                        cur_word = optstring
                option.append(cur_word)

            # flush the last collected option
            if len(option):
                options.append(option)

            counters = _parse_counts(line[0])
            options.append([u'counters', counters[u'packets'], counters[u'bytes']])
            if chain in rules.keys():
                rules[chain].append(options)
            else:
                rules[chain] = [options,]

        if table:
            tables[table] = {u'chains': chains, u'rules': rules}

        return {u'iptables': tables}


    def write(self, fwstruct=None):
        '''Given a dictionary describing firewall manipulation commands, apply
        these commands to the local IP tables.

        Encapsulate the writing process in a save-restore cycle which
        rolls back on any error.

        If the caller gave a checksum, check this before applying any commands.

        As a final op, perform firewall_read() and return the output.

        It is possible to give no commands at all and just read out the current
        firewall configuration. For this use a fwstruct like:
        fwstruct = { u'command': None, u'fwstruct': {'iptables': {}, }

        >>> fw = FirewallControl(dryrun=True)
        >>> a = fw.write(example_fwstruct)
        executing: /sbin/iptables -t filter -C INPUT --source 192.168.42.254/32 --protocol tcp --match tcp --dport 80:443 --jump DROP
        executing: /sbin/iptables -t filter -A INPUT --source 192.168.42.254/32 --protocol tcp --match tcp --dport 80:443 --jump DROP
        >>> md5digest(str(a))
        '211bbca573cba6665dc88dcc5ea686bd'

        xxx b = fw.write({'command': 'add', 'fwstruct': a})
        '''
        if fwstruct:
            if type(fwstruct) == type({}):
                # wrap in a list
                fwstruct = [fwstruct, ]

            for command_set in fwstruct:
                command = command_set['command']
                fwstruct = command_set['fwstruct']

                outformat = command_set.get('outformat')
                if outformat in self.outformat_allowed:
                    self.outformat = command_set['outformat']

                self.apply_commands(fwstruct, mode=command)

        new_state = self.read()
        return new_state


    def syscall(self, cmd):
        '''Wrapper for safe_syscall which uses self.dryrun'''
        if self.dryrun:
            print(u'executing: '+u' '.join(cmd))
            retcode, output = 0, u''
        else:
            retcode, output = safe_syscall(cmd, raisemode=False)
            if retcode and self.strict:
                raise ValueError(output)
        # ensure encoding neutrality
        return retcode, to_ustring(output)


    def apply_commands(self, fwstruct, mode):
        '''Generate commands from fwstruct
        mode: 'insert', 'add', 'delete'
        '''
        for table, tablestruct in fwstruct[u'iptables'].items():
            # Work on "chains" and "rules"
            if mode in [u'add', u'insert']:
                # Add needs to do chains first, then rules
                self.chain_ops(table, tablestruct[u'chains'],
                               mode=mode)
                self.rule_ops(table, tablestruct[u'rules'],
                               mode=mode)
            if mode == u'delete':
                # Delete needs to do rules first, then chains
                self.rule_ops(table, tablestruct[u'rules'],
                               mode=mode)
                self.chain_ops(table, tablestruct[u'chains'],
                               mode=mode)
        return

    def chain_ops(self, table, chains, mode):
        '''Performs creation or deletion of chains.

        Creation fails if self.strict is set and the chain already
        exists. Deletion will fail if there are references or rules
        still in the chain.
        '''
        option = {
            u'insert': u'-N',
            u'add': u'-N',
            u'delete': u'-X',
        }.get(mode)
        for chain, chainstruct in chains.items():
            # Ignore builtin chains
            if chain in self.builtin_chains[table]:
                continue
            cmd = [self.iptables_bin, u'-t', table, option, chain]
            self.syscall(cmd)
        return

    def rule_ops(self, table, rules, mode):
        '''Performs creation and deletion of chains.

        This checks if the rule is already present before inserting or
        deleting.  In self.strict mode, finding the rule on "add" and
        not finding the rule on "delete" results in a failure.
        '''
        option = {
            u'insert': u'-I',
            u'add': u'-A',
            u'delete': u'-D',
        }.get(mode)
        for chain, ruledefs in rules.items():
            # Build iptables command options
            check_cmd = [self.iptables_bin, u'-t', table, u'-C', chain]
            cmd = [self.iptables_bin, u'-t', table, option, chain]
            for ruledef in ruledefs:
                ruleopts = self.rule_to_options(ruledef)
                # Check for presence
                if self.dryrun:
                    print(u'executing: '+u' '.join(check_cmd+ruleopts))
                    retcode, output = (0 if mode==u'delete' else 1), str(check_cmd+ruleopts)
                else:
                    retcode, output = safe_syscall(check_cmd+ruleopts, raisemode=False)
                # Add expects retcode > 0, delete expects retcode == 0
                if mode in [u'add', u'insert'] and retcode == 0:
                    # Cannot add the rule.
                    if self.strict:
                        raise ValueError(output)
                    else:
                        # Ignore this rule
                        continue
                elif mode==u'delete' and retcode != 0:
                    # Cannot delete the rule.
                    if self.strict:
                        raise ValueError(output)
                    else:
                        # Ignore this rule
                        continue

                # Add or delete the rule
                self.syscall(cmd+ruleopts)

        return

    def rule_to_options(self, ruledef):
        '''Convert a ruledef set to a list of options.

        >>> ruledef = [ [u'source', u'192.168.42.254/32',],
        ...             [u'protocol', u'tcp'],
        ...             [u'match', u'tcp'],
        ...             [u'dport', u'80:443'],
        ...             [u'jump', u'DROP'],
        ...             [u'counters', u'0', u'0'], ]
        >>> fw = FirewallControl()
        >>> fw.rule_to_options(ruledef)
        [u'--source', u'192.168.42.254/32', u'--protocol', u'tcp', u'--match', u'tcp', u'--dport', u'80:443', u'--jump', u'DROP']
        '''
        out = []
        for item in ruledef:
            args = list(item)
            if args[0] == u'counters': continue
            if args[0] == u'!': out.append(args.pop(0))
            option = args.pop(0)
            if option.startswith(u'-'):
                out.append(option)
            else:
                out.append(u'--'+option)
            out.extend(args)
        return out


# Example iptables-save -c output:
example_iptables_save = '''
# Completed on Wed Jul 12 16:04:17 2017
# Generated by iptables-save v1.4.12 on Wed Jul 12 16:04:17 2017
*filter
:INPUT DROP [1943:190432]
:FORWARD DROP [250:10500]
:OUTPUT DROP [0:0]
:10583-OVPN - [0:0]
:11972-OVPN - [0:0]
:14042-MBRouter - [0:0]
:14052-Comtime - [0:0]
:14101-Symmedia - [0:0]
:14102-Comtime - [0:0]
:14104-Symmedia - [0:0]
:14107-OVPN - [0:0]
:14108-OVPN - [0:0]
:14110-OVPN - [0:0]
:EXT-INPUT - [0:0]
:EXT-OUTPUT - [0:0]
[24330854:2635874734] -A INPUT -i eth0 -j EXT-INPUT
[583461:61223748] -A INPUT -i lo -j ACCEPT
[68316:4110844] -A INPUT -p icmp -j ACCEPT
[4409683:319456808] -A INPUT -j LOG
[403592:481620962] -A FORWARD -d 10.1.1.94/32 -i eth0 -o tun0 -j 14110-OVPN
[339540:56315108] -A FORWARD -s 10.1.1.94/32 -i tun0 -o eth0 -j 14110-OVPN
[7450:4941165] -A FORWARD -d 10.1.1.91/32 -i eth0 -o tun0 -j 14108-OVPN
[7344:902083] -A FORWARD -s 10.1.1.91/32 -i tun0 -o eth0 -j 14108-OVPN
[118672:220214208] -A FORWARD -d 10.1.1.93/32 -i eth0 -o tun0 -j 14107-OVPN
[169745:9501920] -A FORWARD -s 10.1.1.93/32 -i tun0 -o eth0 -j 14107-OVPN
[402270:64580439] -A FORWARD -d 85.214.59.120/32 -i eth0 -o eth0 -j 14104-Symmedia
[389897:45888154] -A FORWARD -s 85.214.59.120/32 -i eth0 -o eth0 -j 14104-Symmedia
[670:113353] -A FORWARD -d 10.1.1.8/32 -i eth0 -o tun0 -j 11972-OVPN
[629:79453] -A FORWARD -s 10.1.1.8/32 -i tun0 -o eth0 -j 11972-OVPN
[19667:5639752] -A FORWARD -d 139.29.178.8/32 -i eth0 -o eth0 -j 14102-Comtime
[21600:2519748] -A FORWARD -s 139.29.178.8/32 -i eth0 -o eth0 -j 14102-Comtime
[483524:76750566] -A FORWARD -d 85.214.59.120/32 -i eth0 -o eth0 -j 14101-Symmedia
[566568:233331366] -A FORWARD -s 85.214.59.120/32 -i eth0 -o eth0 -j 14101-Symmedia
[32721:13602899] -A FORWARD -d 10.1.1.11/32 -i eth0 -o tun0 -j 10583-OVPN
[44559:3533157] -A FORWARD -s 10.1.1.11/32 -i tun0 -o eth0 -j 10583-OVPN
[138127:65830307] -A FORWARD -d 139.29.178.8/32 -i eth0 -o eth0 -j 14052-Comtime
[131067:14092567] -A FORWARD -s 139.29.178.8/32 -i eth0 -o eth0 -j 14052-Comtime
[73510:20007567] -A FORWARD -i eth0 -o eth0 -j 14042-MBRouter
[51638:2333914] -A FORWARD -i eth0 -o eth0 -j 14042-MBRouter
[12:840] -A FORWARD -p icmp -j ACCEPT
[156446:6782894] -A FORWARD -j LOG
[21700943:11185930269] -A OUTPUT -o eth0 -j EXT-OUTPUT
[583461:61223748] -A OUTPUT -o lo -j ACCEPT
[68205:4097317] -A OUTPUT -p icmp -j ACCEPT
[21:2931] -A OUTPUT -j LOG
[44559:3533157] -A 10583-OVPN -d 10.2.164.210/32 -p tcp -m tcp --dport 3389 -m state --state NEW,ESTABLISHED -m comment --comment öRULE-10941 -j ACCEPT
[32721:13602899] -A 10583-OVPN -s 10.2.164.210/32 -p tcp -m tcp --sport 3389 -m state --state ESTABLISHED -m comment --comment RULE-10941 -j ACCEPT
[10:448] -A 11972-OVPN -d 145.228.13.229/32 -p tcp -m tcp --dport 449 -m state --state NEW,ESTABLISHED -m comment --comment RULE-11581 -j ACCEPT
[8:346] -A 11972-OVPN -s 145.228.13.229/32 -p tcp -m tcp --sport 449 -m state --state ESTABLISHED -m comment --comment RULE-11581 -j ACCEPT
[23:2196] -A 11972-OVPN -d 145.228.13.229/32 -p tcp -m tcp --dport 9476 -m state --state NEW,ESTABLISHED -m comment --comment RULE-11583 -j ACCEPT
[21:4902] -A 11972-OVPN -s 145.228.13.229/32 -p tcp -m tcp --sport 9476 -m state --state ESTABLISHED -m comment --comment RULE-11583 -j ACCEPT
[596:76809] -A 11972-OVPN -d 145.228.13.229/32 -p tcp -m tcp --dport 992 -m state --state NEW,ESTABLISHED -m comment --comment RULE-11584 -j ACCEPT
[641:108105] -A 11972-OVPN -s 145.228.13.229/32 -p tcp -m tcp --sport 992 -m state --state ESTABLISHED -m comment --comment RULE-11584 -j ACCEPT
[0:0] -A 11972-OVPN -d 145.228.13.229/32 -p tcp -m tcp --dport 9470 -m state --state NEW,ESTABLISHED -m comment --comment RULE-11582 -j ACCEPT
[0:0] -A 11972-OVPN -s 145.228.13.229/32 -p tcp -m tcp --sport 9470 -m state --state ESTABLISHED -m comment --comment RULE-11582 -j ACCEPT
[11349:690229] -A 14042-MBRouter -d 145.228.118.185/32 -p tcp -m tcp --dport 6016 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13869 -j ACCEPT
[10523:16983424] -A 14042-MBRouter -s 145.228.118.185/32 -p tcp -m tcp --sport 6016 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -m comment --comment RULE-13869 -j ACCEPT
[138127:65830307] -A 14052-Comtime -s 10.4.130.196/32 -p tcp -m tcp --dport 10010 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13879 -j ACCEPT
[131067:14092567] -A 14052-Comtime -d 10.4.130.196/32 -p tcp -m tcp --sport 10010 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -m comment --comment RULE-13879 -j ACCEPT
[483524:76750566] -A 14101-Symmedia -s 10.4.130.134/32 -p tcp -m tcp --dport 7788 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13921 -j ACCEPT
[566568:233331366] -A 14101-Symmedia -d 10.4.130.134/32 -p tcp -m tcp --sport 7788 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -m comment --comment RULE-13921 -j ACCEPT
[19667:5639752] -A 14102-Comtime -s 10.4.130.196/32 -p tcp -m tcp --dport 10010 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13922 -j ACCEPT
[21600:2519748] -A 14102-Comtime -d 10.4.130.196/32 -p tcp -m tcp --sport 10010 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -m comment --comment RULE-13922 -j ACCEPT
[10410:1656519] -A 14104-Symmedia -s 10.4.8.39/32 -p tcp -m tcp --dport 443 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13923 -j ACCEPT
[12890:1417659] -A 14104-Symmedia -d 10.4.8.39/32 -p tcp -m tcp --sport 443 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -m comment --comment RULE-13923 -j ACCEPT
[169114:9472278] -A 14107-OVPN -d 10.4.156.8/32 -p tcp -m tcp --dport 7007 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13929 -j ACCEPT
[118369:218825986] -A 14107-OVPN -s 10.4.156.8/32 -p tcp -m tcp --sport 7007 -m state --state ESTABLISHED -m comment --comment RULE-13929 -j ACCEPT
[631:29642] -A 14107-OVPN -d 10.4.156.7/32 -p tcp -m tcp --dport 7007 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13930 -j ACCEPT
[303:1388222] -A 14107-OVPN -s 10.4.156.7/32 -p tcp -m tcp --sport 7007 -m state --state ESTABLISHED -m comment --comment RULE-13930 -j ACCEPT
[7330:886843] -A 14108-OVPN -d 10.2.164.134/32 -p tcp -m tcp --dport 3389 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13931 -j ACCEPT
[7448:4941045] -A 14108-OVPN -s 10.2.164.134/32 -p tcp -m tcp --sport 3389 -m state --state ESTABLISHED -m comment --comment RULE-13931 -j ACCEPT
[0:0] -A 14108-OVPN -d 10.2.164.28/32 -p tcp -m tcp --dport 3389 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13932 -j ACCEPT
[0:0] -A 14108-OVPN -s 10.2.164.28/32 -p tcp -m tcp --sport 3389 -m state --state ESTABLISHED -m comment --comment RULE-13932 -j ACCEPT
[0:0] -A 14108-OVPN -d 10.2.164.27/32 -p tcp -m tcp --dport 3389 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13933 -j ACCEPT
[0:0] -A 14108-OVPN -s 10.2.164.27/32 -p tcp -m tcp --sport 3389 -m state --state ESTABLISHED -m comment --comment RULE-13933 -j ACCEPT
[0:0] -A 14110-OVPN -d 10.29.58.77/32 -p tcp -m tcp --dport 51000 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13944 -j ACCEPT
[0:0] -A 14110-OVPN -s 10.29.58.77/32 -p tcp -m tcp --sport 51000 -m state --state ESTABLISHED -m comment --comment RULE-13944 -j ACCEPT
[229972:21457346] -A 14110-OVPN -d 10.29.58.78/32 -p tcp -m tcp --dport 5905 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13945 -j ACCEPT
[188650:430735189] -A 14110-OVPN -s 10.29.58.78/32 -p tcp -m tcp --sport 5905 -m state --state ESTABLISHED -m comment --comment RULE-13945 -j ACCEPT
[0:0] -A 14110-OVPN -d 10.29.58.77/32 -p tcp -m tcp --dport 50000 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13946 -j ACCEPT
[0:0] -A 14110-OVPN -s 10.29.58.77/32 -p tcp -m tcp --sport 50000 -m state --state ESTABLISHED -m comment --comment RULE-13946 -j ACCEPT
[108599:34814307] -A 14110-OVPN -d 10.29.58.78/32 -p tcp -m tcp --dport 11169 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13947 -j ACCEPT
[212896:49724714] -A 14110-OVPN -s 10.29.58.78/32 -p tcp -m tcp --sport 11169 -m state --state ESTABLISHED -m comment --comment RULE-13947 -j ACCEPT
[0:0] -A 14110-OVPN -s 10.29.58.78/32 -p tcp -m tcp --dport 11159 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13948 -j ACCEPT
[0:0] -A 14110-OVPN -d 10.29.58.78/32 -p tcp -m tcp --sport 11159 -m state --state ESTABLISHED -m comment --comment RULE-13948 -j ACCEPT
[966:43173] -A 14110-OVPN -d 10.29.58.77/32 -p tcp -m tcp --dport 5905 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13949 -j ACCEPT
[2045:1160979] -A 14110-OVPN -s 10.29.58.77/32 -p tcp -m tcp --sport 5905 -m state --state ESTABLISHED -m comment --comment RULE-13949 -j ACCEPT
[0:0] -A 14110-OVPN -d 10.29.58.78/32 -p tcp -m tcp --dport 51000 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13950 -j ACCEPT
[0:0] -A 14110-OVPN -s 10.29.58.78/32 -p tcp -m tcp --sport 51000 -m state --state ESTABLISHED -m comment --comment RULE-13950 -j ACCEPT
[0:0] -A 14110-OVPN -d 10.29.58.77/32 -p tcp -m tcp --dport 11169 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13951 -j ACCEPT
[0:0] -A 14110-OVPN -s 10.29.58.77/32 -p tcp -m tcp --sport 11169 -m state --state ESTABLISHED -m comment --comment RULE-13951 -j ACCEPT
[0:0] -A 14110-OVPN -d 10.29.58.78/32 -p tcp -m tcp --dport 50000 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13952 -j ACCEPT
[0:0] -A 14110-OVPN -s 10.29.58.78/32 -p tcp -m tcp --sport 50000 -m state --state ESTABLISHED -m comment --comment RULE-13952 -j ACCEPT
[0:0] -A 14110-OVPN -s 10.29.58.77/32 -p tcp -m tcp --dport 11159 -m state --state NEW,ESTABLISHED -m comment --comment RULE-13953 -j ACCEPT
[0:0] -A 14110-OVPN -d 10.29.58.77/32 -p tcp -m tcp --sport 11159 -m state --state ESTABLISHED -m comment --comment RULE-13953 -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 53 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[41255:5593557] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 53 -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 123 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[215485:16376860] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 123 -m state --state ESTABLISHED -j ACCEPT
[4821:1807338] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 80 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 80 -m state --state ESTABLISHED -j ACCEPT
[4:160] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 443 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 443 -m state --state ESTABLISHED -j ACCEPT
[243915:85197077] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 22 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 22 -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 10010 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 10010 -m state --state ESTABLISHED -j ACCEPT
[33:1730] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 25 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 25 -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --sport 465 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --sport 465 -m state --state ESTABLISHED -j ACCEPT
[997656:152785347] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
[18349671:2050538137] -A EXT-INPUT -d 212.100.43.215/32 -p tcp -m tcp --dport 443 -m state --state NEW,ESTABLISHED -j ACCEPT
[15:6876] -A EXT-INPUT -d 212.100.43.215/32 -p udp -m udp --dport 443 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 53 -m state --state NEW,ESTABLISHED -j ACCEPT
[41258:2586388] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 53 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 123 -m state --state NEW,ESTABLISHED -j ACCEPT
[217547:16533572] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 123 -m state --state NEW,ESTABLISHED -j ACCEPT
[4228:1353918] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 80 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 80 -m state --state NEW,ESTABLISHED -j ACCEPT
[4:176] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 443 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 443 -m state --state NEW,ESTABLISHED -j ACCEPT
[252509:25679757] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 10010 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 10010 -m state --state NEW,ESTABLISHED -j ACCEPT
[35:5447] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 25 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 25 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --dport 465 -m state --state NEW,ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --dport 465 -m state --state NEW,ESTABLISHED -j ACCEPT
[954401:229079380] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --sport 22 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --sport 22 -m state --state ESTABLISHED -j ACCEPT
[20162735:10906591383] -A EXT-OUTPUT -s 212.100.43.215/32 -p tcp -m tcp --sport 443 ! --tcp-flags FIN,SYN,RST,ACK SYN -m state --state ESTABLISHED -j ACCEPT
[0:0] -A EXT-OUTPUT -s 212.100.43.215/32 -p udp -m udp --sport 443 -m state --state ESTABLISHED -j ACCEPT
COMMIT
# Completed on Wed Jul 12 16:04:17 2017
'''

example_ruledef = [
    # Mnemonic version:
    [u'source', u'192.168.42.254/32',],
    # ('!', 'tcp-flags', 'SYN,ACK,FIN', 'SYN'),
    # Full-blown dictionary (support this???):
    #{
    #    'name': 'source',
    #    'negate': False,  # may be omitted, defaults to False
    #    'value': '192.168.42.254/32',
    #},
    [u'protocol', u'tcp'],
    [u'match', u'tcp'],
    [u'dport', u'80:443'],
    [u'jump', u'DROP'],
    # Counters are not interpreted in input mode
    [u'counters', 0, 0],
]

example_output = {
    # One entry per table
    u'iptables': {
        # Dump says: *filter
        u'filter': {
            u'chains': {
                # Dump says: :INPUT ACCEPT [72:11452]
                u'INPUT': {
                    u'policy': 'ACCEPT',
                    # Counters are not interpreted in input mode
                    u'counters': {
                        u'packets': 72,
                        u'bytes': 11452,
                    },
                },
                # ...
            },
            u'rules': {
                u'INPUT': [
                    # Dump says: [0:0] -A INPUT -s 192.168.42.254/32 -p tcp -m tcp --dport 80:443 -j DROP
                    example_ruledef,
                    # more rules...
                ],
                # more chains...
            },
        },
    },
}


example_fwstruct = [
    {
        u'command': u'add',
        u'fwstruct': example_output,
        u'outformat': 'python', # optional: python is the default
    },
    # ...
]
