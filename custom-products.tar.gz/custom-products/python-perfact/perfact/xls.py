#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# xls_utils.py  -  Helpers for handling .xls files.
#
# Copyright (C) 2008 Jan Jockusch <jan.jockusch@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

import os, tempfile
from perfact.generic import cleanup_string
import perfact.generic
import perfact.say
import string
import StringIO
# For conversion of crazy time fields
import datetime


def parse_xls(data, page=0):
    '''Given a file-like object or a string, extract the
    requested page in a list of lists (cells).
    '''
    page = int(page)
    if type(data) != type(''):
        data = data.read()
    tmpdir = tempfile.mkdtemp()
    xlsfile = tmpdir + '/in.xls'

    fh = open(xlsfile, 'w')
    fh.write(data)
    fh.close()

    fh = os.popen('xlhtml -asc -xp:%d %s' % (page, xlsfile), 'r')
    ret = fh.read()
    fh.close()
    os.system('rm -r '+tmpdir)
    return list(map(lambda a: a.split('\t'), ret.split('\n')))


# pyExcelerator import / export

import pyExcelerator

def pyexcel_read_xls(data):
    '''Given a file-like object or a string, extract the
    requested page in a list of lists (cells).
    '''
    if type(data) != type(''):
        data = data.read()
    tmpdir = tempfile.mkdtemp()
    xlsfile = tmpdir + '/in.xls'

    fh = open(xlsfile, 'w')
    fh.write(data)
    fh.close()

    parsed = pyExcelerator.ImportXLS.parse_xls(xlsfile)

    os.system('rm -r '+tmpdir)
    return parsed


def pyexcel_struct2table(data, sheet=0):
    '''Extract a sheet and put all values into a two-dimensional
    array.'''
    vals = data[sheet][1]

    # Analyze keys extracting max row and col
    maxrow = maxcol = 0
    for row, col in vals.keys():
        if row > maxrow: maxrow = row
        if col > maxcol: maxcol = col


    rows = []
    for row in range(maxrow+1):
        cols = []
        for col in range(maxcol+1):
            cols.append(vals.get((row, col), ''))
        rows.append(cols)

    return rows


def pyexcel_table2struct(data, sheetname='Sheet', encoding='utf-8'):
    vals = {}
    for row in range(len(data)):
        rowdata = data[row]
        for col in range(len(rowdata)):
            coldata = rowdata[col]
            if type(coldata) == type(''):
                coldata = coldata.decode(encoding)
            vals[(row, col)] = coldata

    return [(sheetname, vals)]



def pyexcel_write_xls(data, protect=False):
    '''Given an array of cell descriptions'''
    style_top = pyExcelerator.XFStyle()
    style_left = pyExcelerator.XFStyle()
    style_other = pyExcelerator.XFStyle()

    style_top.font.bold = True

    if protect:
        style_top.protection.cell_locked = True
        style_left.protection.cell_locked = True
        font_left = pyExcelerator.Font()
        font_left.color_index = 23
        style_left.font = font_left
        style_other.protection.cell_locked = False

    wb = pyExcelerator.Workbook()

    for sheet, vals in data:
        ws = wb.add_sheet(sheet)

        for key, value in vals.items():
            row, col = key
            if row == 0:
                ws.write(row, col, value, style_top)
            elif col == 0 and value:
                ws.write(row, col, value, style_left)
            else:
                ws.write(row, col, value, style_other)

        # Dummy protection
        if protect:
            ws.protect = True
            ws.wnd_protect = True
            ws.obj_protect = True
            ws.scen_protect = True
            ws.password = "abcdef"


    f = StringIO.StringIO()
    wb.save(f)
    f.seek(0)
    return f.read()



def pyexcel_write_xls_extended( data ):
    '''Given an array of cell descriptions, create an xls file.
    data: a list of mappings (i.e., dictionaries) with the following keys:

        sheetname (required): The name of the data sheet
        contents (required): a mapping from cell position (row,col) to content. Content
            can either be unicode (or bytes) or a list of tuples (part, fontdef). 
            fontdef is passed to easyfont to create a font for the given part.
            For example, giving
              {(0,0): u'test', (0,1): [(u'this is ', ''), (u'bold', 'bold on')]}
            will set 'test' into the first cell and 'this is bold' into the
            second, with the word 'bold' being set in a bold font
        widths: a mapping from column index to width in cm
        heights: a mapping from row index to height in cm
        styles: a mapping from cell position (row,col) to a style
            description that can be used by easyxf. See example in
            https://github.com/python-excel/xlwt/blob/master/examples/xlwt_easyxf_simple_demo.py
            and the xf_dict definition in
            https://github.com/python-excel/xlwt/blob/master/xlwt/Style.py 
            To get a specific font-height in pt mulitply by 20 
            ("font: height 180;" for 9pt)
            Example: {(3,3): "font: height 180, bold on, underline on; align: horiz center;"}
        horz_page_breaks: a list of row numbers where page breaks should occur
        orientation: 'portrait' (default) or 'landscape'
        fit_page: Boolean with default False. If set, the worksheet is zoomed
            so it fits onto a page
    '''

    import xlwt
    # precompute required styles, only creating one object per distinct definition
    xfstyles = {}
    for sheet in data:
        if 'styles' not in sheet:
            continue
        for definition in sheet['styles'].values():
            if definition in xfstyles:
                continue
            xfstyles[definition] = xlwt.easyxf(definition)

    # precompute required fonts for RTF contents
    fonts = {}
    for sheet in data:
        for key, content in sheet['contents'].items():
            if perfact.generic.get_type(content) != 'list':
                continue
            for part in content:
                if part[1] in fonts:
                    continue
                fonts[part[1]] = xlwt.easyfont(part[1])

    wb = xlwt.Workbook()

    for sheet in data:
        ws = wb.add_sheet(sheet['sheetname'])
        if sheet.get('fit_page',False):
            ws.set_fit_num_pages(1)
        if sheet.get('orientation', 'portrait')== 'landscape':
            ws.portrait = False

        for col, w in sheet.get('widths', {}).items():
            ws.col(col).width = int(w*1310)
        for row, h in sheet.get('heights', {}).items():
            ws.row(row).height = int(h*566)

        styles = sheet.get('styles', {})
        for key, content in sheet['contents'].items():
            row, col = key
            style = xfstyles.get(styles.get(key, None), None)
            if perfact.generic.get_type(content) == 'list':
                rt = []
                for part in content:
                    rt.append( (part[0], fonts[part[1]]) )
                if style is None:
                    ws.write_rich_text(row, col, rt)
                else:
                    ws.write_rich_text(row, col, rt, style)
            else:
                if style is None:
                    ws.write(row, col, content)
                else:
                    ws.write(row, col, content, style)
        ws.horz_page_breaks = [
                (row, 0, 255)
                for row in sheet.get('horz_page_breaks', [])
                ]


    # Save workbook
    import StringIO
    f = StringIO.StringIO()
    wb.save(f)
    f.seek(0)
    return f.read()


def pyexcel_table2dicts(data, cols=None, encoding='utf-8'):
    out = []
    for item in data:
        # Basic generic processing
        processed = list(map(lambda a: a.decode(encoding).strip()
                             if type(a)==type('') else unicode(a).strip(),
                             item))

        # Ignore empty lines
        if not list(filter(None, processed)): continue

        # No columns given? Use first non-trivial line as keys
        if not cols:
            cols = processed
            continue

        # Pad missing entries
        processed.extend(['',] * (len(cols) - len(processed)))

        # Retrieve column dictionary
        d = dict((cols[i], processed[i]) for i in range(len(cols)))

        out.append(d)

    return out


def generic_convert(data, extension='xls', target='xlsx'):
    '''Convert files using libreoffice.'''
    tmpdir = tempfile.mkdtemp()
    extension = cleanup_string(
        extension, valid_chars=string.letters+string.digits)
    target = cleanup_string(
        target, valid_chars=string.letters+string.digits)
    # Write source file
    infile = tmpdir + '/in.' + extension
    outfile = tmpdir + '/in.' + target
    fh = open(infile, 'w')
    fh.write(data)
    fh.close()
    # Perform conversion
    fh = os.popen('libreoffice --headless --convert-to %s --outdir %s %s' %
                  (target, tmpdir, infile), 'r')
    ret = fh.read()
    fh.close()
    # Read finished output
    fh = open(outfile, 'r')
    outdata = fh.read()
    fh.close()
    return outdata


def pyexcel_convert(data, extension='xlsx'):
    '''Convert data into Excel97 format
    '''
    return generic_convert(data, 'xlsx', 'xls')


def pyexcel_date_from_float(value):
    '''Convert an XLS float datetime to ISO string notation. '''
    base_str = '1899-12-30 00:00:00'
    fmt = '%Y-%m-%d %H:%M:%S'

    base = datetime.datetime.strptime(base_str, fmt)
    delta = datetime.timedelta(days=float(value))
    result = base + delta
    return result.strftime(fmt)
