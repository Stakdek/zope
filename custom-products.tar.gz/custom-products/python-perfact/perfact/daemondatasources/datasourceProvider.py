#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# datasourceProvider.py  -  building datasource-connections for dbcached.py
#
# $Revision: 2.10 $
#
# Copyright (C) 2015 PerFact Innovation GmbH & Co. KG <info@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#

''' This is the successor of dbconnector.py
Today the data sources for dbcached.py can not only be databases.
So this is a module without the database stuff.
'''

from dbdatasources import ConnectionDecorator

from SoapPseudoConnection import SoapPseudoConnection
import RestConnections
import saprfc

def createDS(dbtype, connectstring):
    ''' Connect a datasource of a given type with the given connectstring '''
    if dbtype in ['oracle', 'sybase', 'sapdb', 'pyodbc','psycopg', 'pyodbc_j', 'dbdummy', 'dbdummy_j']:
        dcon = ConnectionDecorator(connector=connectstring, dbtype=dbtype)
    elif dbtype == 'soap':
        dcon = SoapPseudoConnection(connector=connectstring, dbtype=dbtype)
    elif dbtype == 'restsession':
        dcon = RestConnections.SessionConnection(connector=connectstring, dbtype=dbtype)
    elif dbtype == 'saprfc':
        dcon = saprfc.SAPConnection(connector=connectstring, dbtype=dbtype)
    else:
        mes = 'ConnectionType %s  unknown' % (dbtype)
        raise dsException(dbtype, connectstring, mes)
    return dcon


class dsException(Exception):
    def __init__(self, *args):
        self.args = args
        dbtype, connectstring, error = args
        self.value = 'Connection failed for %s with %s (%s)'  % (dbtype, connectstring, error)
