#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# dbdatasources.py  -  database datasources for datasourceProvider.py
#
# $Revision: 2.10 $
#
# Copyright (C) 2016 PerFact Innovation GmbH & Co. KG <info@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#


import os

#os.environ['PGCLIENTENCODING'] = 'LATIN1'
os.environ['PGCLIENTENCODING'] = 'UNICODE'

import ast
import time

literal_controlvalues = {'controlfloat':'1.0001','controlstring':"'foo'"}
'''Literal control values are querried as literals from the remote
system. Then they get compared with the same literal values in the
local database. This is a way to make sure data is transfered
correctly.'''

class ConnectionDecorator(object):
    ''' Decorator wrapping database connections'''
    def __init__(self, connector, dbtype=''):
        self.connector = connector
        self.decorated = None
        self.dbtype = dbtype
        self.__phantom_table = ''
        self.initProvider()
        if self.dbtype[-2:] == '_j':
            # work with julian date
            self.nowstring = self.julian_nowstring

    def initProvider(self):
        ''' Do all the provider specific stuff'''
        if self.dbtype == 'oracle':
            import cx_Oracle
            self.provider = cx_Oracle
            self.__phantom_table = 'DUAL'
            #os.environ["NLS_LANG"] = 'German_Germany.UTF8'
        elif self.dbtype == 'sapdb':
            self.connector = ast.literal_eval(self.connector)
            import sapdb.dbapi
            self.provider = sapdb.dbapi
            self.close = self.noClose
        elif self.dbtype in ['pyodbc','pyodbc_j']:
            import pyodbc
            self.provider = pyodbc
        elif self.dbtype == 'psycopg':
            import psycopg2
            self.provider = psycopg2
        elif self.dbtype.startswith('sybase'):
            raise Exception('No more support for Sybase. Try pyodbc.')
        elif self.dbtype.startswith('dbdummy'):
            self.provider = None


    def __del__(self):
        self.close()

    def create_connection(self):
        try:
            if (isinstance(self.connector, basestring)):
                self.decorated = self.provider.connect(self.connector)
            else:
                self.decorated = self.provider.connect(**self.connector)
        except Exception as error:
            raise dbconnectorException(self.dbtype, self.connector, error)

    def cursor(self):
        if (self.decorated is None):
            self.create_connection()
        return self.decorated.cursor()

    def close(self):
        if not(self.decorated is None):
            try:
                self.decorated.close()
            except:
                pass
            self.decorated = None

    def noClose(self):
        ''' Substitute for close '''
        return

    def nowstring(self):
        return 'now()'

    def julian_nowstring(self):
        ''' Substitute for nowstring'''
        return str(int(time.strftime('%Y%j'))-1900000)

    def set_isolation_level(self, level):
        if (self.decorated is None):
            self.create_connection()
        return self.decorated.set_isolation_level(level)

    def commit(self):
        return self.decorated.commit()

    def rollback(self):
        if self.decorated is None:
            return
        else:
            return self.decorated.rollback()

    def duplicate(self):
        return ConnectionDecorator(dbtype=self.dbtype, connector=self.connector)

    @property
    def phantom_table(self):
        return self.__phantom_table

    def query_controlvalues(self):
        ''' get some literal values from the db '''
        # create a statement with the controlvalues
        pairs = []
        for n,v in literal_controlvalues.iteritems():
            pairs.append(v+' as '+n)
        from_part = ''
        # some dbs have a special phantom table. ConnectionDecorator knows.
        if self.__phantom_table:
            from_part = ' from ' + self.__phantom_table
        statement = 'select ' + ','.join(pairs) + from_part
        # query and get description and remote_data
        cur = self.cursor()
        cur.execute(statement)
        desc = cur.description
        remote_data = cur.fetchall()
        cur.close()
        assert len(desc) == len(literal_controlvalues), 'Not all controlvalues returned'

        colnames = []
        for col in desc:
            colnames.append(col[0].lower())
        return remote_data, colnames, literal_controlvalues

class dbconnectorException(Exception):
    def __init__(self, *args):
        self.args = args
        dbtype, connectstring, error = args
        self.value = 'Connection failed for %s with %s (%s)'  % (dbtype, connectstring, error)
