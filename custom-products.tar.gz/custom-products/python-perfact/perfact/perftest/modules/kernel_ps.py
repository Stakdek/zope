from perfact.generic import safe_syscall
import os

def perftest(conf):
    '''Perform the test proper.'''
    cmd = ['ps', 'aux']

    retcode, output = safe_syscall(cmd, raisemode=True)
    lines = len(output.decode('utf-8').split('\n'))

    return 'ps lines=%d' % (lines)
