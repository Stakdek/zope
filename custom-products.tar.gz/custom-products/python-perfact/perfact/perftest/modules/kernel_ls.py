from perfact.generic import safe_syscall
import os

def perftest(conf):
    '''Perform the test proper.'''
    directory = conf.get('directory') or os.environ.get('HOME')
    filename  = conf.get('filename') or 'ls_test_file'

    cmd = ['dd', 'if=/dev/zero',
           'of=%s' % os.path.join(directory, filename),
           'oflag=direct', 'iflag=fullblock',
           'bs=4096', 'count=10']

    retcode, output = safe_syscall(cmd, raisemode=True)

    lines = len(os.listdir(directory))

    return 'ls lines=%d' % (lines)
