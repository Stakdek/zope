from perfact.generic import safe_syscall
import math

def perftest(conf):
    '''Perform the test proper.'''
    loop1 = conf.getint('loop1') or 1000
    loop2 = conf.getint('loop2') or 1000
    loop3 = conf.getint('loop3') or 5

    result = 0
    for i in range(loop1):
        for j in range(loop2):
            for k in range(loop3):
                result += math.sqrt((i+1)*(j+1)*(k+1))

    return 'loop=%d*%d*%d' % (loop1, loop2, loop3)

