from perfact.generic import cleanup_string

import string
import os

def perftest(conf):
    '''Perform the test proper.'''
    blocksize = conf.getint('blocksize') or 4096
    count     = conf.getint('count') or 24414
    hostname  = conf.get('hostname') or 'perfact@snoopy' # will almost certainly fail!

    hostname = cleanup_string(hostname,
                              string.ascii_letters+string.digits+'@._-')

    cmd = ('dd if=/dev/zero ' +
           ('bs=%d count=%d' % (blocksize, count)) +
           (' | ssh %s cat >/dev/null' % hostname))

    retcode = os.system(cmd)
    assert retcode == 0, "Error while executing %s" % cmd

    return 'blocksize=%d, count=%d, hostname=%s' % (blocksize, count, hostname)
