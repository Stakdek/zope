from perfact.generic import safe_syscall
import os

def perftest(conf):
    '''Perform the test proper.'''
    filesize  = conf.get('filesize') or '10M'
    numjobs   = conf.getint('numjobs') or 1
    directory = conf.get('directory') or os.environ.get('HOME')
    filename  = conf.get('filename') or 'fio_test_file'

    cmd = ['fio', '--rw=readwrite', '--refill_buffers',
           '--minimal', '--directory=%s' % directory,
           '--name=%s' % filename, '--size=%s' % filesize,
           '--direct=1', '--numjobs=%d' % numjobs]

    retcode, output = safe_syscall(cmd, raisemode=True)

    return 'filesize=%s, numjobs=%d' % (filesize, numjobs)
