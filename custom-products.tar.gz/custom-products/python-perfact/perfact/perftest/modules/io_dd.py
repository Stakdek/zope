from perfact.generic import safe_syscall
import os

def perftest(conf):
    '''Perform the test proper.'''
    blocksize = conf.getint('blocksize') or 4096
    count     = conf.getint('count') or 16384
    directory = conf.get('directory') or os.environ.get('HOME')
    filename  = conf.get('filename') or 'dd_test_file'

    cmd = ['dd', 'if=/dev/zero',
           'of=%s' % os.path.join(directory, filename),
           'oflag=direct', 'iflag=fullblock',
           'bs=%d' % blocksize, 'count=%d' % count]

    retcode, output = safe_syscall(cmd, raisemode=True)

    return 'blocksize=%d, count=%d' % (blocksize, count)
