try:
    import configparser
except:
    import perfact.configparser_compat as configparser

import importlib
import time
import logging

import modules

class PerformanceTest:

    def __init__(self, config_file='/etc/perfact/perftest/perftest.ini'):
        '''Initialize the testing suite from the configuration file.'''

        # Read the sections of the config file
        self.config = configparser.ConfigParser()
        res = self.config.read(config_file)
        assert res, ("Empty configuration file. "
                     "Please edit %s" % config_file)
        assert self.config.sections(), ("No modules defined. "
                                        "Please define at least one test in %s." %
                                        config_file)

        self.modules = []
        for section in self.config.sections():
            # Import the modules which implement the tests
            m = importlib.import_module('modules.'+section)
            self.modules.append([section, m])

        logfile = self.config['DEFAULT'].get('logfile')
        logging.basicConfig(filename=logfile,
                            format='%(asctime)s %(levelname)s %(message)s',
                            level=logging.INFO)

    def log(self, msg):
        logging.info(msg)


    def run(self):
        '''Run the performance tests.'''

        failed = 0
        total = 0

        # Loop through all the testing modules which were loaded
        for section, module in self.modules:
            # Check each module against the timeout
            start = time.time()
            
            # Perform the test
            conf = self.config[section]
            log_line = module.perftest(conf)

            stop = time.time()
            duration = (stop - start) # Unit: seconds

            timeout = conf.getfloat('timeout')

            # Determine failure or success
            if duration <= timeout:
                # Success
                txt = '--  OK  --'
            else:
                # Failure
                txt = '** FAIL **'
                failed += 1

            # Emit log lines for each test
            comment = ('%s %s (%.1f/%.1f) - %s' % 
                       (txt, section, duration, timeout, log_line))
            self.log(comment)

            total += 1

        # Emit a summary log line
        if not failed:
            txt = '++  OK  ++ System passed all %d tests.' % total
        else:
            txt = '** FAIL ** System failed %d/%d tests.' % (failed, total)
        self.log(txt)


if __name__ == '__main__':
    pt = PerformanceTest()
    pt.run()
