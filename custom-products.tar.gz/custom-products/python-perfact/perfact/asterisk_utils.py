#!/usr/bin/env python2
# -*- coding: utf-8 -*-
#
# asterisk.py  -  utilities for accessing an asterisk phone PBX
#
# $Revision: 0.1 $
#
# Copyright (C) 2017 Lars Bergmann <lars.bergmann@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
# $Id: asterisk.py,v 0.1 2017/06/07 10:10:00 perfact Exp $

from __future__ import print_function
import xmlrpclib
import asterisk.manager
import time
import systemd.journal
import socket
import ConfigParser
from perfact.generic import safe_syscall
from perfact.generic import json_decode

socket.setdefaulttimeout(10)

name = 'asterisk_utils'
logwarn = systemd.journal.stream(name, systemd.journal.LOG_WARNING)
logerr  = systemd.journal.stream(name, systemd.journal.LOG_ERR)
loginfo = systemd.journal.stream(name, systemd.journal.LOG_INFO)

def ast_call(cdict, host, username, password):
    '''
    Generic call for asterisk-stuff from manager-interface
    cdict must be a asterisk-AMI-command wrapped in a dictionary
    '''
    # LB: added this loop to make sure call will be recieved
    for i in range(10):
        try:
            manager = asterisk.manager.Manager()
            manager.connect(host)
            manager.login(username, password)
            response_raw = manager.send_action(cdict)
            response = response_raw.headers
            manager.close()
            break
        except Exception as error:
            print(error, file=logerr)
            response = {'Error' : 'Error'}
            time.sleep(0.1)

    return response

def ast_sync(host='192.168.42.37'):
    '''
    call sync script on asterisk machine to get asterisk database
    decode json and return python data structure to zope
    '''
    retcode, result = safe_syscall(
        'ssh perfact@' + host + ' -x /opt/perfact/asterisk/sync2ema.py', raisemode=True
    )
    return json_decode(result)
