#!/usr/bin/env python
#
# performancemeter.py - Module for building a system performance meter.
#

import time  # timestamp formatting
import texttable  # for formatting SQL results
import os  # for special data providers (load etc.)
import signal  # Kill signal types
import smtplib  # for sending notification emails
import socket  # for gethostname()
import email.header  # for header formatting
import perfact.generic  # for safe_syscall, to_string
import re  # for logfile regexp matching
try:
    # python2
    # for testing web servers (replace with requests?)
    from urllib2 import urlopen
except ImportError:
    # python3
    from urllib.request import urlopen
import functools  # for partial pre-evaluation of parameters
import select  # for waiting for socket to be readable
import psycopg2  # for creating connections


def encode_email_header(value, encoding='utf-8'):
    '''Return encoded version of the value.  Input is utf-8-encoded
    8bit or universal string. Output is ascii.'''
    # Make sure we have an 8bit encoded string
    if type(value) == type(u''):
        value = value.encode(encoding)
    return str(email.header.Header(value, encoding))


def get_pfsysteminfo(kind='id'):
    assert kind in ['id', 'name']
    retcode, output = perfact.generic.safe_syscall(
        ['/bin/cat', '/etc/pfsystem'+kind])
    if retcode == 0:
        return output.strip()
    return 'unknown'


def mail_loopback():
    '''Send an email to loopback@localhost and see if it
    appears in /tmp/postfix_loopback.
    '''
    host = socket.gethostname()
    now = str(time.time())
    body = ('Loopback test at %s' % now)
    try:
        smtp = smtplib.SMTP('localhost')
        smtp.sendmail('root@%s' % host,
                      ['loopback@localhost', ],
                      body)
    except smtplib.SMTPException:
        raise
    time.sleep(1)  # Magic number, to wait for delivery
    output = open('/tmp/postfix_loopback', 'rb').read().decode('utf-8')
    assert output.find(body) != -1, "Signal not found."
    os.remove('/tmp/postfix_loopback')
    return


class NotificationPool:
    '''Collect notifications for email recipients, send them in an
    aggregated form when a flush() signal comes.'''

    def __init__(self, sender='no-reply@perfact.de',
                 default_recipients=['devel-testers@perfact.de', ],
                 hostname=None, logger=None):
        self.sender = sender
        self.default_recipients = default_recipients
        self.hostname = (hostname or socket.gethostname())
        self.pfsystemid = get_pfsysteminfo('id')
        self.pfsystemname = get_pfsysteminfo('name')
        self.pool = {}
        self.logger = logger

    def send(self, recipients, subject, report):
        '''Send a notification. Provide a recipients list, a subject and a
        pure text report. The message is not sent immediately, but
        accumulated until the next "flush".
        '''
        if not recipients:
            recipients = self.default_recipients
        for recipient in recipients:
            # Add a pool for this recipient
            if recipient not in self.pool:
                self.pool[recipient] = []
            # Add a subject/report to the pool
            self.pool[recipient].append({
                'subject': subject,
                'report': report,
            })

    def flush(self):
        '''Send all emails collected.'''
        template = '''\
From: {sender}
To: {recipient}
Subject: {subject}
Content-Transfer-Encoding: 8bit
Content-Type: text/plain; charset="UTF-8"
X-PerFact-System-ID: {pfsystemid}
X-PerFact-System-Name: {pfsystemname}

This email has been sent to you by the server "{hostname}"
because you are a registered recipient.

{report}

This is an automatically generated email. Please do not reply.
'''
        for recipient in self.pool.keys():
            messages = self.pool[recipient]
            subjects = [m['subject'] for m in messages]
            subject = subjects[0]
            if len(subjects) > 1:
                subject += (' and %d more' % (len(subjects)-1))

            # Build aggregated message report
            elements = []
            for message in messages:
                elements.append('%(subject)s\n\n%(report)s' % message)
            report = '\n\n'.join(elements)

            # Compose body
            body = template.format(
                sender=perfact.generic.to_string(self.sender),
                recipient=perfact.generic.to_string(recipient),
                subject=encode_email_header(subject),
                hostname=self.hostname,
                pfsystemid=self.pfsystemid,
                pfsystemname=self.pfsystemname,
                report=perfact.generic.to_string(report)
            )

            # Send email
            try:
                smtp = smtplib.SMTP('localhost')
                smtp.sendmail(self.sender,
                              [recipient, ],
                              body)
                if self.logger:
                    self.logger.info(
                        'SMTP notification sent to {0} with {1} message(s)'
                        .format(recipient, len(messages)))
            except smtplib.SMTPException:
                if self.logger:
                    self.logger.error(
                        'SMTP failure sending to {0}'
                        .format(recipient))
            finally:
                # Remove messages from pool.
                del self.pool[recipient]


class PerformanceValue:

    '''Provider class for a measurement value.'''

    def __init__(self, name,
                 safe_interval=(0, 100000),
                 fail_interval=(0, 100000),
                 recover_trigger=0,
                 notify_trigger=0,
                 notify_pool=None,
                 notify_subject=None,
                 notify_body=None,
                 notify_recipients=None,
                 logger=None,
                 performance_meter=None,
                 period=0):
        self.name = name
        # Interval denoting safe operation
        # Upper value is a magic number, just absurdly high
        self.safe_interval = safe_interval
        # Interval outside of which a failure is imminent
        self.fail_interval = fail_interval
        # The period is the number of seconds which should pass
        # between tests (at least).
        self.period = period
        # In last_execution we keep the time.time() value of the last
        # execution.
        self.last_execution = 0
        self.value = 0
        self.details = ''
        self.performance_meter = performance_meter
        self.log_format = (
            '%(ts)s %(signal)s [%(value)s] %(name)s '
            'S%(safe_interval)s F%(fail_interval)s')
        self.details_format = '-details- %(line)s'
        self.recover_format = '-recover- %(line)s'

        self.recover_trigger = recover_trigger
        self.recover_report = ''
        self.recover_count = 0

        # After how many repeats of a warning level do we want
        # notification?
        self.notify_trigger = notify_trigger
        # Either a string with email addresses or a command which will
        # notify.
        # A proxy object with a "send" method, used for pooling messages
        self.notify_recipients = notify_recipients
        self.notify_subject = (
            notify_subject or
            'PerFact Server {signal} on {hostname}: {value} {name}')
        self.notify_body = notify_body or ''
        self.notify_report = ''
        self.notify_alerted = False
        self.notify_count = 0

    def get_data(self):
        '''Collect all information in a structured data container. This data
        can be used for logbook formatting or for transmission as
        JSON encoded data.
        '''
        data = dict(self.__dict__)
        # Remove non-serializable object pointers
        for key in data.keys():
            if (perfact.generic.get_type(data[key]) not in
                ('float', 'double', 'int', 'long',
                 'str', 'unicode', 'bytes',
                 'list', 'tuple', 'set', 'dict')):
                del data[key]
        return data

    def write_log(self):
        my_logger = self.performance_meter.logger
        if my_logger:
            printer = {
                ' OK ': my_logger.info,
                'WARN': my_logger.warning,
                'FAIL': my_logger.error,
            }[self.signal]
        else:
            def default_writer(msg):
                print(msg)
            printer = default_writer

        fmt = self.log_format % self.__dict__
        printer(fmt)
        if self.details and self.signal != ' OK ':
            for line in self.details.split('\n'):
                self.line = line
                fmt = self.details_format % self.__dict__
                printer(fmt)

        if self.recover_report:
            for line in self.recover_report.split('\n'):
                self.line = line
                fmt = self.recover_format % self.__dict__
                printer(fmt)

    def sweep(self):
        '''Perform a sensor measurement.'''
        # Don't do anything if the minimum period of time has not yet
        # elapsed.
        now = time.time()
        if now - self.last_execution < self.period:
            return
        self.last_execution = now
        # Store the timestamp
        self.time = time.time()
        self.ts = time.strftime('%Y-%m-%dT%H:%M:%S',
                                time.localtime(self.time))
        # Recalculate the value and translate to OK, WARN, FAIL
        try:
            self.recalc()
        except Exception as err:
            # Construct a failure with a dummy value, but don't notify
            # or recover, only log.
            self.value = 0
            self.signal = 'FAIL'
            self.details = repr(err)
            self.write_log()
            return
        self.get_signal()
        # Check if a recovery needs to be performed
        self.check_recovery()
        self.write_log()
        self.check_notification()

    def check_recovery(self):
        '''Check if we can perform a recovery.'''
        self.recover_report = ''
        if not self.recover_trigger:
            return
        if self.signal == ' OK ':
            self.recover_count = 0
            return
        self.recover_count += 1
        if self.recover_count >= self.recover_trigger:
            self.recover_report = 'Recovery performed!'
            self.recover()
            self.recover_count = 0

    def in_interval(self, value, interval):
        return ((value >= interval[0]) and
                (value <= interval[1]))

    def get_signal(self):
        '''Transform the calculated value into one of the signals " OK ",
        "WARN" or "FAIL",
        '''
        if self.in_interval(self.value, self.safe_interval):
            self.signal = ' OK '
        elif self.in_interval(self.value, self.fail_interval):
            self.signal = 'WARN'
        else:
            self.signal = 'FAIL'
        return self.signal

    def recalc(self):
        '''Renew the value and details.'''
        # The value should be an integer or float
        self.value = 0
        # Details should be a freeform text
        self.details = ''

    def recover(self):
        '''Override this with a recovery procedure.'''
        pass

    def check_notification(self):
        '''Check if we need to notify.'''
        if not self.notify_trigger:
            return
        if self.signal == ' OK ':
            if self.notify_alerted:
                # Send a resolution notification
                self.notify_resolve()
            self.notify_alerted = False

        if self.signal != 'FAIL':
            self.notify_count = 0
            return

        self.notify_count += 1
        if self.notify_count >= self.notify_trigger:
            if not self.notify_alerted:
                # Send out an alert
                self.notify()
                self.notify_alerted = True
            self.notify_count = 0

    def notify(self):
        '''Override this with a notification procedure.'''
        subject = self.notify_subject.format(
            signal=self.signal,
            hostname=self.performance_meter.notify_pool.hostname,
            value=self.value,
            name=self.name)
        report = self.notify_body
        report += self.ts + '\n' + (self.notify_report or self.details)
        self.performance_meter.notify_pool.send(
            self.notify_recipients, subject, report)

    def notify_resolve(self):
        '''Basic notification resolution mail.'''
        self.notify()


class PerformanceValueSQL(PerformanceValue):

    def __init__(self, name,
                 safe_interval=(0, 100000),
                 fail_interval=(0, 100000),
                 logger=None,
                 dbconn=None, query=None,
                 recover_trigger=0,
                 recover_query=None,
                 notify_trigger=0,
                 notify_recipients=None,
                 notify_subject=None,
                 notify_body=None,
                 mode='count',
                 col_widths=None,
                 performance_meter=None,
                 period=0,
                 ):

        PerformanceValue.__init__(
            self,
            name=name,
            safe_interval=safe_interval,
            fail_interval=fail_interval,
            recover_trigger=recover_trigger,
            notify_trigger=notify_trigger,
            notify_recipients=notify_recipients,
            notify_subject=notify_subject,
            notify_body=notify_body,
            logger=logger,
            performance_meter=performance_meter,
            period=period,
            )
        self.query = query
        self.recover_query = recover_query
        self.mode = mode
        self.col_widths = col_widths

    def recalc(self):
        # Retrieve fresh connector from performance meter
        self.dbconn = self.performance_meter.dbconn
        # For safety, make sure there's no open transaction before starting.
        self.dbconn.rollback()
        self.cursor = self.dbconn.cursor()
        self.cursor.execute(self.query)
        data = self.cursor.fetchall()
        names = [a.name for a in self.cursor.description]
        self.cursor.close()
        self.dbconn.commit()

        if self.mode == 'count':
            self.value = len(data)
        elif self.mode == 'sum':
            self.value = 0
            for item in data:
                self.value += item[-1]

        if data:
            table = texttable.Texttable()
            table.set_deco(texttable.Texttable.VLINES)
            table.set_cols_width(self.col_widths or ([12, ]*len(names)))
            table.set_cols_dtype(['t']*len(names))
            table.set_cols_align(['l', ] * len(names))
            table.add_rows([names, ] + data)
            self.details = table.draw()
        else:
            self.details = ''

    def recover(self):
        if not self.recover_query:
            return
        # Also accept a callable as a recovery
        if callable(self.recover_query):
            self.recover_report = self.recover_query()
            return
        self.dbconn = self.performance_meter.dbconn
        self.cursor = self.dbconn.cursor()
        self.cursor.execute(self.recover_query)
        self.cursor.close()
        self.dbconn.commit()


class PerformanceValueCall(PerformanceValue):

    def __init__(self, name,
                 safe_interval=(0, 100000),
                 fail_interval=(0, 100000),
                 logger=None,
                 cmd=None,
                 recover_trigger=0,
                 recover_cmd=None,
                 notify_trigger=0,
                 notify_recipients=None,
                 notify_subject=None,
                 notify_body=None,
                 performance_meter=None,
                 period=0,
                 ):
        PerformanceValue.__init__(
            self,
            name=name,
            safe_interval=safe_interval,
            fail_interval=fail_interval,
            recover_trigger=recover_trigger,
            notify_trigger=notify_trigger,
            notify_recipients=notify_recipients,
            notify_subject=notify_subject,
            notify_body=notify_body,
            logger=logger,
            performance_meter=performance_meter,
            period=period,
            )
        self.cmd = cmd
        self.recover_cmd = recover_cmd

    def recalc(self):
        if callable(self.cmd):
            retcode, output = 0, self.cmd()
        else:
            retcode, output = perfact.generic.safe_syscall(self.cmd)
        if retcode != 0:
            self.value = self.fail_interval[1] + 1
            self.details = 'Program failed (%d): %s' % (retcode, output)
        else:
            value, details = output.split(None, 1)
            if '.' in value:
                self.value = float(value)
            else:
                self.value = int(value)
            self.details = details.strip()

    def recover(self):
        if callable(self.recover_cmd):
            retcode, output = 0, self.recover_cmd()
        else:
            retcode, output = perfact.generic.safe_syscall(self.recover_cmd)

        if retcode != 0:
            self.value = self.fail_interval[1] + 1
            self.details = 'Program failed (%d): %s' % (retcode, output)


class PerformanceValueLogtail(PerformanceValue):

    def __init__(self, name,
                 safe_interval=(0, 100000),
                 fail_interval=(0, 100000),
                 logger=None,
                 cmd=None,
                 recover_trigger=0,
                 recover_cmd=None,
                 notify_trigger=0,
                 notify_recipients=None,
                 notify_subject=None,
                 notify_body=None,
                 log_filename=None,
                 log_regexp=None,
                 log_columns=None,
                 performance_meter=None,
                 period=0,
                 ):
        PerformanceValue.__init__(
            self,
            name=name,
            safe_interval=safe_interval,
            fail_interval=fail_interval,
            recover_trigger=recover_trigger,
            notify_trigger=notify_trigger,
            notify_recipients=notify_recipients,
            notify_subject=notify_subject,
            notify_body=notify_body,
            logger=logger,
            performance_meter=performance_meter,
            period=period,
            )
        self.recover_cmd = recover_cmd

        # Example logfile and regular expression
        default_log = '/var/log/apache2/access.log'
        default_re = (r'^(\d+\.\d+\.\d+\.\d+) [^ ]* [^ ]* \[[^]]*\] '
                      r'"([^ ]* [^ ]*) [^ ]*" ([45]\d\d) ')
        default_cols = [('ipaddr', 16), ('url', 60), ('code', 4), ]
        self.log_filename = log_filename or default_log
        self.log_regexp = re.compile(log_regexp or default_re)
        self.log_columns = log_columns or default_cols
        # Internal variables
        self.log_handle = None
        self.log_carryover = ''
        # Attach to logfile immediately
        self.attach(init=True)
        return

    def attach(self, init=False):
        '''Attach to logfile and follow. '''
        self.log_handle = open(self.log_filename, 'r')
        if init:
            # Go to the end of the file
            self.log_handle.seek(0, 2)
            # And flush for safety
            self.log_handle.read()
        return self.log_handle

    def readlines(self):
        '''Get as many lines as possible from the logfile. Reattach if the
        logfile has been closed.'''
        data = self.log_handle.read()
        stat = os.fstat(self.log_handle.fileno())
        posn = self.log_handle.tell()
        if stat.st_nlink == 0:
            # File has been removed. Re-attach
            self.log_handle.close()
            self.attach()
        elif stat.st_size < posn:
            # File has shrunk, go back to start
            self.log_handle.seek(0, 0)
            data = self.log_handle.read()
        lines = data.split('\n')
        # Handle half-read lines: append carryover to first line
        lines[0] = self.log_carryover + lines[0]
        # Then pop last line off and move into carryover
        self.log_carryover = lines.pop()
        return lines

    def recalc(self):
        '''Fetch new lines, match up with the regular expression and build
        details table if hits have been found.'''
        lines = self.readlines()
        count = 0
        data = []
        for line in lines:
            match = self.log_regexp.match(line)
            if match is None:
                continue
            count += 1
            data.append(match.groups())
        self.value = count
        if data:
            names = list(map(lambda a: a[0], self.log_columns))
            widths = list(map(lambda a: a[1], self.log_columns))
            table = texttable.Texttable()
            table.set_deco(texttable.Texttable.VLINES)
            table.set_cols_width(widths)
            table.set_cols_dtype(['t']*len(names))
            table.set_cols_align(['l', ] * len(names))
            table.add_rows([names, ] + data)
            self.details = table.draw()
        else:
            self.details = ''
        return

    def recover(self):
        return PerformanceValueCall.recover(self)


# Providers of measurement values which can be used by
# PerformanceValueCall instances:

def loadbalancer_stats():
    '''Read the status page from the load balancer, read the values and
    return the maximum business along with a shortened report.'''

    cmd = ('timeout 4 lynx -connect_timeout=2 -read_timeout=2'
           ' --dump -width=150 http://localhost:8980/balancer-manager')
    output = os.popen(cmd, 'r').readlines()

    # Parse the output
    signal_title = 'Worker URL'
    signal_busycol = 'Busy'
    signal_end = '_____________'
    busycol = 0
    bvalues = []
    report = []
    line = ''

    while True:
        if not output:
            break
        line = output.pop(0)
        if signal_title in line:
            report.append('-'+line)
            break

    try:
        busycol = line.index(signal_busycol)
    except ValueError:
        busycol = None

    while True:
        if not output or not busycol:
            break
        line = output.pop(0)
        if signal_end in line:
            break
        report.append('-'+line)
        bvalue = int(line[busycol:].split()[0])
        bvalues.append(bvalue)

    try:
        value = max(bvalues)
    except ValueError:
        value = 1000  # Guarantee failure
        report.append(
            'Business could not be determined due to server failure\n')
    details = ''.join(report)
    return "%d %s" % (value, details)


def loadbalancer_recover():
    '''What to do if the load balancer says nothing.'''
    os.system('echo "/etc/init.d/apache2 restart" | at now')
    return '0 apache restarted'


def io_stats(host=None, sample_seconds=1):
    '''Make an iostat report and put the percentage of io-wait in front.
    '''
    cmd = ['iostat', '-y', str(sample_seconds), '1']
    if host:
        cmd = ['ssh', host, ] + cmd
    retcode, output = perfact.generic.safe_syscall(cmd)
    if retcode:
        return "0 ERROR"
    # Get rid of illegal characters
    output = output.replace('\x00', '')
    # The output is already good for details reporting.
    # We just need to extract the correct figure to use as a measurement
    line = output.split('\n')[3]  # fourth line
    value = line.strip().split()[3]  # fourth value
    return '%s %s' % (value, output)


def io_writespeed(host=None):
    '''Make a dd measurement of write performance and return the result.
    '''
    cmd = ['dd', 'if=/dev/zero', 'of=/root/measure_dd.img',
           'bs=50M', 'count=1', 'oflag=dsync']
    if host:
        cmd = ['ssh', host, ] + cmd
    retcode, output = perfact.generic.safe_syscall(cmd)
    if retcode:
        return '0 ERROR'
    line = output.strip().split('\n')[-1]
    result = line.split(', ')[-1]
    if result.split()[-1] != 'MB/s':
        return '0 UNREADABLE: '+result
    return result


def io_freespace(host=None, device='/dev/sda1', inodelimit=1000):
    '''Analyze the local free disk space on the given host.
    Return the number of MiB free space on the given device.
    '''
    cmd = ['df', '--block-size=1048576',
           '--output=source,target,fstype,itotal,iavail,size,avail',
           device]
    if host:
        cmd = ['ssh', host, ] + cmd
    retcode, output = perfact.generic.safe_syscall(cmd)
    if retcode:
        return '0 ERROR %d %s' % (retcode, output)
    lines = output.strip().split('\n')
    if len(lines) != 2:
        return '0 ERROR num lines not 2 but %d' % len(lines)
    line = lines[-1]
    source, target, fstype, itotal, iavail, size, avail = line.split()
    if int(iavail) < inodelimit:
        return '0 LOWINODES '+output
    return avail + ' ' + output


def db_exclusivelocks(dbconn=None, version='10', parent=None):
    '''The dbconn API is deprecated.'''
    query = '''\
select a.pid as a_pid,
       a.mode as a_mode,
       aa.query_start::text as a_query_start,
       aa.query as a_query,
       b.pid as b_pid,
       b.mode as b_mode,
       bb.query as b_query
  from pg_locks a
  join pf_measure_activity aa
    on aa.pid = a.pid
   and aa.query_start < now() - interval '120 seconds'
  join pg_locks b
    on b.database=a.database
   and b.relation=a.relation
   and b.granted=true
   and a.granted = false
  join pf_measure_activity bb
    on bb.pid = b.pid
 where a.mode ~ 'Exclusive'
union
select aa.pid as a_pid,
       'waiting' as a_mode,
       aa.query_start::text as a_query_start,
       aa.query as a_query,
       null as b_pid,
       null as b_mode,
       null as b_query
  from pf_measure_activity aa
 where aa.waiting
   and aa.query_start < now() - interval '1 hour'
order by 1, 2
'''
    if not dbconn and not parent:
        return query
    if not dbconn:
        dbconn = parent.dbconn

    cur = dbconn.cursor()
    cur.execute(query)
    data = cur.fetchall()
    cur.close()
    dbconn.commit()
    pids = []
    for item in data:
        pida = item[0]
        pidb = item[4]
        if pida and pida not in pids:
            pids.append(pida)
        if pidb and pidb not in pids:
            pids.append(pidb)

    for pid in pids:
        os.kill(pid, signal.SIGTERM)

    return "%d %s" % (len(pids), str(pids))


def db_dosattempt(dbconn=None, version='10', parent=None):
    '''The dbconn API is deprecated.'''
    query = '''\
select pid,
       substr(aa.query,1, 200) as query,
       aa.query_start::text as query_start
  from pf_measure_activity aa
 where aa.query in (
   select bb.query
     from pf_measure_activity bb
    where bb.query !~* '^(commit|rollback|set )'
      and bb.query_start < now() - interval '3 seconds'
      and not bb.waiting
    group by bb.query
   having count(bb.pid) > 3)
 order by 2, 1
'''
    if not dbconn and not parent:
        return query
    if not dbconn:
        dbconn = parent.dbconn

    cur = dbconn.cursor()
    cur.execute(query)
    data = cur.fetchall()
    cur.close()
    dbconn.commit()
    pids = []
    for item in data:
        pid = item[0]
        if pid not in pids:
            pids.append(pid)
    for pid in pids:
        os.kill(pid, signal.SIGTERM)

    return "%d %s" % (len(pids), str(pids))


def db_brokencaches(dbconn=None, recover=False, parent=None):
    '''The dbconn API is deprecated.'''
    query = '''\
with active_caches as (
select cachereq_cachestat_id as active_cachestat_id,
       min(extract(epoch from (now() - cachereq_modtime))
           )::bigint as active_secondspast,
       count(cachereq_id) as active_numrequests
  from cachereq
 where cachereq_cachereqlc_id = 3
   and cachereq_createtime > now() - interval '5 minutes'
 group by 1
), inactive_caches as (
select cachereq_cachestat_id as inactive_cachestat_id,
       min(extract(epoch from (now() - cachereq_modtime))
           )::bigint as inactive_secondspast,
       count(cachereq_id) as inactive_numrequests
  from cachereq
 where (
       cachereq_cachereqlc_id = 1
   and cachereq_executein <= 0
   and cachereq_createtime < now() - interval '5 minutes'
       ) or (
       cachereq_cachereqlc_id = 1
   and cachereq_executein > 0
   and cachereq_repeat = false
   and cachereq_createtime + interval '1 second' * cachereq_executein
       < now() - interval '1 hour'
       )
 group by 1
)
select cachestat_managerid as managerid,
       char_list(distinct cachestat_tablename) as tablenames,
       sum(inactive_numrequests) as numrequests
  from cachestat
  join inactive_caches
    on inactive_cachestat_id = cachestat_id
  left
  join active_caches
    on active_cachestat_id = cachestat_id
 where active_cachestat_id is null
 group by 1
 order by 1
'''
    if not dbconn:
        dbconn = parent.dbconn

    cur = dbconn.cursor()
    cur.execute(query)
    data = cur.fetchall()
    cur.close()
    dbconn.commit()
    hosts = [a[0] for a in data]
    if recover:
        for host in hosts:
            cmd = ['/etc/init.d/dbcached', 'restart']
            if host:
                cmd = ['ssh', host] + cmd
            perfact.generic.safe_syscall(cmd)

    return "%d %s" % (len(hosts), str(hosts))


def mnt_stat(path):
    try:
        os.stat(path)
        return '0 OK'
    except OSError:
        return '1 ERROR'


def restart_service(service, host='localhost'):
    # assert host in allowed_hosts
    # assert service in allowed_services
    ssh_cmd = 'sh -c ' if (host == 'localhost') else ('ssh %s ' % host)
    os.system(ssh_cmd + '"systemctl restart %s" </dev/null' % service)
    return "Service restart triggered."


def test_zeo(host='localhost', recover=False,
             memlimit=1000000,
             zope_version='2.13',
             zeo_service_name='zope@{zope_version}-zeo-emazeo',
             zeo_pidfile='Z2.pid'):
    '''Test ZEO on the given host. ZEO must answer on the given host. The
    port is extracted from zeo.conf.'''
    ssh_cmd = 'sh -c ' if (host == 'localhost') else ('ssh %s ' % host)
    instances = os.popen(
            ssh_cmd +
            ('''"grep --with-filename \\"^ *address \\" ''') +
            ('''/var/lib/zope%s/zeo/*/etc/zeo.conf"''' % zope_version) +
            ''' | sed 's#etc/zeo.conf: *address \\([^:]*:\\)\\?#bin/zeoctl #' '''
            , 'r').read().strip().split('\n')
    instances = list(map(lambda a: (a.split()[0], int(a.split()[1])),
                         instances))
    broken = []
    for instance, port in instances:
        # Perform test proper
        soc = socket.socket()
        soc.settimeout(2)
        try:
            soc.connect((host, port))
        except:  # For instance connection refused or timeout
            broken.append([host, port, instance, 'could not connect'])
            continue
        ready = select.select([soc], [], [], 2)
        if not ready[0]:
            broken.append([host, port, instance, 'unreadable'])
            del soc
            continue
        # Check for correct signature
        signature = '\x00\x00\x00\x05Z3101'
        response = soc.recv(len(signature))
        if response != signature:
            broken.append([host, port, instance, 'got: '+response])
            del soc
            continue
        # Also check memory usage
        pidfile = instance.replace(
            'bin/zeoctl', 'var/{zeo_pidfile}'.format(zeo_pidfile=zeo_pidfile))
        rssmem = os.popen(
            ssh_cmd +
            '''"ps -o rss= \\$(cat %s)" ''' % pidfile,
            'r').read().strip()
        if int(rssmem) > memlimit:
            broken.append([host, port, instance, 'mem limit: '+rssmem])
        del soc
    value = len(broken)
    details = str(broken)
    if recover:
        for host, port, instance, reason in broken:
            zeo_service_name = zeo_service_name.format(
                zope_version=zope_version)
            ssh_cmd = 'sh -c ' if (host == 'localhost') else ('ssh %s ' % host)
            os.system(
                    ssh_cmd +
                    '"service {zeo_service_name} restart" '
                    '< /dev/null'.format(
                        host=host,
                        zeo_service_name=zeo_service_name))
    return "%d %s" % (value, details)


def test_zope(host='localhost', recover=False,
              memlimit=1000000,
              zope_service_name='zope@{zope_version}-instance-{inst}',
              zope_version='2.13'):
    '''Test a host's Zope instances, return list of failed ports.

    The check is made by calling the URL /monitoring_test, expecting
    "OK" as an answer, plus checking resident memory usage via "ps -o
    rss= <pid>". If this surpasses memlimit, the instance is
    considered broken.
    '''
    # assert host in allowed_hosts
    # Retrieve instances installed on the given host.
    ssh_cmd = 'sh -c ' if (host == 'localhost') else ('ssh %s ' % host)
    instances = os.popen(
        ssh_cmd +
        ('''"grep --with-filename \\"%define HTTPPORT \\" ''') +
        ('''/var/lib/zope%s/instance/*/etc/zope.conf" | ''' % zope_version) +
        '''sed 's#etc/zope.conf:%define HTTPPORT#bin/zopectl#' ''',
        'r').read().strip().split('\n')
    instances = list(map(lambda a: (a.split()[0], int(a.split()[1])),
                         instances))
    broken = []
    for instance, port in instances:
        # Perform test proper
        url = 'http://%s:%d/monitoring_test'
        try:
            # Fail on timeout or other problems
            response = urlopen(url % (host, port), timeout=2).read()
        except:
            broken.append([host, port, instance, 'no answer'])
            continue
        if response != 'OK':
            broken.append([host, port, instance, 'got: '+response])
        # Also check memory usage
        pidfile = instance.replace('bin/zopectl', 'var/Z2.pid')
        rssmem = os.popen(
                ssh_cmd +
                '''"ps -o rss= \\$(cat %s)" ''' % pidfile,
                'r').read().strip()
        if int(rssmem) > memlimit:
            broken.append([host, port, instance, 'mem limit: '+rssmem])

    value = len(broken)
    details = str(broken)
    if recover:
        for host, port, instance, reason in broken:
            # get instance name
            inst = instance.split('/')[5]
            if '{inst}' in zope_service_name:
                zope_service_name = zope_service_name.format(
                    zope_version=zope_version, inst=inst)
            else:
                zope_service_name = zope_service_name.format(
                    zope_version=zope_version)
        os.system(
                ssh_cmd +
                '"service {zope_service_name} restart" '
                '< /dev/null'.format(
                    zope_service_name=zope_service_name))

    return "%d %s" % (value, details)


def test_systemdfailed():
    '''Test if there are failed systemd services'''
    retcode, output = perfact.generic.safe_syscall(
        ['/bin/systemctl', '--failed', '--no-legend'])
    if retcode != 0:
        return "%d %s" % (retcode, output)
    if len(output) > 0:
        return "%d %s" % (len(output.split('\n'))-1, output)
    return "0 0"


def dummy_delay(delay=20):
    '''Dummy test designed to check the function of timeouts.
    '''
    time.sleep(delay)
    return "0 0"


class PerformanceMeter:
    '''Run a number of tests periodically and trigger alarms.'''
    def __init__(self, logger=None, notify_pool=None,
                 interval=10,
                 upload_interval=600,
                 upload_recipient='devel-testers@perfact.de',
                 recoveries_enabled=True,
                 notifications_enabled=True,
                 dbconn_string='dbname=perfactema user=postgres',
                 statement_timeout=2,
                 timeout=10,
                 upload_limit=100):
        self.performance_values = []
        self.interval = interval
        self.logger = logger
        self.notify_pool = notify_pool
        self.upload_interval = upload_interval
        self.upload_recipient = upload_recipient
        self.upload_last = None
        self.upload_data = []
        self.upload_limit = upload_limit
        # Force transfer the logger into the notification pool
        if self.notify_pool and self.logger:
            self.notify_pool.logger = self.logger
        self.recoveries_enabled = recoveries_enabled
        self.notifications_enabled = notifications_enabled
        self.dbconn_string = dbconn_string
        self.dbconn = None
        self.statement_timeout = statement_timeout
        self.timeout = timeout

    def setup(self):
        '''Routine to be called once at the beginning of each loop.
        Sets up connections needed for several measurements.
        '''
        if self.dbconn_string:
            self.dbconn = psycopg2.connect(self.dbconn_string)
            if self.statement_timeout:
                # Set statement timeout
                cur = self.dbconn.cursor()
                cur.execute('set statement_timeout to %d' %
                            (self.statement_timeout*1000))
                cur.close()
                self.dbconn.commit()
        else:
            self.dbconn = None
        # Set the alarm clock
        self.reset_alarm()

    def teardown(self):
        '''Routine called once at the end of each loop. Tears down
        any connections.
        '''
        # Stop the alarm clock
        self.disable_alarm()

        if self.dbconn:
            self.dbconn.close()

    def reset_alarm(self, force_timeout=None):
        '''Reset the alarm timer if a timeout is set.
        '''
        timeout = force_timeout if force_timeout is not None else self.timeout
        if timeout is not None:
            signal.alarm(timeout)

    def disable_alarm(self):
        '''Disable the alarm completely (by setting to 0 seconds)'''
        self.reset_alarm(0)

    def upload(self):
        '''Periodically upload all data as an email.'''
        # Append new list of records
        data = []
        for performance_value in self.performance_values:
            data.append(performance_value.get_data())

        if self.upload_interval is None:
            return
        if not self.upload_recipient:
            return
        self.upload_data.append(data)
        while len(self.upload_data) > self.upload_limit:
            self.upload_data.pop(0)

        now = time.time()
        if not (self.upload_last is None or
                self.upload_last + self.upload_interval < now):
            return

        # Perform upload
        self.upload_last = now
        # Build email report
        template = '''\
From: {sender}
To: {recipient}
Subject: {subject}
Content-Transfer-Encoding: 8bit
Content-Type: text/json; charset="UTF-8"
X-PerFact-System-ID: {pfsystemid}
X-PerFact-System-Name: {pfsystemname}

{data}
'''
        # Compose body
        np = self.notify_pool
        recipient = self.upload_recipient
        subject = 'Monitoring data upload'
        data = perfact.generic.to_string(
            perfact.generic.json_encode(self.upload_data))
        body = template.format(
            sender=perfact.generic.to_string(np.sender),
            recipient=perfact.generic.to_string(recipient),
            subject=encode_email_header(subject),
            hostname=np.hostname,
            pfsystemid=np.pfsystemid,
            pfsystemname=np.pfsystemname,
            data=data
        )

        # Send email
        try:
            smtp = smtplib.SMTP('localhost')
            smtp.sendmail(np.sender,
                          [recipient, ],
                          body)
        except smtplib.SMTPException:
            if self.logger:
                self.logger.error('SMTP failure sending to {0}'
                                  .format(recipient))
        finally:
            self.upload_data = []

    def sweep(self):
        for performance_value in self.performance_values:
            # Force links to this object
            performance_value.performance_meter = self
            # Execute the value determination procedure
            performance_value.sweep()
            # Reset the alarm clock frequently
            self.reset_alarm()
        # Wrap up by flushing notifications out and writing a breaker
        # into the log.
        if self.notify_pool:
            self.notify_pool.flush()
        if self.logger:
            self.logger.info('---')
        # Send all data home periodically
        self.upload()

    def run(self):
        while True:
            self.setup()
            self.sweep()
            self.teardown()
            time.sleep(self.interval)

    def setup_generic(self, dbconn=None):
        '''Generic sensors, should be applicable in any DB-Utils installation.
        Note that the dbconn API is deprecated.'''
        self.setup_postgresql()
        self.setup_apache()
        self.setup_server()
        self.setup_zope()

    def setup_postgresql(self, dbconn=None,
                         bigtables_limits=[5000, 7000],
                         version='10'):
        '''PostgreSQL related tests.
        Note that the dbconn API is deprecated.'''
        # Database locks. Show locks if they are too numerous.
        locks_query = '''\
select a.pid as a_pid,
       a.mode as a_mode,
       aa.query_start::text as a_query_start,
       aa.query as a_query,
       b.pid as b_pid,
       b.mode as b_mode,
       bb.query as b_query
  from pg_locks a
  join pf_measure_activity aa
    on aa.pid = a.pid
   and aa.query_start < now() - interval '30 seconds'
  join pg_locks b
    on b.database=a.database
   and b.relation=a.relation
   and b.granted=true
   and a.granted = false
  join pf_measure_activity bb
    on bb.pid = b.pid
order by 1, 2
'''
        self.performance_values.append(
            PerformanceValueSQL(
                name='Database Locks',
                safe_interval=(0, 5),
                fail_interval=(0, 10),
                notify_trigger=5,
                performance_meter=self,
                col_widths=[6, 20, 28, 40, 6, 20, 40, ],
                query=locks_query))

        # Exclusive locks. Break transactions which can lead to
        # lock-ups because they do not free resources quickly enough.
        self.performance_values.append(
            PerformanceValueSQL(
                name='DB Exclusive Locks',
                safe_interval=(0, 0),
                fail_interval=(0, 5),
                notify_trigger=5,
                performance_meter=self,
                query=db_exclusivelocks(),
                col_widths=[6, 20, 28, 40, 6, 20, 40, ],
                recover_trigger=1,
                recover_query=functools.partial(db_exclusivelocks,
                                                version=version,
                                                parent=self),
            ))

        # DoS attemts. Break transactions if many with exactly the
        # same query are busy on the system.
        self.performance_values.append(
            PerformanceValueSQL(
                name='DB Simultaneous Identical Queries',
                safe_interval=(0, 2),
                fail_interval=(0, 8),
                notify_trigger=25,
                col_widths=[15, 50, 20, ],
                performance_meter=self,
                query=db_dosattempt(),
                recover_trigger=1,
                recover_query=functools.partial(db_dosattempt,
                                                version=version,
                                                parent=self),
            ))

        # Active database connections. Warn if too many build up.
        self.performance_values.append(
            PerformanceValueSQL(
                name='Active DB Connections',
                safe_interval=(0, 100),
                fail_interval=(0, 150),
                performance_meter=self,
                notify_trigger=5,
                mode='sum',
                query='''\
select count(*) as num_conn from pf_measure_activity
'''))

        # Postgres Size of Big Tables
        self.performance_values.append(
            PerformanceValueSQL(
                name='MiB Total Size of Large Tables',
                safe_interval=(0, bigtables_limits[0]),
                fail_interval=(0, bigtables_limits[1]),
                performance_meter=self,
                notify_trigger=5,
                period=120,
                mode='sum',
                query='''\
select *, tablemb+indexesmb as totalmb from (
select
  schemaname,
  tablename,
  pg_table_size(schemaname||'.'||tablename) / 1048576 as tablemb,
  pg_indexes_size(schemaname||'.'||tablename) / 1048576 as indexesmb
from
  pg_tables
where
  schemaname !~ '^pg_|^information_schema'
) base
where tablemb+indexesmb >= 50
order by 5 desc
'''))

        # Postgres Log errors
        self.performance_values.append(
            PerformanceValueLogtail(
                name='Postgres Warnings / Errors',
                safe_interval=(0, 0),
                fail_interval=(0, 10),
                notify_trigger=3,
                log_filename=('/var/log/postgresql/postgresql-%s-main.log' %
                              version),
                log_regexp=(r'^(\d+-\d+-\d+ \d+:\d+:\d+) [CEST]* '
                            r'(FATAL|ERROR|WARNING): (.*)$'),
                log_columns=[('time', 22), ('type', 8), ('message', 60)],
            ))

    def setup_apache(self):
        '''Apache related tests.'''
        # Number of errors since last check
        self.performance_values.append(
            PerformanceValueLogtail(
                name='Web Server Errors',
                safe_interval=(0, 5),
                fail_interval=(0, 10),
                notify_trigger=3,
                log_filename='/var/log/apache2/access.log',
                log_regexp=(r'^(\d+\.\d+\.\d+\.\d+) [^ ]* [^ ]* \[[^]]*\] '
                            r'"([^ ]* [^ ]*) [^ ]*" ([45]\d\d) '),
                log_columns=[('ipaddr', 16), ('url', 60), ('code', 4)],
            ))

        # Load balancer. Call out if the load rises above a given
        # level.
        self.performance_values.append(
            PerformanceValueCall(
                name='Maximum Busy on Load Balancer',
                safe_interval=(0, 3),
                fail_interval=(0, 5),
                notify_trigger=5,
                cmd=loadbalancer_stats,
            ))
        self.performance_values.append(
            PerformanceValueCall(
                name='Overload on Load Balancer',
                safe_interval=(0, 999),
                fail_interval=(0, 1000),
                cmd=loadbalancer_stats,
                recover_trigger=1,
                recover_cmd=loadbalancer_recover
            ))

    def setup_server(self):
        '''Basic server tests. '''
        # CPU Load. Warn if above the number of kernels.
        self.performance_values.append(
            PerformanceValueCall(
                name='CPU Load',
                safe_interval=(0, 5),
                fail_interval=(0, 8),
                notify_trigger=5,
                period=60,
                cmd='cat /proc/loadavg',
            ))

        # I/O Waits. Warn if consistently high.
        self.performance_values.append(
            PerformanceValueCall(
                name='% I/O Wait',
                safe_interval=(0, 20),
                fail_interval=(0, 40),
                notify_trigger=5,
                cmd=io_stats,
            ))

        # Write performance. Warn if consistently low.
        self.performance_values.append(
            PerformanceValueCall(
                name='MB/s Write Speed',
                safe_interval=(20, 1000),
                fail_interval=(10, 1000),
                notify_trigger=2,
                period=120,
                cmd=io_writespeed,
            ))

    def setup_zope(self, zeo_service_name='zope@{zope_version}-zeo-emazeo',
                   zeo_pidfile='Z2.pid',
                   zope_service_name='zope@{zope_version}-instance-{inst}'):
        '''ZEO and Zope tests.'''

        self.performance_values.append(
            PerformanceValueCall(
                name='ZEO check failures',
                safe_interval=(0, 0),
                fail_interval=(0, 1),
                notify_trigger=5,
                cmd=functools.partial(test_zeo,
                                      zeo_service_name=zeo_service_name,
                                      zeo_pidfile=zeo_pidfile),
                recover_trigger=2,
                recover_cmd=functools.partial(
                    test_zeo,
                    recover=True,
                    zeo_service_name=zeo_service_name,
                    zeo_pidfile=zeo_pidfile),
            ))
        # Zope instances
        self.performance_values.append(
            PerformanceValueCall(
                name='Zope monitoring failures',
                safe_interval=(0, 0),
                fail_interval=(0, 3),
                notify_trigger=5,
                cmd=functools.partial(
                    test_zope, zope_service_name=zope_service_name),
                recover_trigger=2,
                recover_cmd=functools.partial(
                    test_zope, recover=True,
                    zope_service_name=zope_service_name),
            ))

    def setup_cachecontrol(self, dbconn=None):
        '''Measurements covering possible cache problems.
        Note: the dbconn API is deprecated.'''
        # Slowdown on interactive cache updates.
        self.performance_values.append(
            PerformanceValueSQL(
                name='Slow Interactive Caches',
                safe_interval=(0, 3),
                fail_interval=(0, 10),
                notify_trigger=25,
                performance_meter=self,
                col_widths=[14, 28, 28, 12, 8, ],
                query='''\
select cachestat_tablename as tablename,
       cachereq_params as params,
       cachereq_createtime::text as createtime,
       cachestat_managerid as managerid,
       cachereq_id
  from cachereq
  join cachestat on cachestat_id = cachereq_cachestat_id
 where cachereq_cachereqlc_id = 1
   and cachereq_executein <= 0
   and cachereq_modtime < now() - interval '1 minutes'
'''))

        # Cache Manager health status.
        self.performance_values.append(
            PerformanceValueCall(
                name='Broken Cache Managers',
                safe_interval=(0, 0),
                fail_interval=(0, 1),
                notify_trigger=3,
                cmd=functools.partial(db_brokencaches, parent=self),
                recover_trigger=1,
                recover_cmd=functools.partial(
                    db_brokencaches, parent=self, recover=True),
            ))

        # Stacked cache updates (high delays allowed).
        self.performance_values.append(
            PerformanceValueSQL(
                name='Stacked Trigger Caches',
                safe_interval=(0, 1000),
                fail_interval=(0, 10000),
                notify_trigger=25,
                performance_meter=self,
                mode='sum',
                query='''\
select cachestat_tablename as tablename,
       count(cachereq_id) as requests,
       count(distinct cachereq_params) as unique
  from cachereq
  join cachestat on cachestat_id = cachereq_cachestat_id
 where cachereq_cachereqlc_id = 1
   and cachereq_executein >= 1
   and cachereq_repeat = false
group by 1
order by 2 desc
'''))

        # Errors on caches. If they persist, notify.
        self.performance_values.append(
            PerformanceValueSQL(
                name='Errors in Non-Automatic Caches',
                safe_interval=(0, 0),
                fail_interval=(0, 10),
                notify_trigger=25,
                performance_meter=self,
                col_widths=[12, 28, 9, 20, 40, ],
                query='''\
select cachereq_id,
       cachereq_createtime::text as createtime,
       cachestat_tablename as tablename,
       cachereq_params as params,
       cachereq_error as error
  from cachereq
  join cachestat on cachestat_id = cachereq_cachestat_id
 where cachereq_cachereqlc_id = 4
   and cachereq_repeat = false
   and cachereq_createtime between now() - interval '15 minutes'
   and now() - interval '2 minutes'
''',
                recover_trigger=1,
                recover_query='''\
update cachereq set
       cachereq_modtime = now(),
       cachereq_error = '',
       cachereq_cachereqlc_id = 1,
       cachereq_busy = false,
       cachereq_executein = 9
 where cachereq_cachereqlc_id = 4
   and cachereq_repeat = false
   and cachereq_createtime between now() - interval '15 minutes'
   and now() - interval '2 minutes'
'''))

        # Duplicate cache repeaters
        self.performance_values.append(
            PerformanceValueSQL(
                name='Duplicate Auto-Caches',
                safe_interval=(0, 0),
                fail_interval=(0, 10),
                notify_trigger=25,
                performance_meter=self,
                col_widths=[20, 20, 20, ],
                query='''\
select cachereq_cachestat_id as set_cachestat_id,
       cachereq_params as set_params,
       max(cachereq_id) as set_cachereq_id
  from cachereq
 where cachereq_repeat = true
   and cachereq_cachereqlc_id = 1
 group by 1, 2
having count(cachereq_id) > 1
''',
                recover_trigger=1,
                recover_query='''\
delete from cachereq
 where cachereq_id in (
select cachereq_id
  from cachereq
  join (
select cachereq_cachestat_id as set_cachestat_id,
       cachereq_params as set_params,
       max(cachereq_id) as set_cachereq_id
  from cachereq
 where cachereq_repeat = true
   and cachereq_cachereqlc_id = 1
 group by 1, 2
having count(cachereq_id) > 1
) data
  on cachereq_cachereqlc_id = 1
 and cachereq_repeat = true
 and cachereq_cachestat_id = set_cachestat_id
 and cachereq_params = set_params
 and cachereq_id <> set_cachereq_id
)
'''))

    def setup_bookingcontrol(self, dbconn=None):
        '''Measurements covering possible booking daemon problems.
        Note: the dbconn API is deprecated.'''
        # The first step of bookings should always be reasonably fast.
        self.performance_values.append(
            name='Inactivity in dbbookd Service',
            safe_interval=(0, 1),
            fail_interval=(0, 2),
            notify_trigger=25,
            performance_meter=self,
            col_widths=[10, 20, 20, 30, 30, ],
            query='''
select xferqueue_id,
       xferqueue_modtime::text as modtime,
       xferqueue_createtime::text as bookingtime,
       xfertype_name as bookingtype,
       xferstatus_name as status
  from xferqueue
  join xferstatus on xferstatus_id = xferqueue_xferstatus_id
  join xfertype on xfertype_id = xferqueue_xfertype_id
 where xferqueue_xferstatus_id = 1
   and xferqueue_done = false
   and xferqueue_modtime < now() - interval '5 minutes'
''',
            recover_trigger=5,
            recover_query=functools.partial(
               restart_service, 'dbbookd', 'localhost'))

    def setup_systemd(self):
        ''' Measurements only applicable to newer installations with
        systemd.'''
        self.performance_values.append(
                PerformanceValueCall(
                    name='Failed Systemd Services',
                    safe_interval=(0, 0),
                    fail_interval=(0, 0),
                    notify_trigger=3,
                    period=120,
                    cmd=test_systemdfailed,
                    )
                )

    def setup_dummydelay(self):
        '''Set up a test which takes a long time.'''
        self.performance_values.append(
                PerformanceValueCall(
                    name='Dummy delay test',
                    safe_interval=(0, 0),
                    fail_interval=(0, 0),
                    notify_trigger=3,
                    cmd=dummy_delay,
                    )
                )
