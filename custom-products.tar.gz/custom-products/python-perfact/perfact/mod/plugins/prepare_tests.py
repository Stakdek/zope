# Attempt to build a testing environment for zMod
import unittest  # For building a test suite
import Testing.ZopeTestCase  # For FunctionalTestCase
import Zope2  # For starting up the demo zope server


Zope2.startup()

class ReadWriteTests(Testing.ZopeTestCase.FunctionalTestCase):
    def testSimple(self):
        obj = self.app
        obj.manage_addProduct['OFSP'].manage_addDTMLDocument(id='test')
        # id, title, connection_string, check, zdatetime, tilevel, autocommit, encoding
        obj.manage_addProduct['ZPsycopgDA'].manage_addZPsycopgConnection(
            id='test2',
            title='',
            connection_string='',
        )
        #res = self.publish(url)
        #res.getBody()
        read = obj.test2.__dict__
        print(read)
        self.assertTrue(True)


def test_suite():
    return unittest.TestSuite((
        unittest.makeSuite(ReadWriteTests),
        ))
