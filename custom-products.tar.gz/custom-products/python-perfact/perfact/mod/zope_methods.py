#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# mod.zope.py  -  Module Zope methods
#
# Copyright (C) 2014 Jan Jockusch <jan.jockusch@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

# For strftime:
import time


# Needs generic stuff
from perfact.generic import *

# Plugins for handling different object types
from perfact.mod.plugins import *

# Need class zModSync for remote snapshots
import perfact.modsync


# --- Functions from the Zope front end relating to mod_*


def mod_format(data=None, indent=0, as_list=False):
    '''Make a printable output of the given object data. Indent the lines
    with <indent> spaces. Return a string or a list of lines if
    <as_list> is True.
    '''

    # if data is None: data = mod_read(obj)

    def str_repr(val):
        '''Generic string representation of a value.'''
        return str((val,))[1:-2]

    def split_longlines(lines, maxlen=100, threshold=140):
        '''Split a list of strings into a longer list of strings, but each
        with lines no longer than <threshold>, split at <maxlen>.'''
        index = 0
        while True:
            if len(lines[index]) > threshold:
                remainder = lines[index][maxlen:]
                lines[index] = lines[index][:maxlen]
                lines.insert(index+1, remainder)
            index += 1
            if index == len(lines): break
        return lines


    output = []
    def make_line(line):
        output.append(indent * ' ' + line)

    make_line('[')
    indent += 4
    for item in data:
        if type(item[1]) == type([]):
            # Non-trivial lists are shown on separate lines.
            lines = item[1]
            if len(lines) > 1:
                make_line("("+str_repr(item[0])+", [")
                indent += 4
                for l in lines:
                    make_line(str_repr(l) + ',')
                make_line("]),")
                indent -= 4
            else:
                make_line(str(item)+',')

        elif type(item[1]) in (type(b''), type(u'')):
            # Multiline presentation of non-trivial text / blobs
            text = item[1]
            if text != '' and (text.find('\n') != -1 or len(text) > 80):
                # Keep newlines after splitting.
                lines = conserv_split(text, '\n')
                # Could be binary data. So, split superlong lines as well.
                lines = split_longlines(lines)

                make_line("("+str_repr(item[0])+", ")
                indent += 4
                for l in lines:
                    make_line(str_repr(l) + '+')
                make_line("''),")
                indent -= 4
            else:
                make_line(str(item)+',')
        else:
            make_line(str(item)+',')
    indent -= 4
    make_line(']')

    if as_list:
        return output
    else:
        return '\n'.join(output)



def mod_notes_data(context=None):
    if hasattr(context, 'aq_explicit'):
        c = getattr(context.aq_explicit, 'MOD_NOTES', None)
    else:
        c = getattr(context, 'MOD_NOTES', None)

    if not c: return ''

    data = read_pdata(c)
    return data



def mod_notes_new(context=None, container=None):
    '''
    '''
    filedata = '''Version 0.9 vom %s

 Hier der Kommentar zur ersten Version.
''' % time.strftime('%d.%m.%Y')

    file_obdata = [
        ('id', 'MOD_NOTES'),
        ('title', ''),
        ('props', [
            [('id', 'title'), ('type', 'string'), ('value', '')],
            [('id', 'content_type'), ('type', 'string'), ('value', 'text/plain')],
            ]),
        ('source', filedata),
        ('type', 'File'),
    ]

    mod_write(file_obdata, parent=context)
    return





def mod_objdiff_ident(my_server, other_server):
    '''Get identification for both systems.'''
    # Syncer objects
    my_sync = perfact.modsync.zModSync(server_url=my_server)
    other_sync = perfact.modsync.zModSync(server_url=other_server)

    # Read identification
    my_ident = my_sync.server_ident()
    other_ident = other_sync.server_ident()

    assert my_ident['retcode'] == 'success', "Connection to local server broken"
    assert other_ident['retcode'] == 'success', "Connection to remote server broken"

    return {
        'my_ident': my_ident,
        'other_ident': other_ident,
    }


def mod_objdiff_cleanpath(path):
    '''Path cleanup used by mod_objdiff_get and mod_objdiff_put.'''
    path = path.strip('/')
    if not path.startswith('__root__/'):
        path = '__root__/' + path
    return path


def mod_objdiff_get(my_server, my_path,
                    other_server, other_path,
                    component):
    '''Read a component from both servers in possibly different paths
    and return a data structure with the verdict.

    Inputs:

    my_server and other_server are URLs pointing into zMod
    modules in different Zope servers.

    my_path and other_path are base paths in the servers, these should
    begin with __root__, otherwise this routine automatically prepends
    __root__.

    component contains the subpath to be added to the individual paths
    to construct the actual paths read.

    Environment:

    No environment is used except for the servers themselves, which
    must contain same versions of the perfact python-modules package
    and the zMod methods.

    Output:

    The routine returns a dictionary containing the following keys:

    my_hash, other_hash: Hash codes of the object on the local and the
    remote server respectively, or None if the object does not exist.

    my_contents, other_contents, merged_contents: Sorted lists with
    the IDs of the objects contained in the referred object. If the
    object does not exists, the list is empty. The merged_contents is
    the list that the differ should scan, because it contains all
    distinct IDs in both servers.

    diff: visualization data for displaying differences in the
    objects.

    Side Effects:

    None
    '''
    # Construct and clean up the paths
    my_path = mod_objdiff_cleanpath(my_path)
    other_path = mod_objdiff_cleanpath(other_path)

    component = component.strip('/')
    if component: component = '/' + component

    # Syncer objects
    my_sync = perfact.modsync.zModSync(server_url=my_server)
    other_sync = perfact.modsync.zModSync(server_url=other_server)

    # Read hash codes and contents
    try:
        my_data = dict(my_sync.server_read(my_path + component, mode='hash'))
    except:
        my_data = {}
    try:
        other_data = dict(other_sync.server_read(other_path + component, mode='hash'))
    except:
        other_data = {}

    out = {
        'component': component.strip('/'),
        'my_path': my_path,
        'my_hash': my_data.get('hash', None),
        'my_contents': my_data.get('contents', []),
        'other_path': other_path,
        'other_hash': other_data.get('hash', None),
        'other_contents': other_data.get('contents', []),
    }

    # Merge contents lists
    merged_contents = list(out['my_contents'])
    for item in out['other_contents']:
        if item not in merged_contents:
            merged_contents.append(item)
    merged_contents.sort()

    out['merged_contents'] = merged_contents

    # Same or missing? No differences.
    if ((out['my_hash'] is None) or
        (out['other_hash'] is None) or
        (out['my_hash'] == out['other_hash'])):
        out['diffs'] = {}

    else:
        # Difference? Read full sources
        out['my_source'] = my_sync.server_read(my_path + component)
        out['other_source'] = other_sync.server_read(other_path + component)

        # Calculate differences
        out['diff'] = mod_objdiff_diff(out['my_source'], out['other_source'])

    # Prepare output
    out['line'] = mod_objdiff_prep(out)
    return out



def mod_objdiff_push(my_server, my_path,
                     other_server, other_path,
                     del_ids=[], push_ids=[]):
    '''Push objects from my_server to other_server using zModSync objects.

    Inputs: See mod_objdiff_get

    del_ids: List of components to be deleted on other_server.

    push_ids: List of components to be read from my_server and written to other_server.

    Environment: See mod_objdiff_get

    Outputs: ?

    Side Effects:

    The Data.fs on other_server will be changed.
    '''
    # Construct and clean up the paths
    my_path = mod_objdiff_cleanpath(my_path)
    other_path = mod_objdiff_cleanpath(other_path)

    # Syncer objects
    my_sync = perfact.modsync.zModSync(server_url=my_server)
    other_sync = perfact.modsync.zModSync(server_url=other_server)

    push_ids.sort()
    for push_id in push_ids:
        data = my_sync.server_read(my_path + '/' + push_id)
        parent = (other_path + '/' + push_id).rsplit('/',1)[0]
        other_sync.server_write(parent, str(data))

    del_ids.sort()
    for del_id in del_ids:
        other_sync.server_delete(other_path + '/' + del_id)

    return



def mod_objdiff_prep(data):
    '''Prepare output data for a set of objects.'''
    opchars = {
        'equal': '=',
        'diff': '≠',
        'push': '⇒',
        'del': '⊗',
        }

    d = {
        'idA': data['component'],
        'idB': data['component'],
        'op': '',
        'opchar': '',
    }

    same = (data['my_hash'] and data['other_hash'] and
            data['my_hash'] == data['other_hash'])

    if same:
        # Objects are the same
        d['op'] = 'equal'
        d['opchar'] = opchars[d['op']]
        return d

    if data['other_hash'] is None:
        # Object is only in A
        d['idB'] = None
        d['op'] = 'push'
        d['opchar'] = opchars[d['op']]
        return d

    if data['my_hash'] is None:
        # Object is only in B
        d['idA'] = None
        d['op'] = 'del'
        d['opchar'] = opchars[d['op']]
        return d

    # Objects are different. Publish data
    d['op'] = 'diff'
    d['opchar'] = opchars[d['op']]

    return d


def mod_objdiff_diff(data_a, data_b):
    dict_a = dict(data_a)
    dict_b = dict(data_b)


    diffs = {}


    if dict_a['type'] != dict_b['type']:
        diffs = {
            'message': 'Type mismatch',
            'dict_a': {'type': dict_a['type']},
            'dict_b': {'type': dict_b['type']},
            }
        return diffs

    has_source = 'source' in dict_a
    source_a = dict_a.get('source', '')
    source_b = dict_b.get('source', '')
    if source_a: del dict_a['source']
    if source_b: del dict_b['source']

    keys = list(dict_a.keys())
    for k in dict_b.keys():
        if k not in keys: keys.append(k)
    keys.sort()

    diff_keys = []
    for key in keys:
        if dict_a.get(key, None) != dict_b.get(key, None):
            diff_keys.append(key)

    # No difference in source code? Then don't show it
    if source_a == source_b:
        has_source = False

    if has_source:
        # Perform word-for-word diff
        blocks = diff_lines(source_a, source_b)
        h_a = []
        h_b = []
        for b in blocks:
            before = html_quote(b['before'])
            h_a.append(before)
            h_b.append(before)
            ot = b.get('oldtext', '')
            nt = b.get('newtext', '')
            if not (ot or nt): continue
            if (ot and nt):
                # Perform additional word diff
                wblocks = diff_lines(ot, nt, use_tokens=True)
                wh_a = []
                wh_b = []
                for b in wblocks:
                    before = '<b class="wdiff">' + html_quote(b['before']) + '</b>'
                    wh_a.append(before)
                    wh_b.append(before)
                    wot = b['oldtext']
                    wnt = b['newtext']
                    if not (wot or wnt): continue
                    if wot: wot = html_quote(wot)
                    if wnt: wnt = html_quote(wnt)
                    wh_a.append(wot)
                    wh_b.append(wnt)
                ot = '<b>' + ''.join(wh_a) + '</b>'
                nt = '<b>' + ''.join(wh_b) + '</b>'
            else:
                # No additional diffing required. Just wrap in <b>
                if ot: ot = '<b>'+html_quote(ot)+'</b>'
                if nt: nt = '<b>'+html_quote(nt)+'</b>'
            h_a.append(ot)
            h_b.append(nt)
        highlighted_a = ''.join(h_a)
        highlighted_b = ''.join(h_b)

    else:
        highlighted_a = None
        highlighted_b = None

    diffs = {
        'message': None,
        'all_keys': keys,
        'diff_keys': diff_keys,
        'dict_a': dict_a,
        'dict_b': dict_b,
        'has_source': has_source,
        'source_a': source_a,
        'source_b': source_b,
        'highlighted_a': highlighted_a,
        'highlighted_b': highlighted_b,

        }

    return diffs





def mod_read(obj=None, onerrorstop=False):
    '''Build a consistend metadata dictionary for all types.'''

    # Known types:
    known_types = list(object_types.keys())

    # TODO:
    # - Preconditions ?
    # - Site Access Rules ?

    #if obj is None: obj = context
    meta = []


    # The Zope object type is always in the same place

    meta_type = obj.meta_type
    meta.append(('type', meta_type))

    # Modification data. This is not in the set now, because modification
    # dates should not affect the hashes and cannot be written back anyway.

    #mtime = obj.bobobase_modification_time()
    #meta.append(('mtime', mtime.strftime('%Y-%m-%d %H:%M:%S')))
    #meta.append(('mtime', str(mtime)))


    # ID is a method for some types

    id = obj.getId()
    # if callable(id):
    #     id = id()
    # if not id:
    #     id = obj.__name__
    meta.append(('id', id))

    # The title should always be readable
    title = getattr(obj, 'title', None)
    meta.append(('title', title))

    # Generic and meta type dependent handlers

    handlers = ['Properties', 'AccessControl', 'ZCacheable',]

    handlers.append(meta_type)

    if meta_type not in known_types:
        if onerrorstop:
            assert False, "Unsupported type: %s" % meta_type
        else:
            additions = [('unsupported', meta_type),]
            meta.extend(additions)
            meta.sort()
            return meta

    for handler_id in handlers:
        handler = object_types.get(handler_id, None)()
        if handler is None:
            if onerrorstop:
                assert False, "Unsupported type: %s" % meta_type
            else:
                additions = [('unsupported', meta_type),]
                meta.extend(additions)
                continue

        # Check if the interface is implemented
        implements = getattr(handler, 'implements', None)

        if implements is None or implements(obj):
            additions = handler.read(obj)
            meta.extend(additions)

    # Hash friendly, sorted list of tuples.
    meta.sort()

    return meta




def mod_restore(data=None, parent=None, onerrorstop=False,
                context=None, container=None):
    '''Given a source text file or a list of object data, this method uses
    traversal to navigate to each object in turn, compares it with the
    object in place if it exists, and overwrites it if changes are found.

    The <data> given may be a string, which is safe-evaluated into a list
    of paths and object data. Otherwise, the list can be given
    directly. The <parent> defaults to the context if not given.
    '''

    source_id = 'MOD_SOURCE'

    # a specific source_id was given:
    if data and not str(data).startswith('['):
        source_id = data
        data = None

    # if no data is given..
    if data is None:
        # ..use the context's MOD_SOURCE
        if hasattr(context, 'aq_explicit'):
            obj = getattr(context.aq_explicit, source_id, None)
        else:
            obj = getattr(context, source_id, None)

        if obj is not None:
            obj_data = mod_read(obj)
            data = dict(obj_data)['source']

            # If no parent was explicitly given, restore to the
            # acquisition parent
            if parent is None:
                parent = context.aq_parent


    # Evaluate string data if necessary
    if type(data) == type(''):
        # Use the special external method "literal_eval", which can handle
        # much bigger strings than safe_eval, and has support for basic
        # binary operators.
        data = literal_eval(data)

    # Default definition of the parent
    if parent is None: parent = context

    # Iterate through the data, keeping a report
    report = []

    for path, obj_data in data:

        # Traverse to the container

        components = path.split('/')
        trav = parent
        for component in components[:-1]:
            if hasattr(trav, 'aq_explicit'):
                trav = getattr(trav.aq_explicit, component)
            else:
                trav = getattr(trav, component)

        obj_dict = dict(obj_data)
        obj_id = obj_dict['id']
        unsupported = obj_dict.get('unsupported', None)
        if unsupported is not None:
            if onerrorstop:
                assert False, "Object type unsupported: "+unsupported
            else:
                report.append((path, "Object type unsupported: "+unsupported))
                continue

        # Sanity check
        if obj_id != components[-1]:
            assert False, "Id of object data does not match path!"

        # Id already present?

        cur_obj = None
        for id, obj in trav.objectItems():
            if id == obj_id:
                cur_obj = obj
        if cur_obj:
            # Read the current data, then.
            current_data = mod_read(cur_obj)

            # Same? Ignore this object
            if current_data == obj_data:
                report.append((path, "Object unchanged."))
                continue

        # Item new or changed? Write out.
        mod_write(obj_data, parent=trav)
        report.append((path, "Object written."))

    return report





def mod_snapshot(obj=None, basepath='', get_list=False, ignore_modules=False,
                 mode='hash', add_to_id='', add_to_props=[],
                 context=None, container=None):
    '''Recursively collect all objects and bind them in a comprehensive
    hash or source file.

    Inputs:

    obj (Object to serialize. If not given, the context is used.),

    basepath (String to prepend to all paths),

    get_list (Optionally omit string formatting and return the
      serialization list instead of a report.),

    ignore_modulues (Optionally omit folders containing MOD_INFO. Used in
      versioning, because these folders usually have their own version
      count and do not need to be included in the outer versions.)

    mode (Control whether to dump the full 'source' into MOD_SOURCE or
      just 'hash' keys for each object into MOD_HASH),

    add_to_id (Add a string to the file_id),

    add_to_props (Properties to add to the file object, these must be
      ordered key-value tuples for id, type, and value of the property.)


    Environment: Uses the context to retrieve serialization data.

    Outputs: Returns None if there is nothing to do. Returns a list of
    serialized objects if "get_list" is used. Returns a small report
    otherwise.

    Side Effects: Creates a new file object, MOD_HASH or MOD_SOURCE,
    optionally with an ID suffix and additional properties. The file
    contains a text representation of a Python list of the objects
    serialized. This list either contains SHA-hashes of the objects (to
    check if they are the same) or a full serialization. Puts a report in
    the session.

    '''

    if obj is None: obj = context

    # ID of the hash file (which should not be included in the hash
    # file...)
    hash_id = 'MOD_HASH'
    source_id = 'MOD_SOURCE'
    ignore_ids = [hash_id, source_id]

    # ID which identifies submodules
    modnotes_id = 'MOD_NOTES'

    out = []
    report = []

    # Recursively build the list of paths
    def get_recursive(anchor, basepath):
        try:    data = mod_read(anchor)
        except: return
        d = dict(data)
        id = d['id']
        contents = d.get('contents', [])

        # If in "ignore_modules" mode, skip serializing folder-like
        # objects which are themselves modules.
        if ignore_modules and modnotes_id in contents:
            report.append({
                'comment': 'Modul übersprungen',
                'arg': id,
            })
            return

        new_base = (basepath + '/' if basepath else '') + id

        for ignore_id in ignore_ids:
            if id.startswith(ignore_id):
                report.append({
                    'comment': 'Element übersprungen',
                    'arg': id,
                })
                return

        if mode == 'hash':
            hash_value = obj_hash(data)
            out.append((new_base, hash_value))
        elif mode == 'source':
            if get_list:
                out.append((new_base, data))
            else:
                formatted = mod_format(data, indent=0)
                out.append(str((new_base,))[:-1] + '\n' +
                           formatted + '\n' +
                           ')')
        else:
            assert False, "Invalid mode used!"

        report.append({
            'comment': 'Element verarbeitet',
            'arg': id,
        })

        for item in contents:
            get_recursive(getattr(anchor, item), new_base)

    get_recursive(obj, basepath)

    if get_list:
        return out

    if mode == 'hash':
        file_id = hash_id + add_to_id
        out = list(map(str, out))
    elif mode == 'source':
        file_id = source_id + add_to_id

    filedata = '[\n'+',\n'.join(out)+'\n]'
    file_obdata = [
        ('id', file_id),
        ('title', ''),
        ('props', [
            [('id', 'title'), ('type', 'string'), ('value', '')],
            [('id', 'content_type'), ('type', 'string'), ('value', 'text/plain')],
            ] + add_to_props),
        ('source', filedata),
        ('type', 'File'),
    ]

    mod_write(file_obdata, parent=obj)

    return report





def mod_title(context=None):
    parents = context.layout_crumb_list()
    parents.reverse()
    for parent in parents:
        v = mod_version(context=parent)
        if v:
            txt = parent.layout_title() + ' ' + v
            return txt
    return ''


def mod_version(context=None):
    if hasattr(context, 'aq_explicit'):
        c = getattr(context.aq_explicit, 'MOD_NOTES', None)
    else:
        c = getattr(context, 'MOD_NOTES', None)
    if not c: return ''

    # We know "MOD_NOTES" is of type File
    data = read_pdata(c)

    try:    v = data.split('\n',1)[0].strip()
    except: return ''

    # Remove the string Version"
    parts = v.split()
    if not parts: return ''
    if parts[0].startswith('V'): parts.pop(0)
    v = parts[0]

    return v


def mod_versions_diff(paths=[], context=None):
    '''Forwards the two first paths given to the diff screen.

    Inputs: paths (a list of strings denoting the IDs of the file objects
    to diff. The empty string denotes the context.

    Environment: The context is expected to be conforming to mod_versions.

    Outputs: Header redirection to mod_objdiff.

    Side Effects: Initializes the appsession settings mod_mypath and
    mod_otherpath.

    '''
    context.layout_init()

    # The base path is the context, starting at the site root.
    base = context.layout_url(method='', no_root=True)

    if len(paths) < 2:
        assert False, "Zwei Pfade werden benötigt!"

    context.appsession_set('mod_mypath',
                           (base + paths[0]).rstrip('/'))
    context.appsession_set('mod_otherpath',
                           (base + paths[1]).rstrip('/'))
    context.layout_end()
    return



def mod_versions_data(context=None):
    '''Collects data to be displayed by mod_versions.

    Input: None

    Environment: The context should contain one or more
    MOD_SOURCE_<version> files, and a MOD_NOTES file. All of these are
    optional.

    Output: A mapping object with all entries needed by mod_versions. For
    a complete list of keys, see below.

    Side effects: None
    '''
    versions = [a for a in context.objectValues('File')
            if a.id().startswith('MOD_SOURCE_')]

    versions.sort(key=lambda a: a.id(), reverse=True)

    ret = {
        'current_version': mod_version(context),
        'versions': versions,
    }

    return ret


def mod_versions_commit(version, committer='', comment='', ignore_modules=True,
                        context=None, container=None):
    '''Performs a snapshot, names it with the version tag
    and sets properties for version, committer, comment, date.

    Input: version (e.g. 1.2.3 (major, minor, patchlevel) or
    1.2.3-branch.0, committer (a text defining the committer), comment
    (what's changed since the last version), and ignore_modules (defines
    whether sub-modules should be ignored in the commit, defaults to
    True).

    Environment: The context is used as the source. If a MOD_NOTES object
    exists, its version must coincide with the version given, or an error
    will result.

    Output: None

    Side Effects: The version snapshot is generated in
    the context. A report is placed in the session (by mod_snapshot).

    '''

    # Check the version
    current_version = mod_version(context=context)
    if current_version and current_version != version:
        assert False, "Die Version stimmt nicht mit MOD_NOTES überein, bitte bearbeiten!"

    # Prepare the additional properties
    props = [
        [('id', 'version'), ('type', 'string'), ('value', version)],
        [('id', 'committer'), ('type', 'string'), ('value', committer)],
        [('id', 'comment'), ('type', 'text'), ('value', comment)],
        [('id', 'date'), ('type', 'date'), ('value', time.strftime('%Y-%m-%d'))],
    ]
    # Perform a snapshot
    mod_snapshot(mode='source', add_to_id='_'+version,
                 add_to_props=props, ignore_modules=ignore_modules,
                 context=context, container=container)

    return





def mod_write(data, parent=None, override=False, root=None):
    '''
    Given object data in <data>, store the object, creating it if it was
    missing. If <parent> is not given, the context is used. With
    <override> = True, this method will remove an existing object if there
    is a meta_type mismatch.
    If root is given, it should be the application root, which is then updated
    with the metadata in data, ignoring parent.
    '''

    # Fall back to storing in context
    # if parent is None: parent = context

    # Retrieve the object ID and meta type.

    d = dict(data)
    id = d['id']
    meta_type = d['type']

    # Plugin data

    handlers = ['Properties', 'AccessControl', 'ZCacheable',]

    handlers.append(meta_type)

    # ID exists? Check if meta type matches, emit an error if not.

    if root is None:
        if hasattr(parent, 'aq_explicit'):
            obj = getattr(parent.aq_explicit, id, None)
        else:
            obj = getattr(parent, id, None)
    else:
        obj = root

    # ID exists? Check for type
    if obj and obj.meta_type != meta_type:
        if override:
            # Remove the existing object in override mode
            parent.manage_delObjects(ids=[id,])
            obj = None
        else:
            assert False, "Type mismatch for object " + repr(data)

    # ID is new? Create a minimal object (depending on type)

    if obj is None:
        creator = object_types.get(meta_type)().create
        creator(parent, data)
        if hasattr(parent, 'aq_explicit'):
            obj = getattr(parent.aq_explicit, id, None)
        else:
            obj = getattr(parent, id, None)

    # Send an update (depending on type)
    for handler in handlers:
        folder = object_types.get(handler)()

        implements = getattr(folder, 'implements', None)
        if folder.implements(obj):
            folder.write(obj, data)



def mod_duplicates(context=None, container=None):
    source_id = 'MOD_HASH'
    data = None

    if hasattr(context, 'aq_explicit'):
        obj = getattr(context.aq_explicit, source_id, None)
    else:
        obj = getattr(context, source_id, None)
    if obj is not None:
        obj_data = mod_read(obj)
        data = dict(obj_data)['source']

    hashes = literal_eval(data)

    hashes = [a for a in hashes if a[0].find('/ARCHIVE/') == -1]

    hashes.sort(key=lambda a: a[1])

    previous_hashcode = None
    unique_count = 0
    duplicates = []

    out = []

    def detect_dups():
        if unique_count == 1:
            # Unique. Do nothing.
            return
        out.append("Duplicates found (%d)" % unique_count)
        for path in duplicates:
            out.append(" - %s" % path)
        out.append('')
        return

    for path, hashcode in hashes:
        if previous_hashcode and previous_hashcode != hashcode:
            # Hashcode has changed. Measure if unique
            detect_dups()

            unique_count = 0
            duplicates = []

        unique_count += 1
        duplicates.append(path)
        previous_hashcode = hashcode
        # out.append('%s %s %s' %(hashcode, unique_count, path))

    detect_dups()


    return '\n'.join(out)
