from perfact.mod.zope_methods import *
