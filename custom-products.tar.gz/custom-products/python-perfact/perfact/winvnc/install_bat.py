from perfact.generic import to_ustring

hostname = context.vnc_hostname
port = context.vnc_port

contents = '''@echo off
REM Choose a decent color
color 1F

REM A little information about us
echo.
echo **************************
echo * PerFact Instant VNC    *
echo *                        *
echo * started on: %%date%% *
echo **************************

REM Check if we are already running
tasklist | find "tvnserver.exe" > NUL

REM IF not, start a new vncserver-process in the background and continue with the script
if %%ERRORLEVEL%% NEQ "0" (
  start tvnserver.exe
)

REM We need to give the vncserver-process some time to spawn
ping -n 2 127.0.0.1 > NUL

REM Tell the vncserver-process that we want to connect to a listening client
tvnserver.exe -controlapp -connect %s:%s

echo.
echo.
echo.
echo Drücken Sie eine beliebige Taste um die Sitzung zu beenden
echo Press a key to terminate the remote support session
pause > NUL

REM Tell the app to shutdown
tvnserver.exe -controlapp -shutdown

REM Wait a second
ping -n 1 127.0.0.1 > NUL

REM If playing nice does not work we have to get rude -.-
taskkill /IM tvnserver.exe /F

''' % (hostname, port)

contents = to_ustring(contents).encode('cp850')

#return contents
