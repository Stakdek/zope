
def generate_key(usePutty=None, authopt=None, unixuser='secconnect'):
    '''
    Generate a public/private key pair for use in ssh.
    The private key is returned, while the public key is
    appended to the authorized_keys file of the given
    user.
    '''
    # make key in unique temp directory
    dirname = tempfile.mkdtemp()
    timestamp = strftime('%Y%m%d%H%M%S_%s')

    if (usePutty):
        os.system(('/bin/chmod 700 %(dirname)s && '+
                   'cd %(dirname)s && '+
                   '/usr/bin/ssh-keygen -C "%(timestamp)s" -f keyfile.ossh -N "" -t rsa && '+
                   '/usr/bin/puttygen keyfile.ossh -o keyfile && ' +
                   '/bin/mv keyfile.ossh.pub keyfile.pub') % locals())
    else:
        os.system(('/bin/chmod 700 %(dirname)s && '+
                   'cd %(dirname)s && '+
                   '/usr/bin/ssh-keygen -C "%(timestamp)s"'+
                   ' -f keyfile -N "" -t rsa') % locals())
                            
    # read public/private keys

    fh = open(os.path.join(dirname, 'keyfile.pub'))
    pubkey = fh.readline()[:-1]
    fh.close()

    fh = open(os.path.join(dirname, 'keyfile'))
    privkey = ''.join(fh.readlines())
    fh.close()

    os.system(('rm %(dirname)s -rf ; '+
               '~%(unixuser)s/appendkey'+
               ' ~%(unixuser)s "%(authopt)s %(pubkey)s"') % locals())

    return privkey

def getHostHash():
    f = os.popen('ssh-keygen -l -f /etc/ssh/ssh_host_rsa_key')
    e = f.readline()
    f.close()
    return e.split(' ')[1]

def getPuttyKnownHost():
    def toint(bytes):
        return ord(bytes[3])+(256*ord(bytes[2])+(256*ord(bytes[1])+256*ord(bytes[0])))

    f = open('/etc/ssh/ssh_host_rsa_key.pub')
    e = f.read()
    f.close()

    parts = e.split(' ')
    prefix = parts[0]
    data = base64.decodestring(parts[1])
    comment = parts[2]

    start = 0
    sdata=[]
    while start < len(data):
        load = toint(data[start:start+4])
        sdata.append(data[start+4:start+4+load])
        start = start + load + 4

    expval = binascii.b2a_hex(sdata[1])
    # remove leading zeros since plink fails to verify the key if there some
    while len(expval) and expval[0] == '0':
        expval = expval[1:]
    exp = '0x'+expval
    modulo = '0x'+binascii.b2a_hex(sdata[2])[2:]

    return exp+','+modulo
