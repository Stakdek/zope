#
# winvnc.py - Utilities for providing Windows users with VNC
# capabilities.
#
# Copyright (C) 2015 PerFact Innovation <support@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#

from perfact.generic import cleanup_string, safe_syscall
import string
import tempfile
import os

def create_zipfile(files):
    '''Create a zipfile containing some files.

    Input: Dictionary of files. Each key is a filename, each value is
    the binary content.

    Output: Zipfile bytes.

    Side Effects: The temporary data in /tmp will remain there until
    cleaned up by the cron job.

    '''

    tempdir = tempfile.mkdtemp()
    for f, data in files.items():
        # sanitize filenames
        f = cleanup_string(
            f, valid_chars=string.letters+string.digits+'-_.+')
        fh = open(tempdir+'/'+f, 'wb')
        fh.write(data)
        fh.flush()
        fh.close()
    retcode = os.system('cd %s; zip install.zip %s' %
                        (tempdir, ' '.join(files.keys())))
    assert retcode==0, "Problem creating zipfile."
    fh = open(tempdir + '/install.zip', 'r')
    zipfile = fh.read()
    fh.close()
    return zipfile


def create_windows_sfx(files, run=None, title=None, prompt=None):
    '''Create a windows self-extracting executable which will run a script
    immediately after unpacking.

    Input: files is a dictionary with filenames as keys and binary
    data as values. run is the filename of the file to execute after
    unpacking. title is the window title of the sfx executable, prompt
    is the safety question which will pop up before executing the
    program.

    Output: Bytes of the executable.
    '''
    tempdir = tempfile.mkdtemp()
    for f, data in files.items():
        # sanitize filenames
        f = cleanup_string(
            f, valid_chars=string.letters+string.numbers+'-_.+')
        fh = open(tempdir+'/'+f, 'wb')
        fh.write(data)
        fh.flush()
        fh.close()

    # Build the archive with 7z
    retcode = os.system('cd %s; /usr/bin/7z a archive.7z %s' %
                        (tempdir, ' '.join(files.keys())))
    assert retcode == 0, "Problem generating 7z archive."

    # Build a simple 7z configuration
    conf = ';!@Install@!UTF-8!\n'
    if title:
        conf += 'Title="'+title+'"\n'
    if prompt:
        conf += 'BeginPrompt="'+prompt+'"\n'
    if run:
        conf += 'RunProgram="'+run+'"\n'
    conf += ';!@InstallEnd@!\n'

    fc = open(tempdir + '/__config.txt', 'w')
    fc.write(conf)
    fc.close()

    # Join config and archive to build the executable.
    retcode = os.system('cd %s; cat /usr/lib/p7zip/7zSD.sfx __config.txt archive.7z > install.exe' % tempdir)
    inst = open(tempdir + '/install.exe', 'r').read()
    os.system('rm -rf '+tempdir)
    return inst
    

def vncpasswd(password):
    '''Generate a vnc password suitably encoded for use in .vnc
    configuration files.

    '''
    ch_in , ch_out = os.popen2('tightvncpasswd -f | hexdump -v -e \'/1 "%02x"\'')
    ch_in.write(password)
    ch_in.close()
    ret = ch_out.read().strip()
    ch_out.close()
    return ret


