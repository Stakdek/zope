req = context.REQUEST
resp = req.RESPONSE

files = {}
static = context.StaticFiles

for file in static:
    content = getattr(static, file)
    files[file] = str(content)

files['startup.bat'] = context.install_bat()

exename = 'perfact-vnc.exe'

if False:
    zipname = 'perfact-vnc.zip'
    archive = context.createZip(files)
    resp.setHeader('Content-Type', 'application/x-zip')
    resp.setHeader('Content-Disposition', 'filename='+zipname)
    #return archive

sfx_archive = context.createWinInstaller(files, 'startup.bat', 'PerFact-VNC', 'Start VNC remote support session?')
resp.setHeader('Content-Type', 'application/x-msdos-program')
resp.setHeader('Content-Disposition', 'filename='+exename)

#return sfx_archive
