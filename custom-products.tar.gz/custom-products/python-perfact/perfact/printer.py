# coding: utf8
#
# printer.py  -  Helpers for parsing and printing labels on
#                specialized printers in graphics format.
#
# Copyright (C) 2005 Jan Jockusch <jan.jockusch@perfact-innovation.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
from os import popen, system, listdir
import subprocess
from tempfile import mkdtemp
from syslog import syslog
import re

from perfact.generic import cleanup_string
import string


def cleanup_ident(name):
    '''remove unsafe characters from printer names etc.'''
    return cleanup_string(
        name,
        valid_chars=string.letters+string.digits+'-_.= ')

# Set of routines for coalescing several jobs into one.


def raw_print_dir(handle, printer='label1'):
    '''Send all files in tempdir to the printer as one job.
    '''
    assert printer == cleanup_ident(printer), 'Invalid printer name'
    if not handle.startswith('/tmp/'):
        raise ValueError('Invalid dir handle')

    proc = subprocess.Popen(['/usr/bin/lp', '-d', printer, '-'],
                            stdin=subprocess.PIPE)

    files = listdir(handle)
    files.sort()
    for f in files:
        fin = open(handle+'/'+f, 'r')
        while 1:
            buf = fin.read(65536)
            if not buf:
                break
            proc.stdin.write(buf)
        fin.close()

    proc.stdin.close()
    proc.wait()
    return


def pdf_print(data, printer=None, cupsparam=None, copies=1, **kw):
    '''Print PDF data directly. Keyword arguments are passed
    on to the printer as options.
    cupsparam should be a list. Earlier versions used string.
    '''
    assert printer == cleanup_ident(printer), 'Invalid printer name'
    opts = []
    for i in kw.keys():
        opts += ['-o', cleanup_ident(i)+'='+cleanup_ident(kw[i])]
    if not cupsparam:
        cupsparam = ['-d', printer]
    if copies > 1 and 'collate' not in kw.keys():
        opts += ['-o', 'collate=true']

    for i in range(len(cupsparam)):
        cupsparam[i] = cleanup_ident(cupsparam[i])
    proc = subprocess.Popen([
        '/usr/bin/lp',
        '-n', str(copies)] + opts + cupsparam,
        stdin=subprocess.PIPE,
        stderr=subprocess.PIPE,
        )
    fout = proc.stdin
    if isinstance(data, str):
        fout.write(data)
    else:
        while 1:
            buf = data.read(65536)
            if not buf:
                break
            fout.write(buf)
        data.close()

    [stdout, stderr] = proc.communicate()
    assert proc.returncode == 0, stderr
    return


def pdf_to_png(pdf, page=0, dpmm=8, antialias=None):
    '''Render a given PDF into a b/w PNG for browser visualization.
    '''
    dpi = 25.4 * dpmm
    tmpdir = mkdtemp()

    deviceopts = '-sDEVICE=pngmono'
    if antialias:
        try:
            bits = int(antialias)
        except ValueError:
            bits = 4
        deviceopts = ('-sDEVICE=pnggray -dTextAlphaBits=%d '
                      '-dGraphicsAlphaBits=%d' % (bits, bits))

    fout = popen(('(cd %s ; gs -q -dBATCH -dNOPAUSE -r%f ' +
                  '%s -sOutputFile=out%%04d.png -)') %
                 (tmpdir, dpi, deviceopts), 'w')
    fout.write(pdf)
    fout.close()

    files = listdir(tmpdir)
    files.sort()
    data = open(tmpdir + '/' + files[page], 'rb').read()
    return data


def bin_to_hex(value):
    '''Convert binary string into hex string of double length'''
    out = []
    for i in value:
        out.append('%02X' % ord(i))
    return ''.join(out)


def bin_invert(value):
    '''Invert a binary bit representation.'''
    out = []
    for i in value:
        out.append(chr(255-ord(i)))
    return ''.join(out)


def read_pbm_dimensions(fin, dpmm):
    ''' Reads the dimensions from a pbm-file and leaves the
    readpointer in the dimensions line'''
    dimensions = {}

    if fin.readline().strip() != 'P4':
        raise ValueError('Wrong file format')
    while 1:
        line = fin.readline().strip()
        if line[0] == '#':
            continue
        break
    dimensions['width'], dimensions['height'] = map(int, line.split(' '))

    dimensions['raw_width'] = (dimensions['width']+7)/8
    dimensions['raw_height'] = (dimensions['height']+7)/8
    dimensions['raw_total'] = (dimensions['raw_width'] *
                               dimensions['raw_height'] * 8)

    dimensions['width_mm'] = float(dimensions['width']) / dpmm
    dimensions['height_mm'] = float(dimensions['height']) / dpmm

    if (dimensions['height'] % 8) != 0:
        raise ValueError('Height %d not multiple of eight' %
                         dimensions['height'])

    return dimensions


class PrintStrategy(object):

    def printout(self, printfile):
        raise Exception('Use a subclass of PrintStrategy')

    def printall(self, raw_files, tmpdir='.'):
        for f in raw_files:
            fin = tmpdir + '/' + f
            self.printout(fin)

    def optimize(self, aString):
        return aString


class PrintDirStrategy(PrintStrategy):
    '''Append one or more pages to the printer file in the temp dir
    given by handle.
    '''
    def __init__(self, handle):
        if not handle.startswith('/tmp/'):
            raise ValueError('Invalid dir handle')
        self.handle = handle

    def printall(self, raw_files, tmpdir='.'):
        fout = open(self.handle+'/out.prn', 'a')
        for f in raw_files:
            fin = open(tmpdir + '/' + f, 'r')
            while 1:
                buf = fin.read(65536)
                self.optimize(buf)
                if not buf:
                    break
                fout.write(buf)
            fin.close()
        fout.close()


class DirectPrintStrategy (PrintStrategy):
    ''' Class to send raw data to a printer file per file '''
    def __init__(self, printer='label1'):
        assert printer == cleanup_ident(printer), 'Invalid printer name'
        self.printer = printer

    def printout(self, printfile):
        ''' Send data to a raw printer via lp '''
        fin = open(printfile, 'r')
        fout = popen('/usr/bin/lp -d %s -' % self.printer, 'w')
        while 1:
            buf = fin.read(65536)
            self.optimize(buf)
            if not buf:
                break
            fout.write(buf)
        fin.close()
        fout.close()
        return


class BulkPrintStrategy (DirectPrintStrategy):
    ''' Class to send raw data to a printer in one big jobs consisting of
    defined number of different labels '''

    def printall(self, raw_files, tmpdir='.'):
        ''' collects printdata in a single file and prints when limit
        is reached '''
        # If it is only one file, the DirectPrintStrategy is faster
        if (len(raw_files) < 2):
            DirectPrintStrategy.printall(self, raw_files, tmpdir)
            return
        limit = 20
        counter = 0
        alloutfile = tmpdir+'/allout.prn'
        fout = open(alloutfile, 'a')
        for f in raw_files:
            fin = open(tmpdir + '/' + f, 'r')
            while 1:
                buf = fin.read(65536)
                if not buf:
                    break
                fout.write(buf)
            fin.close()
            counter = counter + 1
            if counter >= limit:
                # print and open a new alloutfile
                fout.close()
                self.printout(alloutfile)
                system('rm -f ' + alloutfile)
                fout = open(alloutfile, 'a')
                counter = 0
        if (counter >= 0):
            fout.close()
            self.printout(alloutfile)


class BulkTestStrategy (PrintStrategy):
    ''' Class to send raw data to a testdir in one big jobs consisting of
    defined number of different labels '''

    def printout(self, printfile):
        ''' Send data to a raw printer via lp '''
        fin = open(printfile, 'r')
        # print '/usr/bin/lp -d %s -' % self.printer
        fout = open('./testneu/Ausgabe.txt', 'a')
        while 1:
            buf = fin.read(65536)
            buf = self.optimize(buf)
            if not buf:
                break
            fout.write(buf)
        fin.close()
        fout.close()
        return

    def printall(self, raw_files, tmpdir='.'):
        ''' collects printdata in a single file and prints when limit is
        reached '''
        # If it is only one file, the DirectPrintStrategy is faster
        if (len(raw_files) < 2):
            DirectPrintStrategy.printall(self, raw_files, tmpdir)
            return
        limit = 20
        counter = 0
        alloutfile = tmpdir+'/allout.prn'
        fout = open(alloutfile, 'a')
        for f in raw_files:
            fin = open(tmpdir + '/' + f, 'r')
            while 1:
                buf = fin.read(65536)
                if not buf:
                    break
                fout.write(buf)
            fin.close()
            counter = counter + 1
            if counter >= limit:
                # print and open a new alloutfile
                fout.close()
                print('printing an alloutfile')
                self.printout(alloutfile)
                system('rm -f ' + alloutfile)
                fout = open(alloutfile, 'a')
                counter = 0
        if (counter >= 0):
            fout.close()
            self.printout(alloutfile)


class TestPrintStrategy (PrintStrategy):
    ''' Does not print anything and leaves the files where they are'''
    def printall(self, raw_files, tmpdir='.'):
        print('Output-Files: ')
        for f in raw_files:
            print(tmpdir+'/'+f)


class TestPrintStrategy2 (PrintStrategy):
    ''' Does not print but moves files to ./testneu '''

    def printout(self, printfile):
        ''' Send data to a raw printer via lp '''
        # fin  = open(printfile, 'r')
        system('mv -f ' + printfile + ' ./testneu')
        print('file in ./testneu')
        return


class RawPDFPrinter (object):
    ''' Class for printing PDFs on a labelprinter '''

    def __init__(self, printstrategy):
        # print 'init: '+ str(self.__class__)
        self.printstrategy = printstrategy
        self.init_optimizer()

    def init_optimizer(self):
        # do nothing, there is no default optimizer
        return

    def get_header(self):
        return ''

    def get_single_lines(self):
        return False

    def get_name(self):
        return 'noMod'

    def pbm_to_raw_fd(self, fin, fout, copies=1,
                      hoffset=0, voffset=0,
                      tearoff=None, dpmm=8,
                      rawheader=''):
        '''Convert raw PBM data into a label printer page.'''
        # Safe parameters
        copies = int(copies or 0)
        hoffset = int(hoffset or 0)
        voffset = int(voffset or 0)
        dpmm = int(dpmm or 8)

        values = self.get_newValues()
        values['hoffset'] = hoffset
        values['voffset'] = voffset
        values['copies'] = copies
        values['rawheader'] = rawheader
        dimensions = read_pbm_dimensions(fin, dpmm)
        values.update(dimensions)
        fout.write(self.get_header() % values)

        # Write opaque binary data
        bytes_read = 0
        values['scanline'] = 0
        while True:
            buf = fin.read(self.get_single_lines() and
                           values['raw_width'] or 65536)
            bytes_read += len(buf)

            if not buf:
                break
            if bytes_read > values['raw_total']:
                buf = buf[:-(bytes_read-values['raw_total'])]

            values['scanline'] = values['scanline'] + 1
            buf = self.convert_buf(buf, values)
            fout.write(buf)

        fout.write(self.get_footer(copies=copies, hoffset=hoffset,
                                   voffset=voffset, tearoff=None))
        fin.close()
        fout.close()
        return

    def printout(self, printdata, num_labels=1, batch_size=1, dpmm=8,
                 rotate='U', hoffset=16, voffset=0, tearoff=None,
                 rawheader=''):
        ''' Print out a PDF on a raw printer
        Rotate by supplying "U", "L" or "R" as "rotate" parameter.
        Flipping is supported by passing "V" or "H" as "rotate".
        '''
        # Safe parameters
        num_labels = int(num_labels or 0)
        batch_size = int(batch_size or 0)
        dpmm = int(dpmm or 8)
        hoffset = int(hoffset or 0)
        voffset = int(voffset or 0)

        dpi = 25.4 * dpmm

        tmpdir = mkdtemp()
        fileprefix = (self.get_name() + '-' + str(num_labels) +
                      '-' + str(dpmm) + '-' + str(voffset) + '-'+str(hoffset))
        fileprefix = cleanup_ident(fileprefix)
        fout = popen(('(cd %s ; gs -q -dBATCH -dNOPAUSE -r%f ' +
                      '-sDEVICE=pbmraw -sOutputFile=%sout%%04d.pbm -)') %
                     (tmpdir, dpi, fileprefix), 'w')
        fout.write(printdata)
        fout.close()

        files = listdir(tmpdir)
        files.sort()
        raw_files = []
        count = None
        for f in files:
            if rotate:
                rot = ''
                for rotletter in rotate:
                    rot += {
                        'U': '-r180',
                        'L': '-ccw',
                        'R': '-cw',
                        'V': '-lr',
                        'H': '-tb',
                    }[rotletter] + ' '
                fin = popen('pnmflip '+rot+' '+tmpdir+'/'+f, 'r')
            else:
                fin = popen('cat '+tmpdir+'/'+f, 'r')

            # batch handling
            if count is None or count >= batch_size:
                count = 0
                outfile = f[:-3]+'raw'
                raw_files.append(outfile)
            fout = open(tmpdir+'/'+outfile, 'a')
            count += 1

            # pass this descriptor to the pbm converter
            self.pbm_to_raw_fd(fin, fout, copies=num_labels,
                               hoffset=hoffset, voffset=voffset,
                               tearoff=tearoff,
                               dpmm=dpmm, rawheader=rawheader)
        self.printstrategy.printall(raw_files, tmpdir=tmpdir)
        syslog('raw_pdf_print sent %d files to the printer' % len(raw_files))
        return

    def get_footer(self, copies=1, hoffset=0, voffset=0, tearoff=None):
        return ''

    def convert_buf(self, buf, values=None):
        return buf

    def get_newValues(self):
        return {}


# Subclasses for special printers

class RawPDFtoPICAPrinter(RawPDFPrinter):
    ''' PICA '''

    def pbm_to_raw_fd(self, fin, fout, copies=1, hoffset=0, voffset=0,
                      tearoff=None, dpmm=8, rawheader=''):
        ''' Convert raw PBM data into a label printer page
         PCX File variant
         Pica printers work differently. We need to supply a PCX file instead
         of raw pnm data, so first convert.'''
        # Safe parameters
        copies = int(copies or 0)
        hoffset = int(hoffset or 0)
        voffset = int(voffset or 0)
        dpmm = int(dpmm or 8)

        # Perform PCX conversion
        tmpdir = mkdtemp()
        pcxin = popen('convert - %s/out.pcx' % tmpdir, 'w')
        while 1:
            buf = fin.read(65536)
            if not buf:
                break
            pcxin.write(buf)
        pcxin.close()
        fin.close()

        fin = open(tmpdir+'/out.pcx', 'r')
        # Build label header and footer
        header = ('\001FCCL--r0015000-\027\001AX001'
                  '%(voffset)06d%(hoffset)06d1\027')
        footer = '''\001FBAA00r00000000\027
\001FBBA00r00001000\027
\001FBC000r00000000\027
'''

        # Output:
        fout.write(header % locals())

        # Write opaque binary data
        while 1:
            buf = fin.read(65536)
            if not buf:
                break
            fout.write(buf)
        fout.write(footer)
        fin.close()
        fout.close()
        return

    def get_name(self):
        return 'PICA'


class RawPDFtoTSPLPrinter(RawPDFPrinter):
    '''TSPL only 8dpmm'''

    def get_header(self):
        # TODO: Replace REFERENCE with SHIFT for modern printers
        # (SHIFT supports offsets -1in .. +1in)
        header = '''SIZE %(width_mm).1f mm,%(height_mm).1f mm
REFERENCE %(hoffset)d,%(voffset)d
CLS
%(rawheader)s
BITMAP 0,0,%(raw_width)d,%(height)d,0,'''
        return header

    def get_footer(self, copies=1, hoffset=0, voffset=0,
                   tearoff=None):
        # Safe param
        copies = int(copies or 0)
        return '\nPRINT 1,%d\n' % copies

    def convert_buf(self, buf, values=None):
        return bin_invert(buf)

    def get_name(self):
        return 'TSPL'


class RawPDFtoSATOPrinter(RawPDFPrinter):
    '''SATO'''
    '''
    If labels do not show up as expected, you may need to completely
    reset the SATO printer: press FEED and LINE while powering on and
    select the default configuration.
    '''
    # Sequence '\033A\033C\033Z' repeats last label

    def get_header(self):
        return ('\033A\033H%(sato_hoffset)04d\033V%(sato_voffset)04d'
                '\033GB%(raw_width)03d%(raw_height)03d')

    def get_footer(self, copies=1, hoffset=0, voffset=0,
                   tearoff=None):
        # Safe param
        copies = int(copies or 0)
        return '\033Q%06d\033Z' % copies

    def get_newValues(self):
        ret = {}
        # In some cases, we need to supply offsets inside this driver
        ret['sato_hoffset'] = 350
        ret['sato_voffset'] = 0
        return ret

    def get_name(self):
        return 'SATO'


class RawPDFtoZebraPrinter(RawPDFPrinter):
    '''Zebra'''
    ''' Feeding in Zebra printers is unknown yet. '''
    # ~DY downloads graphics into UNKNOWN.GRF
    # ^PQn before ^XZ prints several labels.
    # ^XB prevents winding to the tearoff

    def get_header(self):
        return '~DY,B,,%(raw_total)d,%(raw_width)d,'

    def get_footer(self, copies=1, hoffset=0, voffset=0,
                   tearoff=None):
        # Safe params
        copies = int(copies or 0)
        hoffset = int(hoffset or 0)
        voffset = int(voffset or 0)

        # For cutter: footer = '\n^JSA\n^JWH\n^XA\n^MMC\n^FO%2d,%2d^XG^FS\n'
        # % (hoffset, voffset)
        footer = '\n^XA\n^MMT\n^FO%2d,%2d^XG^FS\n' % (hoffset, voffset)
        if copies > 1:
            footer += '^PQ%d\n' % copies
        # tearoff won't work this way
        if tearoff:
            footer += '~TA%03d\n' % tearoff
        footer += '^XZ\n'
        return footer

    def get_name(self):
        return 'Zebra'

    def init_optimizer(self):
        self.printstrategy.optimize = self.optimize

    def optimize(self, aString):
        ''' supress backfeed in all labels but the last'''
        print('running optimize')
        aString = re.sub(r'XZ[ ]*\n(?!$)', 'XB\n^XZ\n', aString)
        return aString


class RawPDFtoZebraASCIIPrinter(RawPDFPrinter):
    '''Zebra_ASCII'''

    def get_header(self):
        return '~DY,A,,%(raw_total)d,%(raw_width)d,'

    def get_footer(self, copies=1, hoffset=0, voffset=0,
                   tearoff=None):
        # Safe params
        copies = int(copies or 0)
        hoffset = int(hoffset or 0)
        voffset = int(voffset or 0)

        footer = '\n^XA\n^FO%2d,%2d^XG^FS\n' % (hoffset, voffset)
        if copies > 1:
            footer += '^PQ%d\n' % copies
        if tearoff:
            footer += '~TA%03d\n' % tearoff
        footer += '^XZ\n'
        return footer

    def convert_buf(self, buf, values=None):
        return bin_to_hex(buf)+'\n'

    def get_name(self):
        return 'Zebra_ASCII'


class RawPDFtoEPL2Printer(RawPDFPrinter):
    '''EPL2'''

    def get_header(self):
        return '\nN\nGW%(hoffset)d,%(voffset)d,%(raw_width)d,%(height)d,'

    def get_footer(self, copies=1, hoffset=0, voffset=0, tearoff=None):
        return '\nP1,1\n'

    def convert_buf(self, buf, values=None):
        return bin_invert(buf)

    def get_name(self):
        return 'EPL2'


class RawPDFtoPICASLPrinter(RawPDFPrinter):
    '''PICA_SL'''
    # header is empty and can therefore be inherited from RawPDFPrinter

    def get_single_lines(self):
        return True

    def get_footer(self, copies=1, hoffset=0, voffset=0, tearoff=None):
        footer = '''\001FBAA00r00000000\027
\001FBBA00r00001000\027
\001FBC000r00000000\027
'''
        return footer

    def convert_buf(self, buf, values=None):
        ret = '\001D%(scanline)04d000%(raw_width)03d' % values
        ret = ret + buf + '\027'
        return ret

    def get_name(self):
        return 'PICA_SL'


class RawPDFtoPCLPrinter(RawPDFPrinter):
    ''' PCL kann bisher nur die Aufloesung 12pdmm = 300dpi'''

    def get_single_lines(self):
        return True

    def get_header(self):
        ''' PCL preceiding the raster-image'''
        # Reset the Page and set any pagesize ST printers do not care
        ret = '\x1bE\x1b&l1A'
        # Portrait, no margins
        ret = ret + '\x1b&l0o0l0E'
        # set offsets
        ret = ret + '\x1b&l%(hoffset)du%(voffset)dZ'
        # copies
        ret = ret + '\x1b&l%(copies)dX'
        # set position for the startingpoint of the graphic
        ret = ret + '\x1b*p0x0Y'
        # set the resolution TODO: Hier muss der richtige Wert rein
        # Vorsicht, hier sind dpi gefragt und nicht dpmm
        ret = ret + '\x1b*t300R'
        # set rotation TODO: Das hier könnten wir auch benutzen
        ret = ret + '\x1b*r0F'
        # set the rasterarea
        ret = ret + '\x1b*r%(height)dt%(width)dS'
        # start the graphic at the current cursor
        ret = ret + '\x1b*r1A'
        # pjl_postamble = '''
        # \x1b%%-12345X@PJL EOJ
        # @PJL RESET
        # \x1b%%-12345X '''
        # ret = ret + pjl_postamble
        return ret

    def get_footer(self, copies=1, hoffset=0, voffset=0, tearoff=None):
        ''' PCL to end the data-transfer and reset everything '''
        # *rC is the newer version but not supported by older printers
        ret = '\x1b*rB\x1bE'
        # TODO: PJL-Footer fehlt noch
        return ret

    def convert_buf(self, buf, values=None):
        ret = '\x1b*b%(raw_width)dW' % values
        ret = ret + buf
        return ret

    def get_name(self):
        return 'PCL'


class RawPDFtoDatamaxASCIIPrinter(RawPDFPrinter):
    '''Datamax ASCII'''

    def get_header(self):
        return '\x02qA\r\n\x02IAAFLOGO\r\n'

    def get_footer(self, copies=1, hoffset=0, voffset=0,
                   tearoff=None):
        footer = 'FFFF\r\n\x02L\r\n1Y1100000000000LOGO\r\nE\r\n'
        return footer

    def get_single_lines(self):
        return True

    def convert_buf(self, buf, values={}):
        hexvalues = bin_to_hex(buf)
        lineprefix = '80%02x' % len(buf)
        return lineprefix + hexvalues + '\r\n'

    def get_name(self):
        return 'Datamax_ASCII'


classselector = {
    'TSPL':        RawPDFtoTSPLPrinter,
    'SATO':        RawPDFtoSATOPrinter,
    'Zebra':       RawPDFtoZebraPrinter,
    'Zebra_ASCII': RawPDFtoZebraASCIIPrinter,
    'EPL2':        RawPDFtoEPL2Printer,
    'PICA':        RawPDFtoPICAPrinter,
    'PICA_SL':     RawPDFtoPICASLPrinter,
    'PCL':         RawPDFtoPCLPrinter,
    'DPL_ASCII':   RawPDFtoDatamaxASCIIPrinter,
    }


def raw_pdf_print_dir(handle, pdf, num_labels=1, mode="SATO", dpmm=8):
    '''Append one or more pages to the printer file in the temp dir
    given by handle.
    '''
    printstrategy = PrintDirStrategy(handle)
    printclass = classselector[mode](printstrategy)
    printclass.printout(pdf, num_labels=1)
    return


def raw_pdf_print(pdf, num_labels=1, printer='label1', mode="EPL2",
                  test__=None, batch_size=1, dpmm=8, rotate='U',
                  hoffset=16, voffset=0, tearoff=None,
                  rawheader='', **kw):
    '''Memory efficient raw printer utility.
    Rotate by supplying "U", "L" or "R" as "rotate" parameter.
    '''
    if (test__):
        printstrategy = BulkTestStrategy()
    else:
        printstrategy = BulkPrintStrategy(printer)
    printclass = classselector[mode](printstrategy)
    printclass.printout(pdf, num_labels=num_labels,
                        dpmm=dpmm, rotate=rotate, hoffset=hoffset,
                        voffset=voffset, tearoff=tearoff,
                        rawheader=rawheader)


if __name__ == '__main__':
    '''If run as main program, send a testing label.
    '''
    fin = open('label_test.pdf', 'r')
    pdf = fin.read()
    fin.close()
    # raw_pdf_print(pdf, num_labels=1, printer='label01',
    # mode="PICA", dpmm=12, test__=None, voffset=14800, hoffset=10600)
    raw_pdf_print(
        pdf, num_labels=1, printer='Testlabelprinter', mode="PICA",
        dpmm=12, test__=True, voffset=0, hoffset=0)
