#!/opt/zope/zope2.13/bin/python

import perfact.generic
import perfact.mod

import re
import urllib
import os
import tempfile
import string

import time  # for periodic output

import logging
import pprint
import difflib

try:
    import systemd.journal
except ImportError:
    # No systemd module available
    pass

logger = logging.getLogger('ModSync')
#handler = systemd.journal.JournalHandler()
handler = logging.StreamHandler()
logger.addHandler(handler)
logger.setLevel(logging.INFO)
logger.propagate = False


class zModSync:
    '''A zModSync instance is capable of mirroring a part of the ZODB
    object tree in the file system.

    By default, the syncer creates a subdirectory "__root__" in the
    current directory and can use the methods "record()" and
    "playback()" to get all objects from the ZODB or write them back,
    respectively.

    The class also contains a method for dumping schemas of databases,
    to keep track of changes there.

    It also does generic git commits, which can then be viewed and
    tracked with tig or other git-related tools.

    '''

    def __init__(self, site='__root__', base_dir='.',
                 recurse=True,
                 server_url=None,
                 databases=['perfactema', ],
                 db_tables={},
                 app=None):

        self.site = site
        self.base_dir = base_dir
        self.recurse = recurse
        self.server_url = server_url
        self.app = app
        self.databases = databases
        self.db_tables = db_tables
        assert (server_url is not None or app is not None), "server_url or app must be given."

        # Statistics
        self.num_obj_total = 1
        self.num_obj_current = 0
        self.num_obj_last_report = time.time()

        self.commit_name = "Zope Developer"
        self.commit_email = "zope-devel@perfact.de"
        self.commit_message = "Generic commit message."

        # Some objects should be ignored by the process because of
        # their specific IDs.
        self.ignore_objects = [
            re.compile('^MOD_SOURCE'),
            re.compile('^__'),
        ]

        # We write the binary sources into files ending with
        # appropriate extensions for convenience. This table guesses
        # the most important ones from the "content_type" property.
        self.content_types = {
            'application/pdf': 'pdf',
            'application/json': 'json',
            'application/javascript': 'js',
            'image/jpeg': 'jpg',
            'image/gif': 'gif',
            'image/png': 'png',
            'text/javascript': 'js',
            'text/css': 'css',
            'text/html': 'html',
            'image/svg+xml': 'svg',
        }

        # In some cases, we can deduce the best extension from the
        # object type.
        self.meta_types = {
            'Z SQL Method': 'sql',
            'Script (Python)': 'py',
        }

    def server_read(self, path, mode='source'):
        '''Given a slash-separated path, read one object from the Zope
        server.
        '''
        assert mode in ('source', 'hash'), "Illegal mode"

        logger.info("Will read from %s" % path)

        url = (self.server_url + 'mod_read?' +
               urllib.urlencode({'obj': path, 'mode': mode}))
        curl_cmd = ['curl', '-s', url]

        retcode, output = perfact.generic.safe_syscall(curl_cmd, raisemode=True)

        try:
            data = perfact.generic.literal_eval(output)
        except:
            logger.error(output)
            raise

        return data

    def server_write(self, parent, data):
        '''Write an object to the Zope server using the slash-separated parent
        path. The object will be created from the serialized
        "data".

        '''

        logger.info("Will write to %s" % parent)

        tmpdir = tempfile.mkdtemp()

        fh = open(tmpdir + '/data', 'w')
        fh.write(data)
        fh.close()

        url = self.server_url + 'mod_write'
        param1 = 'data=<%s/data' % tmpdir
        param2 = 'parent=' + parent
        curl_cmd = ['curl', '-s', '-F', param1, '-F', param2, url]

        retcode, output = perfact.generic.safe_syscall(curl_cmd, raisemode=True)

        perfact.generic.safe_syscall(['rm', '-rf', tmpdir])

        # Check if the contents has changed (are there directories not in "contents"?)

        logger.info("Written with response %s, %s" % (retcode, output))
        return data

    def server_delete(self, path):
        '''Delete an object from the Zope server using the slash-separated
        path.'''

        logger.info("Will delete object at %s" % path)

        url = self.server_url + 'mod_delete'
        param1 = urllib.urlencode({'path': path})
        curl_cmd = ['curl', '-s', '-d', param1, url]

        retcode, output = perfact.generic.safe_syscall(curl_cmd, raisemode=True)
        return

    def server_ident(self):
        '''Get identification information from the server.'''
        ret = {
            'retcode': 'unknown',
            'ident': '',
        }
        data = self.server_read('__root__')
        if not data:
            ret['retcode'] = 'unreachable'
            return ret
        d = dict(data)
        ret['retcode'] = 'success'
        ret['ident'] = d['title']
        return ret

    def source_ext_from_meta(self, meta):
        '''Guess a good extension from meta data.'''

        obj_id, meta_type, props = None, None, []
        content_type = None

        # Extract meta data from the key-value list passed.
        for key, value in meta:
            if key == 'id':
                obj_id = value
            if key == 'type':
                meta_type = value
            if key == 'props':
                props = value
        for prop in props:
            d = dict(prop)
            if d['id'] == 'content_type':
                content_type = d['value']
                break

        # txt is the default extension.
        ext = 'txt'
        # If the ID has a period, the extension defaults from the ID.
        if (obj_id or '').find('.') != -1:
            ext = obj_id.rsplit('.', 1)[-1]

        # If there's an extension to use for the object meta_type, use
        # that.
        ext = self.meta_types.get(meta_type, ext)

        # If there's a match in the content_types database, use that.
        ext = self.content_types.get(content_type, ext)
        return ext

    def fs_write(self, path, data):
        '''Write object data out to a file with the given path.'''

        # Read the basic information
        data_dict = dict(data)
        contents = data_dict.get('contents', [])
        source = data_dict.get('source', None)

        # Only write out sources if unicode or string
        write_source = (type(source) in (type(''), type(u'')))

        # Build metadata. Remove source from metadata if it is there
        meta = list(filter(lambda a: a[0] != 'source', data))
        fmt = perfact.mod.mod_format(meta).encode('utf-8')

        # Make directory for the object if it's not already there
        try:
            os.stat(self.base_dir + '/' + path)
        except:
            logger.info("Will create new directory %s" % path)
            mkdir_cmd = ['mkdir', '-p', self.base_dir + '/' + path]
            perfact.generic.safe_syscall(mkdir_cmd, raisemode=True)

        # Metadata
        data_fname = '__meta__'
        # Check if data has changed!
        try:
            old_data = open(self.base_dir + '/' +
                            path + '/' + data_fname, 'rb').read()
        except:
            old_data = None
        if old_data is None or old_data != fmt:
            logger.info("Will write %d bytes of metadata" % len(fmt))
            fh = open(self.base_dir + '/' +
                      path + '/' + data_fname, 'wb')
            fh.write(fmt)
            fh.close()

        # Write source
        if write_source:
            # Check if the source has changed!

            # Write bytes or utf-8 encoded text.
            data = source
            base = '__source__'
            if type(data) == type(u''):
                data = data.encode('utf-8')
                base = '__source-utf8__'
            ext = self.source_ext_from_meta(meta)
            src_fname = '%s.%s' % (base, ext)

            # Check if there are stray __source files and remove them first.
            source_files = [s for s in os.listdir(self.base_dir + '/' + path)
                            if s.startswith('__source') and s != src_fname]
            for source_file in source_files:
                rm_cmd = ['rm', self.base_dir + '/' + path + '/' + source_file]
                print(' '.join(rm_cmd))
                perfact.generic.safe_syscall(rm_cmd, raisemode=True)

            # Check if content has changed!
            try:
                old_data = open(self.base_dir + '/' +
                                path + '/' + src_fname, 'rb').read()
            except:
                old_data = None
            if old_data is None or old_data != data:
                logger.info("Will write %d bytes of source" % len(data))
                fh = open(self.base_dir + '/' +
                          path + '/' + src_fname, 'wb')
                fh.write(data)
                fh.close()

        # Check if the contents has changed (are there directories not in "contents"?)
        current_contents = os.listdir(self.base_dir + '/' + path)
        for item in current_contents:
            if self.is_ignored(item):
                continue

            if item not in contents:
                logger.info("Removing old item %s from filesystem" % item)
                rm_cmd = ['rm', '-rf', self.base_dir + '/' + path + '/' + item]
                perfact.generic.safe_syscall(rm_cmd, raisemode=True)

        return contents

    def fs_read(self, path):
        '''Read data from local file system.

        Use <override_contents> to merge the filesystem information
        into the data structure.'''
        data_fname = '__meta__'
        filenames = os.listdir(self.base_dir + '/' + path)
        src_fnames = list(filter(lambda a: a.startswith('__source'), filenames))
        assert len(src_fnames) <= 1, "Multiple source files in " + path
        src_fname = src_fnames and src_fnames[0] or None

        meta_str = open(self.base_dir + '/' +
                        path + '/' + data_fname, 'rb').read()
        meta = perfact.generic.literal_eval(meta_str)

        if src_fname:
            src = open(self.base_dir + '/' +
                       path + '/' + src_fname, 'rb').read()
            if src_fname.rsplit('.', 1)[0].endswith('-utf8__'):
                src = src.decode('utf-8')
            meta.append(('source', src))
            meta.sort()
        return meta

    def fix_encoding(self, data, encoding):
        '''Assume that strings in 'data' are encoded in 'encoding' and change
        them to unicode or utf-8.

        >>> example = [
        ...  ('id', 'body'),
        ...  ('owner', 'jan'),
        ...  ('props', [
        ...    [('id', 'msg_deleted'), ('type', 'string'), ('value', 'Datens\xe4tze gel\xf6scht!')],
        ...    [('id', 'content_type'), ('type', 'string'), ('value', 'text/html')],
        ...    [('id', 'height'), ('type', 'string'), ('value', 20)],
        ...    [('id', 'expand'), ('type', 'boolean'), ('value', 1)]]),
        ...  ('source', '<p>\\nIm Bereich Limitplanung sind die Pl\\xe4ne und Auswertungen zusammengefa\\xdft.\\n'),
        ...  ('title', 'Werteplan Monats\xfcbersicht'),
        ...  ('type', 'DTML Method'),
        ... ]
        >>> from pprint import pprint
        >>> pprint(zModSync(app={'dummy': True}).fix_encoding(example, 'iso-8859-1'))
        [('id', 'body'),
         ('owner', 'jan'),
         ('props',
          [[('id', 'msg_deleted'),
            ('type', 'string'),
            ('value', 'Datens\\xc3\\xa4tze gel\\xc3\\xb6scht!')],
           [('id', 'content_type'), ('type', 'string'), ('value', 'text/html')],
           [('id', 'height'), ('type', 'string'), ('value', 20)],
           [('id', 'expand'), ('type', 'boolean'), ('value', 1)]]),
         ('source',
          '<p>\\nIm Bereich Limitplanung sind die Pl\\xc3\\xa4ne und Auswertungen zusammengefa\\xc3\\x9ft.\\n'),
         ('title', 'Werteplan Monats\\xc3\\xbcbersicht'),
         ('type', 'DTML Method')]

        '''
        unpacked = dict(data)
        if 'props' in unpacked:
            unpacked_props = [dict(a) for a in unpacked['props']]
            unpacked['props'] = unpacked_props

        # Skip some types
        skip_types = ['Image', ]
        if unpacked['type'] in skip_types:
            return data
        
        # Check source
        if 'source' in unpacked and type(unpacked['source']) == type(''):
            # Only these types use ustrings, all others stay binary
            ustring_types = [
                # 'Page Template',
                # 'Script (Python)',
            ]
            conversion = unpacked['source'].decode(encoding)
            if unpacked['type'] not in ustring_types:
                conversion = conversion.encode('utf-8')
            unpacked['source'] = conversion

        # Check title
        if 'title' in unpacked and type(unpacked['title']) == type(''):
            ustring_types = [
                'Page Template',
            ]
            conversion = unpacked['title'].decode(encoding)
            if unpacked['type'] not in ustring_types:
                conversion = conversion.encode('utf-8')
            unpacked['title'] = conversion

        # Check string properties
        if 'props' in unpacked:
            for prop in unpacked['props']:
                if prop['type'] == 'string':
                    prop['value'] = str(prop['value']).decode(encoding).encode('utf-8')
        
        if 'props' in unpacked:
            repacked_props = []
            for item in unpacked['props']:
                pack = item.items()
                pack.sort()
                repacked_props.append(pack)
            unpacked['props'] = repacked_props
        repacked = unpacked.items()
        repacked.sort()
        return repacked

    def merge_contents(self, meta, path):
        '''Update meta data with the objects actually present in
        the file system.'''
        fs_contents = self.fs_contents(path)
        meta_dict = dict(meta)
        meta_contents = meta_dict.get('contents', [])
        if not fs_contents and not meta_contents:
            return meta
        sorted_meta_contents = list(meta_contents)
        sorted_meta_contents.sort()
        if sorted_meta_contents == fs_contents:
            return meta
        # add fs_contents entries not in meta
        for item in fs_contents:
            if item not in meta_contents:
                meta_contents.append(item)
        # remove meta entries not in fs_contents
        for item in meta_contents:
            if item not in fs_contents:
                meta_contents.remove(item)
        # re-generate new meta
        meta = list(meta_dict.items())
        meta.sort()
        return meta

    def fs_contents(self, path):
        '''Read the current contents from the local file system.'''
        filenames = os.listdir(self.base_dir + '/' + path)
        contents = list(filter(lambda a: not a.startswith('__'), filenames))
        contents.sort()
        return contents

    def is_ignored(self, name):
        '''Decide whether the given ID should be ignored.'''
        ignore_found = False
        for ign in self.ignore_objects:
            if ign.match(name):
                ignore_found = True
                break
        return ignore_found

    def is_unsupported(self, data):
        '''Looking at the object data, see if the object is unsupported.'''
        for key, value in data:
            if key == 'unsupported':
                return True
        return False

    def snapshot(self, path=None, recurse=True, basepath=None):
        '''Get a Zope list of objects from the server.
        '''
        if path is None:
            path = self.site
        if basepath is None:
            basepath = path
        out = []

        data = self.server_read(path)
        data_dict = dict(data)
        contents = data_dict.get('contents', [])
        if path.startswith(basepath):
            clean_path = path[len(basepath):]
        else:
            clean_path = path
        out.append((clean_path, data))

        for item in contents:

            # Check if one of the ignore patterns matches
            if self.is_ignored(item):
                continue

            # Recurse
            if recurse:
                out.extend(self.snapshot(
                    path + '/' + item,
                    recurse=recurse, basepath=basepath))

        return out

    def record(self, path=None, recurse=True):
        '''Record Zope objects from the given path into the local
        filesystem.'''
        if self.app:
            obj = self.app
            if path is not None:
                # traverse into the object of interest
                parts = list(filter(None, path.split('/')))
                for part in parts:
                    obj = getattr(obj, part)
            return self.record_app(obj, recurse=True)

        if path is None:
            path = self.site

        data = self.server_read(path)
        contents = self.fs_write(path, data)

        for item in contents:

            # Check if one of the ignore patterns matches
            if self.is_ignored(item):
                continue

            # Recurse
            if recurse:
                self.record(path + '/' + item)

    def record_app(self, obj=None, recurse=True):
        '''Record Zope objects from the given path into the local
        filesystem. Use the object "app" directly instead of curl.'''
        if obj is None:
            obj = self.all

        data = perfact.mod.mod_read(obj)
        path = self.site + ('/'.join(obj.getPhysicalPath()))
        contents = self.fs_write(path, data)

        # Update statistics
        self.num_obj_current += 1
        self.num_obj_total += len(contents)
        now = time.time()
        if now - self.num_obj_last_report > 2:
            logger.info('%d obj saved of an estimated %d, current path %s' % (
                self.num_obj_current, self.num_obj_total, path
            ))
            self.num_obj_last_report = now

        for item in contents:

            # Check if one of the ignore patterns matches
            if self.is_ignored(item):
                continue

            # Recurse
            if recurse:
                new_obj = getattr(obj, item)
                self.record_app(obj=new_obj)

    def playback(self, path=None, recurse=True, override=False,
                 encoding=None):
        '''Play back (write) objects from the local filesystem into Zope.'''
        if self.app:
            return self.playback_app(path, recurse=recurse, override=override,
                                     encoding=encoding)

        # Largely untested segment follows...
        if path is None:
            path = self.site

        fs_data = self.fs_read(path)
        srv_data = self.server_read(path)

        if fs_data == srv_data:
            logger.info("Unchanged: %s" % path)
        else:
            # Unsupported type?
            if self.is_unsupported(fs_data):
                logger.warn("Type unsupported. Not uploading %s" % path)
            else:
                logger.warn("Uploading: %s" % path)
                logger.warn(fs_data)
                logger.warn(srv_data)
                server_write(path, data)

        if recurse:
            data_dict = dict(fs_data)
            contents = data_dict.get('contents', [])
            for item in contents:
                if self.is_ignored(item):
                    continue

                self.playback(path + '/' + item)

    def playback_app(self, path=None, recurse=True, override=False,
                     encoding=None):
        '''Write Zope objects from the given path into the object
        given. Use the object "app" directly instead of curl.'''
        obj = self.app
        parent_obj = None
        obj_id = None
        root_obj = None
        if path:
            parts = [part for part in path.split('/') if part]
        if path and len(parts):
            # traverse into the object of interest
            for part in parts[:-1]:  # Stop one short to get the parent.
                obj = obj._getOb(part)  # getattr(obj, part)
            parent_obj = obj
            obj_id = parts[-1]
            if obj_id == 'get':
                logger.warn('Object "get" cannot be uploaded at path %s' %
                            path)
                return
            obj = parent_obj._getOb(obj_id, None)  # getattr(parent_obj, obj_id, None)
        else:
            root_obj = self.app

        fs_path = self.site + '/' + path
        fs_data = self.fs_read(fs_path)
        srv_data = perfact.mod.mod_read(obj) if obj else None
        # Make sure contents reflects status of file system
        fs_data = self.merge_contents(fs_data, fs_path)
        data_dict = dict(fs_data)

        contents = data_dict.get('contents', [])
        if obj and hasattr(obj, 'objectItems'):
            # Read contents from app
            srv_contents = list(map(lambda a: a[0], obj.objectItems()))
        else:
            srv_contents = []
        # Find IDs in Data.fs object not present in file system
        del_ids = list(filter(lambda a: a not in contents, srv_contents))
        if del_ids:
            logger.warn('Deleting objects ' + repr(del_ids))
            obj.manage_delObjects(ids=del_ids)

        # Update statistics
        self.num_obj_current += 1
        self.num_obj_total += len(contents)
        now = time.time()
        if now - self.num_obj_last_report > 2:
            logger.info('%d obj uploaded of an estimated %d, current path %s' % (
                self.num_obj_current, self.num_obj_total, path
            ))
            self.num_obj_last_report = now

        if encoding is not None:
            # Translate file system data
            fs_data = self.fix_encoding(fs_data, encoding)
            
        if fs_data != srv_data:
            # Unsupported type?
            if self.is_unsupported(fs_data):
                logger.warn("Type unsupported. Not uploading %s" % path)
            else:
                logger.warn("Uploading: %s" % path)
                perfact.mod.mod_write(fs_data, parent_obj, override=override, root=root_obj)
                if True:  # Enable checkback
                    # Read the object back to confirm
                    if root_obj is not None:
                        new_obj = root_obj
                    else:
                        new_obj = getattr(parent_obj, obj_id)
                    test_data = perfact.mod.mod_read(new_obj)
                    # Replace "contents"
                    test_dict = dict(test_data)
                    if 'contents' in test_dict:
                        test_dict['contents'] = contents
                        test_data = list(test_dict.items())
                        test_data.sort()
                    if test_data != fs_data:
                        if getattr(self,'differ',None) is None:
                            self.differ = difflib.Differ()
                        logger.error("Write failed!")
                        uploaded = pprint.pformat(fs_data)
                        readback = pprint.pformat(test_data)
                        diff = '\n'.join(self.differ.compare(
                            uploaded.split('\n'),readback.split('\n')))
                        logger.warn(diff)

        if recurse:
            for item in contents:
                if self.is_ignored(item):
                    continue
                self.playback_app(path=path + '/' + item, override=override,
                                  encoding=encoding)

    def recent_changes(self, since_secs=None, txnid=None, limit=50, search_limit=100):
        '''Retrieve all distinct paths which have changed recently.  Control
        how far to look back in time by supplying the number of
        seconds in Unix time in "since_secs" or the transaction ID at
        which to stop scanning in "txnid".
        Retrieves at most "limit" distinct paths.
        '''
        paths = []
        newest_txnid = None
        # Clear the request, so we can access undoable_transactions()
        self.app.REQUEST={}
        # Loop back collecting transactions
        step_size = 10
        cursor = 0
        done = False
        no_records = False
        limit_reached = False
        while cursor < search_limit:
            txns = self.app._p_jar.db().undoInfo(cursor, cursor+step_size)
            if len(txns) == 0 and cursor == 0:
                no_records = True
                break
            for txn in txns:
                if newest_txnid is None:
                    newest_txnid = txn['id']
                if since_secs and txn['time'] < since_secs:
                    done = True
                    break
                if txnid and txn['id'] == txnid:
                    done = True
                    break
                this_path = txn['description'].split('\n')[0]
                # Ignore transaction descriptions not defining a path
                if not this_path.startswith('/'):
                    continue
                # Cut the method which originated the change, leaving
                # only the object.
                this_path = this_path.rsplit('/',1)[0]
                if this_path not in paths:
                    paths.append(this_path)
                    if len(paths) >= limit:
                        done = True
                        limit_reached = True
                        break
            if done:
                break
            cursor += step_size
        return {
            'paths': paths,
            'newest_txnid': newest_txnid,
            'no_records': no_records,
            'search_limit_reached': not done,
            'limit_reached': limit_reached,
        }

    def txn_write(self, txnid):
        '''Write the newest transaction ID'''
        path = '__last_txn__'
        fh = open(self.base_dir + '/' + path, 'wb')
        fh.write(txnid)
        fh.close()

    def txn_read(self):
        '''Read the newest transaction ID'''
        path = '__last_txn__'
        try:
            txn = open(self.base_dir + '/' + path, 'rb').read()
        except:
            txn = None
        return txn

    def db_schema_dump(self, dbname=None):
        '''Make a fresh database snapshot.'''
        # Dump all databases if none is given.
        if dbname is None:
            for dbname in self.databases:
                self.db_schema_dump(dbname)
            return

        # Make directory for the dump if it's not already there
        path = '__psql__'
        try:
            os.stat(self.base_dir + '/' + path)
        except:
            logger.info("Will create new directory %s" % path)
            mkdir_cmd = ['mkdir', '-p', self.base_dir + '/' + path]
            perfact.generic.safe_syscall(mkdir_cmd, raisemode=True)

        logger.info("Will dump database schema for %s" % dbname)
        outfile = self.base_dir + '/' + path + '/schema-%s.sql' % dbname
        cmds = []
        retcode, output = perfact.generic.safe_syscall(
            ['pg_dump',
             '--schema-only',
             '--user', 'postgres',
             '--file', outfile,
             dbname, ], raisemode=True)
        return

    def db_table_dump(self, dbname=None, tablename=None):
        '''Dump the data of a given table into the repository.'''

        if dbname is None:
            # Dump all configured databases
            for dbname in self.db_tables.keys():
                self.db_table_dump(dbname)
            return
        if tablename is None:
            # Dump all configured tables
            for tablename in self.db_tables.get(dbname, []):
                self.db_table_dump(dbname, tablename)
            return

        tablename = perfact.generic.cleanup_string(
            tablename, valid_chars=string.ascii_letters + string.digits + '_')
        dbname = perfact.generic.cleanup_string(
            dbname, valid_chars=string.ascii_letters + string.digits + '_')

        path = '__psql__/data-%s' % dbname
        fname = tablename + '.sql'

        # Make directory for the dump if it's not already there
        try:
            os.stat(self.base_dir + '/' + path)
        except:
            logger.info("Will create new directory %s" % path)
            mkdir_cmd = ['mkdir', '-p', self.base_dir + '/' + path]
            perfact.generic.safe_syscall(mkdir_cmd, raisemode=True)

        logger.info("Will dump database table %s / %s" % (dbname, tablename))
        # Data must be dumped in an ordered fashion to be diff friendly.
        fh = open(self.base_dir + '/' + path + '/' + fname, 'wb')
        fh.write((u"COPY %s FROM STDIN;\n" % tablename).encode('utf-8'))
        retcode, output = perfact.generic.safe_syscall(
            ['psql',
             '--dbname', dbname,
             '--user', 'postgres',
             '--command', "copy (select * from %s order by %s_id) to stdout" %
             (tablename, tablename)], raisemode=True)
        fh.write(output)
        fh.write(u"\\.\n".encode('utf-8'))
        fh.close()
        return

    def git_init(self):

        assert False, 'DEPRECATED, use git_*-functions from pfcodechg.py'

        '''Initialize a git repository in the base directory.'''
        # We must do this in a subshell in order to use the current directory

        cmds = 'cd %s ; git init ; git add .' % self.base_dir
        retcode = os.system(cmds)
        assert retcode == 0

        cmds = ('cd %s ; git config user.email "%s"' %
                (self.base_dir, self.commit_email))
        retcode = os.system(cmds)
        assert retcode == 0

        cmds = ('cd %s ; git config user.name "%s"' %
                (self.base_dir, self.commit_name))
        retcode = os.system(cmds)
        assert retcode == 0

    def git_snapshot(self, custom_message=''):

        assert False, 'DEPRECATED, use git_*-functions from pfcodechg.py'

        cmds = ('cd %s ; git add --all ; git commit -m "%s"' %
                (self.base_dir, custom_message.replace('"', '') or self.commit_message))
        retcode = os.system(cmds)

        # The following assertion is not valid, because git returns an
        # error code if the source was not changed.
        # assert retcode == 0
