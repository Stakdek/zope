#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ssh.py  -  Utilities for connecting via OpenSSH and setup of keys/certs
#            Support for legacy systems (subset of sna_utils.py)
#
# Copyright (C) 2018 Thorsten Südbrock <thorsten.suedbrock@perfact.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

import os
import tempfile
import binascii, base64
from perfact.generic import safe_syscall
from perfact.fileassets import fileassets
from time import strftime
import ConfigParser
import StringIO
import socket


# original in /var/lib/zope2.13/instance/ema/Extensions/GONE/sna_utils.py_GONE
def generate_key(usePutty=None, authopt=None, unixuser='secconnect', bits=2048):
    '''
    Generate a public/private key pair for use in ssh.
    The private key is returned, while the public key is
    appended to the authorized_keys file of the given
    unixuser.
    '''
    # make key in unique temp directory
    dirname = tempfile.mkdtemp()
    timestamp = strftime('%Y%m%d%H%M%S_%s')
    os.chmod(dirname, 0o700)
    keyfile = os.path.join(dirname, 'keyfile')
    pubfile = os.path.join(dirname, 'keyfile.pub')
    #os.chdir(dirname)

    # create a private key
    cmd = ['/usr/bin/ssh-keygen', '-C', timestamp,
           '-f', keyfile, '-N', '', '-t', 'rsa', '-b', str(bits)]
    err, out = safe_syscall(cmd, raisemode=True)

    if (usePutty):
        keyfile_putty = keyfile + '_oss'
        cmd = ['/usr/bin/puttygen', keyfile, '-o', keyfile_putty]
        err, out = safe_syscall(cmd, raisemode=True)
        os.rename(keyfile_putty, keyfile)

    # read public/private keys

    fh = open(pubfile)
    pubkey = fh.readline()[:-1]
    fh.close()

    fh = open(keyfile)
    privkey = ''.join(fh.readlines())
    fh.close()

    # remove temporary files again
    os.remove(keyfile)
    os.remove(pubfile)
    os.rmdir(dirname)

    # unixuser home file
    homepath = os.path.expanduser('~'+unixuser)
    # append the generated public key to the ~/.ssh/authorized_keys using
    # the 'appendkey' binary
    appendkey = os.path.join(homepath, 'appendkey')
    cmd = [appendkey, homepath]
    if authopt:
        cmd.append(authopt + ' ' + pubkey)
    else:
        cmd.append(pubkey)
    err, out = safe_syscall(cmd, raisemode=True)

    return privkey


def getHostHash(path='/etc/ssh/ssh_host_rsa_key.pub', key=None):
    """ Print out hash value of a SSH public or private key

    >>> getHostHash(key=fileassets['tests.ssh_rsa_pub'])
    'SHA256:1zm+8IkeokEbEjG2Y66uKm+aDV+Ta8IXDWOIGH0Ttp4'


    >>> getHostHash(key=fileassets['tests.ssh_rsa_key'])
    'SHA256:1zm+8IkeokEbEjG2Y66uKm+aDV+Ta8IXDWOIGH0Ttp4'

    >>> getHostHash(path=fileassets.data['tests.ssh_rsa_pub']['filename'])
    'SHA256:1zm+8IkeokEbEjG2Y66uKm+aDV+Ta8IXDWOIGH0Ttp4'
    """
    if not (key or path):
        raise AssertionError("A key (string) or path (file path) must be given!")

    if path:
        if os.path.exists(path):
            keypath = path
        else:
            raise AssertionError("Given file path does not exist: %s" % path)
    tmpfile = None
    if key:
        # write out to tmpdir
        tmpdir = tempfile.mkdtemp()
        tmpfile = os.path.join(tmpdir, 'key')
        keypath = tmpfile
        f = open(tmpfile, 'w')
        f.write(key)
        f.close()
        os.chmod(tmpfile, 0o600)

    cmd = ['/usr/bin/ssh-keygen', '-l', '-f', keypath]
    err, out = safe_syscall(cmd, raisemode=False)

    if tmpfile and os.path.exists(tmpfile):
        # remove tmpfile again
        os.remove(tmpfile)
        os.rmdir(tmpdir)

    if err != 0:
        raise AssertionError("An error occured. Errorlevel: %s - Output: %s" \
        % (err, out))
    else:
        return out.split(' ')[1]

def get_pub_key(key, inputmode='openssh'):
    """ Output the corresponding SSH public key to a given SSH private key
    Supported inputmodes are 'openssh' and 'putty'
    Default is to use 'openssh'. The output format will always be openssh

    >>> get_pub_key(key=fileassets['tests.ssh_rsa_key'])
    'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAAgQDCs8us9NI70QNwHW1boSAONhem8PwCCC76m/WqtGzlvl9mxrHDHChhebQByjDO0ZKcO3Cm/HY/qA84RxGW93fzLCjxpQwtU8ymyiqeF1Hm23gUcoAVf+C1SHf6ivMkUk5LqxPdMM1GfsFVz/2u26sd/3KcABzi7ouYyNWrXTlwaw==\\n'
    """
    # write out to tmpdir
    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'privkey')
    f = open(tmpfile, 'w')
    f.write(key)
    f.close()
    os.chmod(tmpfile, 0o600)

    if inputmode == 'putty':
        cmd = ['/usr/bin/puttygen', tmpfile, '-O', 'public-openssh']
        err, out = safe_syscall(cmd, raisemode=False)
    else:
        cmd = ['/usr/bin/ssh-keygen', '-y', '-f', tmpfile]
        err, out = safe_syscall(cmd, raisemode=False)

    # remove tmpfile again
    os.remove(tmpfile)
    os.rmdir(tmpdir)

    if err != 0:
        raise AssertionError("An error occured. Errorlevel: %s - Output: %s" \
                             % (err, out))
    else:
        return out

def getPuttyKnownHost(path='/etc/ssh/ssh_host_rsa_key.pub', pubkey=None):
    """Convert the given public key into the PuTTY compatible format, so it
    can be used in the known_hosts file on Windows systems.

    >>> getPuttyKnownHost(pubkey=fileassets['tests.ssh_rsa_pub'])
    '0x10001,0xc2b3cbacf4d23bd103701d6d5ba1200e3617a6f0fc02082efa9bf5aab46ce5be5f66c6b1c31c286179b401ca30ced1929c3b70a6fc763fa80f38471196f777f32c28f1a50c2d53cca6ca2a9e1751e6db78147280157fe0b54877fa8af324524e4bab13dd30cd467ec155cffdaedbab1dff729c001ce2ee8b98c8d5ab5d39706b'

    >>> getPuttyKnownHost(path=fileassets.data['tests.ssh_rsa_pub']['filename'])
    '0x10001,0xc2b3cbacf4d23bd103701d6d5ba1200e3617a6f0fc02082efa9bf5aab46ce5be5f66c6b1c31c286179b401ca30ced1929c3b70a6fc763fa80f38471196f777f32c28f1a50c2d53cca6ca2a9e1751e6db78147280157fe0b54877fa8af324524e4bab13dd30cd467ec155cffdaedbab1dff729c001ce2ee8b98c8d5ab5d39706b'
    """
    def toint(bytes):
        return ord(bytes[3])+(256*ord(bytes[2])+(256*ord(bytes[1])+256*ord(bytes[0])))

    if not (path or pubkey):
        raise AssertionError('At least key or path must be given!')

    tmpfile=None
    if pubkey:
        # write out to tmpdir
        tmpdir = tempfile.mkdtemp()
        tmpfile = os.path.join(tmpdir, 'pubkey')
        path = tmpfile
        f = open(tmpfile, 'w')
        f.write(pubkey)
        f.close()
        os.chmod(tmpfile, 0o600)

    # read out the key
    f = open(path)
    e = f.read()
    f.close()

    # remove tmpfile again
    if tmpfile and os.path.exists(tmpfile):
        os.remove(tmpfile)
        os.rmdir(tmpdir)

    parts = e.split(' ')
    prefix = parts[0]
    data = base64.decodestring(parts[1])
    if len(parts) > 2:
        comment = parts[2]

    start = 0
    sdata=[]
    while start < len(data):
        load = toint(data[start:start+4])
        sdata.append(data[start+4:start+4+load])
        start = start + load + 4

    expval = binascii.b2a_hex(sdata[1])
    # remove leading zeros since plink fails to verify the key if there some
    while len(expval) and expval[0] == '0':
        expval = expval[1:]
    exp = '0x'+expval
    modulo = '0x'+binascii.b2a_hex(sdata[2])[2:]

    return exp+','+modulo

def genConfig(inputdict):
    """ Genearate a remote support configuration file for SSH connections
    a.k.a 'connect.rcn' file.
    It has an .ini file like syntax consisting of one [RemoteService] section
    which in turn contains multiple key = value pairs on each line

    >>> genConfig({'foo': 'bar', 'blubb': 'swush'})
    '[RemoteService]\\nfoo = bar\\nblubb = swush\\n\\n'
    """
    c = ConfigParser.ConfigParser()
    c.add_section('RemoteService')
    for k in inputdict.keys():
        c.set('RemoteService', k, inputdict[k])
    output = StringIO.StringIO()
    c.write(output)
    return output.getvalue()

def get_ports_from_proc():
    """ Return a list of tcp/udp IPv4 ports currently in use
    This function uses the /proc filesystem for information.

    >>> type(get_ports_from_proc()) == list
    True
    """
    with open('/proc/net/tcp', 'r') as myfile:
        lines = myfile.readlines()[1:] # slice first line which is a header
    tcp_items = [item.split()[1] for item in lines]
    ports_hex = [item.split(':')[1] for item in tcp_items]
    ports_int = [int(port_hex, 16) for port_hex in ports_hex]

    with open('/proc/net/udp', 'r') as myfile:
        lines = myfile.readlines()[1:] # slice first line which is a header
    udp_items = [item.split()[1] for item in lines]
    ports_hex = [item.split(':')[1] for item in udp_items]

    # add udp port to list
    ports_int += [int(port_hex, 16) for port_hex in ports_hex]

    # use set to eliminate duplicated, make sorted lsit afterwards
    return sorted(set(ports_int))


def get_ports_from_services(path='/etc/services'):
    """ Return a set of all ports listed in the given file.
    Only lines with # are removed, no further parsing is done!

    >>> type(get_ports_from_services()) == set
    True
    """
    with open(path, 'r') as myfile:
        lines = myfile.readlines()

    ports = set()
    for line in lines:
        if line.strip().startswith('#'):
            continue
        items = line.split()
        if len(items) >= 2:
            port = items[1].split('/')[0]
            ports.add(int(port))

    return ports

def get_free_port(start, stop, safe=True, blocked_portlist=None):
    """ Return the lowest free port in the given range start-stop which is
    currently unused in the system and not part of the blocked_portlist

    >>> get_free_port(start=17, stop=23, safe=True)
    Traceback (most recent call last):
    ...
    AssertionError: All ports are blocked by other services
    start: 17
    stop: 23

    >>> get_free_port(start=20, stop=23, blocked_portlist=[20,21,22,23])
    Traceback (most recent call last):
    ...
    AssertionError: No more free ports available!
    Maybe you need to increase start: 20 or stop: 23
    or give less blocked ports: [20, 21, 22, 23]

    >>> get_free_port(start=20, stop=23, blocked_portlist=[20,21,22], safe=False)
    23

    >>> get_free_port(start=42000, stop=42000, safe=True)
    42000
    """
    # exclude some ports
    if not blocked_portlist:
        blocked_portlist = []

    free = range(start,stop+1)

    if len(free) <= len(blocked_portlist):
        raise AssertionError('No more free ports available!\nMaybe you need' \
                             ' to increase start: %s or stop: %s\nor give less' \
                             ' blocked ports: %s' \
                             % (start, stop, blocked_portlist))

    if safe:
        # exclude other 'reserved' ports
        reserved = get_ports_from_services()
        blocked_portlist.extend(reserved)

        # exclude all currently open ports
        open_ports = get_ports_from_proc()
        blocked_portlist.extend(open_ports)

    free_s = set(free)
    blocked_s = set(blocked_portlist)

    free = free_s.difference(blocked_s)
    free = sorted(free)
    if not len(free):
        raise AssertionError('All ports are blocked by other services\n' \
                             'start: %s\n' \
                             'stop: %s' \
                             % (start, stop))
    port = free[0]
    return port


def kill_sshproc(pid):
    '''kill ssh process of user secconnect using wrapper executable listed in
    /etc/sudoers, create this entry if neccessary
    entry should look like:
    zope ALL=NOPASSWD:/usr/bin/perfact-killssh-secconnect
    '''
    retcode, output = safe_syscall(
        ['sudo', '/usr/bin/perfact-killssh-secconnect', '-p', str(pid)],
        raisemode=False
    )
    return retcode, output

def createWinInstaller(files, run=None, title=None, prompt=None):
    '''Creates an self extracting archive (using 7zip) for a simple
    installation without registry keys e.g. extraction of some files
    into a folder.
    Optionally a command can be executed after extraction is finished,
    using the 'run' parameter for the filename.

    :files
    Dictionary - keys are the filenames and values are the contents

    :run
    String - Name of file to be run after extraction

    :title
    String - Displayed name in the window title while extracting

    :prompt
    String - Bring up a message box with "OK/Cancel" buttons before
    extracting anything
    '''
    tempdir = tempfile.mkdtemp()
    filepaths = []
    for f in files:
        filepath = os.path.join(tempdir, f)
        filepaths.append(filepath)
        fh = open(filepath, 'wb')
        fh.write(files[f])
        fh.flush()
        fh.close()
    conf = ';!@Install@!UTF-8!\n'
    if title:
        conf += 'Title="'+title+'"\n'
    if prompt:
        conf += 'BeginPrompt="'+prompt+'"\n'
    if run:
        conf += 'RunProgram="'+run+'"\n'
    conf += ';!@InstallEnd@!\n'

    #os.popen('cd %s; /usr/bin/7z a archive.7z %s' %  (tempdir, ' '.join(files.keys())))
    archive = os.path.join(tempdir, 'archive.7z')
    cmds = ['/usr/bin/7z', 'a',]
    cmds.append(archive)
    cmds.extend(filepaths)
    ret, out = safe_syscall(cmds, raisemode=True)

    conffile = os.path.join(tempdir, '__config.txt')
    fc = open(conffile, 'w')
    fc.write(conf)
    fc.close()
    #os.popen('cd %s; cat /usr/lib/p7zip/7zSD.sfx __config.txt archive.7z > install.exe' % tempdir)
    ret, out = safe_syscall(['/bin/cat',
                             '/usr/lib/p7zip/7zSD.sfx',
                             conffile,
                             archive],
                            raisemode=True)
    inst = out
    for filepath in filepaths:
        os.remove(filepath)
    os.remove(conffile)
    os.remove(archive)
    os.rmdir(tempdir)
    return inst


def test_all():
    """ Most tests need to be run as user 'zope'!
    """
    print('Running doctests')
    import doctest
    doctest.testmod()

    uid = os.getuid()
    assert uid == 1005, "You need to run as user 'zope' (uid=1005)! \n\
    Your uid is %s. As root try: 'sudo -u zope python ssh.py'" % uid

    print('Test of private/public key pair generation and appending')
    privkey = generate_key(unixuser='secconnect', bits=1024)
    assert privkey.startswith('-----BEGIN RSA PRIVATE KEY-----'), \
        'Private key generation failed. Key is: %s' % privkey

    # check if pubkey was appended to /home/secconnect/.ssh/authorized_keys
    print('Checking if pubkey was appended to authorized_keys')
    pubkey = get_pub_key(key=privkey)
    f = open('/home/secconnect/.ssh/authorized_keys', 'r')
    found = False
    for line in f:
        if pubkey.strip() in line:
            found = True
            break
    assert found, 'Public key not found in authorized_keys. Pubkey: %s' % pubkey

    print('Test of PuTTY private/public key pair generation and appending')
    privkey = generate_key(usePutty=True, unixuser='secconnect', bits=1024)
    assert privkey.startswith('PuTTY-User-Key-File-2: ssh-rsa'), \
        'No PuTTY compatible key found. Key is: %s' % privkey

    # check if pubkey was appended to /home/secconnect/.ssh/authorized_keys
    print('Checking if pubkey was appended to authorized_keys')
    pubkey = get_pub_key(key=privkey, inputmode='putty')
    pubkey = ' '.join(pubkey.split()[0:2])
    f = open('/home/secconnect/.ssh/authorized_keys', 'r')
    found = False
    for line in f:
        if pubkey.strip() in line:
            found = True
            break
    assert found, 'Public key not found in authorized_keys. Pubkey: %s' % pubkey

    print('Test of private/public key pair generation and appending with' \
          ' additional options')
    authopt='permitopen=\"127.0.0.1:8080\",no-agent-forwarding'
    privkey = generate_key(unixuser='secconnect', bits=1024, authopt=authopt)
    assert privkey.startswith('-----BEGIN RSA PRIVATE KEY-----'), \
        'Private key generation failed. Key is: %s' % privkey

    # check if pubkey was appended to /home/secconnect/.ssh/authorized_keys
    print('Checking if pubkey was appended to authorized_keys with authopt')
    pubkey = get_pub_key(key=privkey)
    f = open('/home/secconnect/.ssh/authorized_keys', 'r')
    found = False
    for line in f:
        if pubkey.strip() in line:
            if authopt in line:
                found = True
                break
    assert found, 'Public key with options not found in authorized_keys.' \
        ' Pubkey: %s - Authopt: %s' % (pubkey, authopt)

    # Try to build an self extracting archive to mimic a very simple installer
    installer = createWinInstaller(files={'a': 'aaa',
                                          'b': 'bbb',
                                          'c': 'ccc'}
    )
    fd, instpath = tempfile.mkstemp()
    with open(instpath, 'w+b') as inst:
        inst.write(installer)
    ret, out = safe_syscall(['/usr/bin/file', '-b', instpath])
    os.remove(instpath)
    assert out.strip() == 'PE32 executable (GUI) Intel 80386, for MS Windows', \
        'The installer seems to be no windows executable!'

    print('All tests successful')


if __name__ == '__main__':
    test_all()
