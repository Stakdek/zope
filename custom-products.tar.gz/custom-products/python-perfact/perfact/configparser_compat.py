# Compatibility layer for python2 using ConfigParser instead of configparser

import ConfigParser

class ConfigParser:

    def __init__(self):
        self.c = ConfigParser.ConfigParser()

    def read(self, configfile):
        return self.c.read(configfile)

    def sections(self):
        return self.c.sections()

    def __getitem__(self, key):
        return ConfigSection(self.c, key)


class ConfigSection:

    def __init__(self, config, section):
        self.c = config
        self.s = section

    def get(self, key):
        if self.c.has_option(self.s, key):
            return self.c.get(self.s, key)
        return None

    def getfloat(self, key):
        if self.c.has_option(self.s, key):
            return self.c.getfloat(self.s, key)
        return None

    def getint(self, key):
        if self.c.has_option(self.s, key):
            return self.c.getint(self.s, key)
        return None
