# -*- coding: utf-8 -*-

from setuptools import setup
import sys
is_python2 = (sys.version_info[0] == 2)

setup(name='PerFact Python Modules',
      version='3.12.1',
      description='Modules with helper functions for PerFact Web Apps',
      long_description='''These modules are useful for expanding the capabilities of Zope
applications and command line utilities.''',
      author='Ján Jockusch et.al.',
      author_email='devel@perfact.de',
      packages=[
          'perfact',
          'perfact.mod',
          'perfact.mod.plugins',
          'perfact.winvnc',
          'perfact.perftest',
          'perfact.daemondatasources',
      ],
      package_data={
          'perfact': [
              'assets/tests/*',
              'assets/file/*',
              'assets/data/*',
              'assets/mail/*',
          ],
      },
      scripts=[
        'bin/perfact-firewall-control',
        'bin/perfact-measure',
        'bin/perfact-measurewatchdog',
        'bin/perfact-zoperecord',
        'bin/perfact-zopeplayback',
        'bin/perfact-asterisk-listener',
        'bin/perfact-assignd',
        'bin/perfact-killssh-secconnect',
        'bin/perfact-dcdiscovery',
        'bin/perfact-dbrecord',
      ] if is_python2 else [],  # Only enable this when moving to Zope4.
      license='GPLv2',
      platforms=['Linux', ],
      )
