<dtml-comment>
Connection_id : sufdb
arguments: name
</dtml-comment>
SELECT DISTINCT name FROM users ORDER BY name