# SimpleUserFolder
PerFact Version of the Zope Product SimpleUserFolder

The Product SimpleUserFolder allows methods from the Data.fs to provide the 
user list, user addition, modification and deletion, and authorization.
