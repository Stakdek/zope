Overview
========

SiteErrorLog records errors/exceptions happening anywhere in your Zope.
SiteErrorLog recorded errors are not persistent.
