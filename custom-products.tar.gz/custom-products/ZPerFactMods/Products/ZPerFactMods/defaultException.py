# Patch which adds a traceback to the default exception

import zExceptions
from zExceptions import HTTPException, status_reasons

ERROR_HTML = """\
<!DOCTYPE html>
<html>
<head>
<title>Site Error</title>
<meta charset="utf-8" />
</head>
<body bgcolor="#FFFFFF">
<h2>Site Error</h2>
<p>An error was encountered while publishing this resource.
</p>
<p><strong>{title}</strong></p>

{detail}
<hr noshade="noshade"/>
<pre>
{tb}
</pre>
<hr noshage="noshade"/>
<p>Troubleshooting Suggestions</p>

<ul>
<li>The URL may be incorrect.</li>
<li>The parameters passed to this resource may be incorrect.</li>
<li>A resource that this resource relies on may be
  encountering an error.</li>
</ul>

<p>If the error persists please contact the site maintainer.
Thank you for your patience.
</p>
</body></html>"""


def HTTPException_call(self, environ, start_response):
    headers = list(getattr(self, 'headers', {}).items())
    if not self.empty_body:
        headers.append(('content-type', 'text/html;charset=utf-8'))
    if self.errmsg is not None:
        reason = self.errmsg
    reason = status_reasons[self.getStatus()]
    start_response(
        '%d %s' % (self.getStatus(), reason),
        headers)

    if self.empty_body:
        return []

    body = self.body
    if body is None:
        message = str(self)
        detail = self.detail if self.detail is not None else message
        if self.title and detail:
            import traceback
            tb = traceback.format_exc()
            body = self.body_template.format(
                title=self.title, detail=detail, tb=tb)
            body = body
        else:
            body = message
    return [body.encode('utf-8')]



zExceptions.ERROR_HTML = ERROR_HTML
HTTPException.body_template = ERROR_HTML
HTTPException.__call__ = HTTPException_call
