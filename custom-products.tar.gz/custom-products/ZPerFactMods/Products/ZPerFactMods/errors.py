class NotFoundView(object):
    def test(self):
        import pdb
        pdb.set_trace()
